// Simple test script for the Agentik Marketplace feature
document.addEventListener('DOMContentLoaded', function() {
  console.log('Testing Agentik Marketplace feature...');
  
  // Check if marketplace button exists
  const marketplaceBtn = document.getElementById('marketplaceBtn');
  if (marketplaceBtn) {
    console.log('✅ Marketplace button found');
  } else {
    console.error('❌ Marketplace button not found');
  }
  
  // Check if marketplace modal exists
  const marketplaceModal = document.getElementById('marketplaceModal');
  if (marketplaceModal) {
    console.log('✅ Marketplace modal found');
  } else {
    console.error('❌ Marketplace modal not found');
  }
  
  // Check marketplace options
  const marketplaceOptions = document.querySelectorAll('.marketplace-option');
  if (marketplaceOptions.length === 4) {
    console.log(`✅ Found ${marketplaceOptions.length} marketplace options`);
  } else {
    console.error(`❌ Expected 4 marketplace options, found ${marketplaceOptions.length}`);
  }
  
  // Test marketplace button click
  if (marketplaceBtn && marketplaceModal) {
    marketplaceBtn.click();
    if (!marketplaceModal.classList.contains('hidden')) {
      console.log('✅ Marketplace modal opens on button click');
    } else {
      console.error('❌ Marketplace modal did not open on button click');
    }
    
    // Test marketplace option selection
    if (marketplaceOptions.length > 0) {
      const firstOption = marketplaceOptions[0];
      const marketplaceId = firstOption.getAttribute('data-marketplace');
      firstOption.click();
      
      // Check if agents list is shown
      const agentsList = document.getElementById('agentsList');
      if (agentsList && !agentsList.classList.contains('hidden')) {
        console.log(`✅ Agents list shown for marketplace: ${marketplaceId}`);
        
        // Check if agents are populated
        const agentsContainer = document.getElementById('agentsContainer');
        const agentCards = agentsContainer.querySelectorAll('.agent-card');
        if (agentCards.length > 0) {
          console.log(`✅ Found ${agentCards.length} agents for ${marketplaceId}`);
        } else {
          console.error(`❌ No agents found for ${marketplaceId}`);
        }
      } else {
        console.error('❌ Agents list not shown after marketplace selection');
      }
    }
    
    // Test close button
    const closeBtn = document.getElementById('closeMarketplaceBtn');
    if (closeBtn) {
      closeBtn.click();
      if (marketplaceModal.classList.contains('hidden')) {
        console.log('✅ Marketplace modal closes on close button click');
      } else {
        console.error('❌ Marketplace modal did not close on close button click');
      }
    } else {
      console.error('❌ Close button not found');
    }
  }
  
  console.log('Marketplace testing complete');
});
