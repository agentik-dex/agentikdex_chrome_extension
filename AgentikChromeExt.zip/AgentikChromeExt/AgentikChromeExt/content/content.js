// Agentik Wallet - Content Script
// This script runs in the context of web pages and provides integration with DeFi platforms

console.log("Agentik Wallet content script loaded");

// Constants
const SUPPORTED_PLATFORMS = [
  { domain: "app.uniswap.org", type: "dex" },
  { domain: "app.aave.com", type: "lending" },
  { domain: "compound.finance", type: "lending" },
  { domain: "pancakeswap.finance", type: "dex" },
  { domain: "raydium.io", type: "dex" },
  { domain: "sushi.com", type: "dex" }
];

// Check if current site is a supported DeFi platform
function checkCurrentSite() {
  const currentDomain = window.location.hostname;
  return SUPPORTED_PLATFORMS.find(platform => currentDomain.includes(platform.domain));
}

// Initialize platform integration
function initPlatformIntegration() {
  const currentPlatform = checkCurrentSite();
  
  if (!currentPlatform) {
    console.log("Not on a supported DeFi platform");
    return;
  }
  
  console.log(`Detected ${currentPlatform.type} platform: ${currentPlatform.domain}`);
  
  // Add platform-specific integration
  switch (currentPlatform.type) {
    case "dex":
      integrateWithDEX(currentPlatform.domain);
      break;
    case "lending":
      integrateWithLending(currentPlatform.domain);
      break;
    default:
      console.log("No specific integration for this platform type");
  }
  
  // Add Agentik Wallet control button to the page
  addAgentikWalletControl();
}

// Integrate with DEX platforms
function integrateWithDEX(domain) {
  console.log(`Integrating with DEX: ${domain}`);
  
  // Monitor for swap forms
  const observer = new MutationObserver((mutations) => {
    // Look for swap input fields
    const amountInputs = document.querySelectorAll('input[type="number"], input[type="text"]');
    
    amountInputs.forEach(input => {
      // Check if this input is likely part of a swap form
      const isSwapInput = isElementPartOfSwapForm(input);
      
      if (isSwapInput && !input.dataset.cryptoVoiceMonitored) {
        console.log("Found swap input field, adding integration");
        
        // Mark as monitored to avoid duplicate listeners
        input.dataset.cryptoVoiceMonitored = "true";
        
        // Add event listeners to capture swap details
        input.addEventListener('change', captureSwapDetails);
      }
    });
  });
  
  // Start observing the document
  observer.observe(document.body, { 
    childList: true, 
    subtree: true 
  });
}

// Integrate with lending platforms
function integrateWithLending(domain) {
  console.log(`Integrating with lending platform: ${domain}`);
  
  // Similar approach to DEX integration but for lending forms
  // This would monitor for supply/borrow forms
  
  // For demonstration purposes, we'll use a simplified version
  const observer = new MutationObserver((mutations) => {
    // Look for lending action buttons
    const actionButtons = document.querySelectorAll('button');
    
    actionButtons.forEach(button => {
      const buttonText = button.textContent.toLowerCase();
      
      // Check if this button is for lending actions
      const isLendingAction = 
        buttonText.includes('supply') || 
        buttonText.includes('borrow') || 
        buttonText.includes('repay') || 
        buttonText.includes('withdraw');
      
      if (isLendingAction && !button.dataset.cryptoVoiceMonitored) {
        console.log("Found lending action button, adding integration");
        
        // Mark as monitored
        button.dataset.cryptoVoiceMonitored = "true";
        
        // Add event listener
        button.addEventListener('click', captureLendingAction);
      }
    });
  });
  
  // Start observing
  observer.observe(document.body, { 
    childList: true, 
    subtree: true 
  });
}

// Helper function to determine if an element is part of a swap form
function isElementPartOfSwapForm(element) {
  // This is a simplified check - in a real implementation, this would be more robust
  // Check if the element or its parents contain swap-related text
  
  let current = element;
  let depth = 0;
  const maxDepth = 5; // Limit how far up the DOM we check
  
  while (current && depth < maxDepth) {
    // Check element text content
    const text = current.textContent.toLowerCase();
    
    if (text.includes('swap') || 
        text.includes('exchange') || 
        text.includes('from') && text.includes('to') ||
        text.includes('trade')) {
      return true;
    }
    
    // Move up to parent
    current = current.parentElement;
    depth++;
  }
  
  return false;
}

// Capture swap details when user interacts with DEX
function captureSwapDetails(event) {
  const input = event.target;
  const value = input.value;
  
  // Try to determine if this is a "from" or "to" input
  let isFromInput = false;
  let tokenSymbol = "";
  
  // Check nearby elements for token information
  const container = findParentContainer(input);
  
  if (container) {
    // Look for token symbols in the container
    const tokenElements = container.querySelectorAll('span, div');
    
    for (const element of tokenElements) {
      const text = element.textContent.trim();
      
      // Simple check for token symbols (3-5 uppercase letters)
      if (/^[A-Z]{3,5}$/.test(text)) {
        tokenSymbol = text;
        break;
      }
    }
    
    // Try to determine if this is "from" or "to" based on position or labels
    const labels = container.querySelectorAll('label, span, div');
    
    for (const label of labels) {
      const text = label.textContent.toLowerCase();
      
      if (text.includes('from') || text.includes('you pay') || text.includes('input')) {
        isFromInput = true;
        break;
      }
    }
  }
  
  // Send the captured information to the background script
  chrome.runtime.sendMessage({
    action: "dexInteraction",
    data: {
      type: isFromInput ? "from" : "to",
      value: value,
      token: tokenSymbol,
      platform: window.location.hostname
    }
  });
}

// Capture lending actions
function captureLendingAction(event) {
  const button = event.target;
  const actionType = button.textContent.trim().toLowerCase();
  
  // Try to find the associated amount and asset
  const container = findParentContainer(button);
  let amount = "";
  let asset = "";
  
  if (container) {
    // Look for input fields with numbers
    const inputs = container.querySelectorAll('input[type="number"], input[type="text"]');
    
    for (const input of inputs) {
      if (input.value && !isNaN(parseFloat(input.value))) {
        amount = input.value;
        break;
      }
    }
    
    // Look for asset symbols
    const tokenElements = container.querySelectorAll('span, div');
    
    for (const element of tokenElements) {
      const text = element.textContent.trim();
      
      // Simple check for token symbols
      if (/^[A-Z]{3,5}$/.test(text)) {
        asset = text;
        break;
      }
    }
  }
  
  // Send the captured information to the background script
  chrome.runtime.sendMessage({
    action: "lendingInteraction",
    data: {
      type: actionType, // supply, borrow, etc.
      amount: amount,
      asset: asset,
      platform: window.location.hostname
    }
  });
}

// Helper function to find a parent container for an element
function findParentContainer(element) {
  // Look for a parent div that likely contains the whole form section
  let current = element;
  let depth = 0;
  const maxDepth = 5;
  
  while (current && depth < maxDepth) {
    // Check if this element has multiple inputs or appears to be a form section
    if (current.querySelectorAll('input').length > 1 || 
        current.querySelectorAll('button').length > 0) {
      return current;
    }
    
    current = current.parentElement;
    depth++;
  }
  
  // If no suitable container found, return the immediate parent
  return element.parentElement;
}

// Add Agentik Wallet control to the page
function addAgentikWalletControl() {
  // Create the control element
  const controlElement = document.createElement('div');
  controlElement.className = 'cryptovoice-control';
  controlElement.innerHTML = `
    <button class="cryptovoice-button">
      <span class="cryptovoice-icon">🎤</span>
      <span class="cryptovoice-text">Agentik Wallet</span>
    </button>
  `;
  
  // Add styles
  const styles = document.createElement('style');
  styles.textContent = `
    .cryptovoice-control {
      position: fixed;
      bottom: 20px;
      right: 20px;
      z-index: 10000;
    }
    
    .cryptovoice-button {
      background-color: #6c5ce7;
      color: white;
      border: none;
      border-radius: 50px;
      padding: 10px 20px;
      display: flex;
      align-items: center;
      gap: 8px;
      box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
      cursor: pointer;
      transition: all 0.2s ease;
    }
    
    .cryptovoice-button:hover {
      transform: translateY(-2px);
      box-shadow: 0 6px 16px rgba(0, 0, 0, 0.2);
    }
    
    .cryptovoice-icon {
      font-size: 18px;
    }
    
    .cryptovoice-text {
      font-weight: 500;
    }
    
    .cryptovoice-listening .cryptovoice-button {
      background-color: #fd79a8;
      animation: pulse 1.5s infinite;
    }
    
    @keyframes pulse {
      0% {
        transform: scale(1);
      }
      50% {
        transform: scale(1.05);
      }
      100% {
        transform: scale(1);
      }
    }
  `;
  
  // Add to the document
  document.head.appendChild(styles);
  document.body.appendChild(controlElement);
  
  // Add event listener
  const button = controlElement.querySelector('.cryptovoice-button');
  let isListening = false;
  
  button.addEventListener('click', () => {
    isListening = !isListening;
    
    if (isListening) {
      controlElement.classList.add('cryptovoice-listening');
      button.querySelector('.cryptovoice-text').textContent = 'Listening...';
      
      // Notify background script to start listening
      chrome.runtime.sendMessage({ action: "startVoiceRecognition" });
    } else {
      controlElement.classList.remove('cryptovoice-listening');
      button.querySelector('.cryptovoice-text').textContent = 'Agentik Wallet';
      
      // Notify background script to stop listening
      chrome.runtime.sendMessage({ action: "stopVoiceRecognition" });
    }
  });
}

// Listen for messages from the background script
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.action === "fillDexForm") {
    // Fill in a DEX form with the provided values
    fillDexForm(message.data);
    sendResponse({ success: true });
  } else if (message.action === "fillLendingForm") {
    // Fill in a lending form with the provided values
    fillLendingForm(message.data);
    sendResponse({ success: true });
  }
});

// Fill in a DEX form with values from a voice command
function fillDexForm(data) {
  console.log("Filling DEX form with:", data);
  
  // Find all input fields
  const inputs = document.querySelectorAll('input[type="number"], input[type="text"]');
  
  // Try to identify the "from" input
  let fromInput = null;
  
  for (const input of inputs) {
    const container = findParentContainer(input);
    
    if (container) {
      const labels = container.querySelectorAll('label, span, div');
      
      for (const label of labels) {
        const text = label.textContent.toLowerCase();
        
        if (text.includes('from') || text.includes('you pay') || text.includes('input')) {
          fromInput = input;
          break;
        }
      }
      
      if (fromInput) break;
    }
  }
  
  // If we found the input, fill it with the amount
  if (fromInput) {
    fromInput.value = data.amount;
    fromInput.dispatchEvent(new Event('input', { bubbles: true }));
    fromInput.dispatchEvent(new Event('change', { bubbles: true }));
    
    console.log("Filled DEX form with amount:", data.amount);
  } else {
    console.log("Could not find the appropriate input field");
  }
}

// Fill in a lending form with values from a voice command
function fillLendingForm(data) {
  console.log("Filling lending form with:", data);
  
  // Similar implementation to fillDexForm but for lending platforms
  // This would be customized based on the specific lending platforms supported
}

// Initialize when the content script loads
initPlatformIntegration();
