/**
 * CryptoVoice - Cryptography Utilities
 * 
 * This file contains utility functions for cryptographic operations
 * such as encryption, decryption, hashing, and secure key management.
 */

/**
 * Encryption algorithms
 * @enum {string}
 */
const EncryptionAlgorithms = {
  AES_GCM: 'AES-GCM',
  AES_CBC: 'AES-CBC',
  RSA_OAEP: 'RSA-OAEP'
};

/**
 * Hash algorithms
 * @enum {string}
 */
const HashAlgorithms = {
  SHA_256: 'SHA-256',
  SHA_512: 'SHA-512',
  BLAKE2B: 'BLAKE2B'
};

/**
 * Key derivation algorithms
 * @enum {string}
 */
const KeyDerivationAlgorithms = {
  PBKDF2: 'PBKDF2',
  ARGON2: 'ARGON2'
};

/**
 * Generates a random UUID
 * @returns {string} Random UUID
 */
function generateUUID() {
  try {
    // Use crypto.randomUUID if available
    if (crypto && typeof crypto.randomUUID === 'function') {
      return crypto.randomUUID();
    }
    
    // Fallback implementation
    const rnds = new Uint8Array(16);
    crypto.getRandomValues(rnds);
    
    // Set version bits
    rnds[6] = (rnds[6] & 0x0f) | 0x40; // Version 4
    rnds[8] = (rnds[8] & 0x3f) | 0x80; // Variant 10
    
    // Convert to hex string
    const hexBytes = [];
    for (let i = 0; i < 16; i++) {
      hexBytes.push(rnds[i].toString(16).padStart(2, '0'));
    }
    
    // Format as UUID
    return [
      hexBytes.slice(0, 4).join(''),
      hexBytes.slice(4, 6).join(''),
      hexBytes.slice(6, 8).join(''),
      hexBytes.slice(8, 10).join(''),
      hexBytes.slice(10, 16).join('')
    ].join('-');
  } catch (error) {
    console.error('Error generating UUID:', error);
    
    // Last resort fallback
    return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function(c) {
      const r = Math.random() * 16 | 0;
      const v = c === 'x' ? r : (r & 0x3 | 0x8);
      return v.toString(16);
    });
  }
}

/**
 * Generates a random string
 * @param {number} length - Length of the string
 * @param {string} charset - Character set to use
 * @returns {string} Random string
 */
function generateRandomString(length = 16, charset = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789') {
  try {
    // Generate random values
    const randomValues = new Uint8Array(length);
    crypto.getRandomValues(randomValues);
    
    // Map to charset
    let result = '';
    for (let i = 0; i < length; i++) {
      result += charset.charAt(randomValues[i] % charset.length);
    }
    
    return result;
  } catch (error) {
    console.error('Error generating random string:', error);
    
    // Fallback implementation
    let result = '';
    for (let i = 0; i < length; i++) {
      result += charset.charAt(Math.floor(Math.random() * charset.length));
    }
    
    return result;
  }
}

/**
 * Generates a random bytes array
 * @param {number} length - Length of the array
 * @returns {Uint8Array} Random bytes
 */
function generateRandomBytes(length = 32) {
  try {
    const bytes = new Uint8Array(length);
    crypto.getRandomValues(bytes);
    return bytes;
  } catch (error) {
    console.error('Error generating random bytes:', error);
    throw new Error('Failed to generate random bytes');
  }
}

/**
 * Converts a string to bytes
 * @param {string} str - String to convert
 * @returns {Uint8Array} Bytes
 */
function stringToBytes(str) {
  return new TextEncoder().encode(str);
}

/**
 * Converts bytes to a string
 * @param {Uint8Array} bytes - Bytes to convert
 * @returns {string} String
 */
function bytesToString(bytes) {
  return new TextDecoder().decode(bytes);
}

/**
 * Converts bytes to a hex string
 * @param {Uint8Array} bytes - Bytes to convert
 * @returns {string} Hex string
 */
function bytesToHex(bytes) {
  return Array.from(bytes)
    .map(b => b.toString(16).padStart(2, '0'))
    .join('');
}

/**
 * Converts a hex string to bytes
 * @param {string} hex - Hex string to convert
 * @returns {Uint8Array} Bytes
 */
function hexToBytes(hex) {
  const bytes = new Uint8Array(hex.length / 2);
  for (let i = 0; i < hex.length; i += 2) {
    bytes[i / 2] = parseInt(hex.substring(i, i + 2), 16);
  }
  return bytes;
}

/**
 * Converts bytes to a base64 string
 * @param {Uint8Array} bytes - Bytes to convert
 * @returns {string} Base64 string
 */
function bytesToBase64(bytes) {
  const binString = Array.from(bytes)
    .map(b => String.fromCharCode(b))
    .join('');
  return btoa(binString);
}

/**
 * Converts a base64 string to bytes
 * @param {string} base64 - Base64 string to convert
 * @returns {Uint8Array} Bytes
 */
function base64ToBytes(base64) {
  const binString = atob(base64);
  const bytes = new Uint8Array(binString.length);
  for (let i = 0; i < binString.length; i++) {
    bytes[i] = binString.charCodeAt(i);
  }
  return bytes;
}

/**
 * Hashes data using the specified algorithm
 * @param {string|Uint8Array} data - Data to hash
 * @param {string} algorithm - Hash algorithm to use
 * @returns {Promise<Uint8Array>} Hash
 */
async function hashData(data, algorithm = HashAlgorithms.SHA_256) {
  try {
    // Convert string to bytes if needed
    const dataBytes = typeof data === 'string' ? stringToBytes(data) : data;
    
    // Hash data
    const hashBuffer = await crypto.subtle.digest(algorithm, dataBytes);
    
    // Convert to Uint8Array
    return new Uint8Array(hashBuffer);
  } catch (error) {
    console.error(`Error hashing data with ${algorithm}:`, error);
    throw new Error(`Failed to hash data with ${algorithm}`);
  }
}

/**
 * Derives a key from a password
 * @param {string} password - Password to derive key from
 * @param {Uint8Array} salt - Salt for key derivation
 * @param {string} algorithm - Key derivation algorithm
 * @param {number} iterations - Number of iterations
 * @param {number} keyLength - Length of the derived key in bytes
 * @returns {Promise<Uint8Array>} Derived key
 */
async function deriveKey(password, salt, algorithm = KeyDerivationAlgorithms.PBKDF2, iterations = 100000, keyLength = 32) {
  try {
    // Convert password to bytes
    const passwordBytes = stringToBytes(password);
    
    // Import password as key
    const baseKey = await crypto.subtle.importKey(
      'raw',
      passwordBytes,
      { name: 'PBKDF2' },
      false,
      ['deriveBits']
    );
    
    // Derive key
    const derivedBits = await crypto.subtle.deriveBits(
      {
        name: 'PBKDF2',
        salt,
        iterations,
        hash: 'SHA-256'
      },
      baseKey,
      keyLength * 8
    );
    
    // Convert to Uint8Array
    return new Uint8Array(derivedBits);
  } catch (error) {
    console.error(`Error deriving key with ${algorithm}:`, error);
    throw new Error(`Failed to derive key with ${algorithm}`);
  }
}

/**
 * Generates an encryption key
 * @param {string} algorithm - Encryption algorithm
 * @returns {Promise<CryptoKey>} Encryption key
 */
async function generateEncryptionKey(algorithm = EncryptionAlgorithms.AES_GCM) {
  try {
    // Generate key
    return await crypto.subtle.generateKey(
      {
        name: algorithm,
        length: 256
      },
      true,
      ['encrypt', 'decrypt']
    );
  } catch (error) {
    console.error(`Error generating encryption key for ${algorithm}:`, error);
    throw new Error(`Failed to generate encryption key for ${algorithm}`);
  }
}

/**
 * Exports a key to raw bytes
 * @param {CryptoKey} key - Key to export
 * @returns {Promise<Uint8Array>} Exported key
 */
async function exportKey(key) {
  try {
    // Export key
    const exportedKey = await crypto.subtle.exportKey('raw', key);
    
    // Convert to Uint8Array
    return new Uint8Array(exportedKey);
  } catch (error) {
    console.error('Error exporting key:', error);
    throw new Error('Failed to export key');
  }
}

/**
 * Imports a key from raw bytes
 * @param {Uint8Array} keyData - Key data
 * @param {string} algorithm - Encryption algorithm
 * @returns {Promise<CryptoKey>} Imported key
 */
async function importKey(keyData, algorithm = EncryptionAlgorithms.AES_GCM) {
  try {
    // Import key
    return await crypto.subtle.importKey(
      'raw',
      keyData,
      {
        name: algorithm,
        length: 256
      },
      true,
      ['encrypt', 'decrypt']
    );
  } catch (error) {
    console.error(`Error importing key for ${algorithm}:`, error);
    throw new Error(`Failed to import key for ${algorithm}`);
  }
}

/**
 * Encrypts data using AES-GCM
 * @param {string|Uint8Array} data - Data to encrypt
 * @param {CryptoKey} key - Encryption key
 * @returns {Promise<Object>} Encrypted data with IV
 */
async function encryptData(data, key) {
  try {
    // Convert string to bytes if needed
    const dataBytes = typeof data === 'string' ? stringToBytes(data) : data;
    
    // Generate IV
    const iv = generateRandomBytes(12);
    
    // Encrypt data
    const encryptedBuffer = await crypto.subtle.encrypt(
      {
        name: 'AES-GCM',
        iv
      },
      key,
      dataBytes
    );
    
    // Convert to Uint8Array
    const encryptedBytes = new Uint8Array(encryptedBuffer);
    
    // Return encrypted data with IV
    return {
      encryptedData: encryptedBytes,
      iv
    };
  } catch (error) {
    console.error('Error encrypting data:', error);
    throw new Error('Failed to encrypt data');
  }
}

/**
 * Decrypts data using AES-GCM
 * @param {Uint8Array} encryptedData - Encrypted data
 * @param {Uint8Array} iv - Initialization vector
 * @param {CryptoKey} key - Decryption key
 * @param {boolean} asString - Whether to return the result as a string
 * @returns {Promise<Uint8Array|string>} Decrypted data
 */
async function decryptData(encryptedData, iv, key, asString = false) {
  try {
    // Decrypt data
    const decryptedBuffer = await crypto.subtle.decrypt(
      {
        name: 'AES-GCM',
        iv
      },
      key,
      encryptedData
    );
    
    // Convert to Uint8Array
    const decryptedBytes = new Uint8Array(decryptedBuffer);
    
    // Return as string if requested
    if (asString) {
      return bytesToString(decryptedBytes);
    }
    
    return decryptedBytes;
  } catch (error) {
    console.error('Error decrypting data:', error);
    throw new Error('Failed to decrypt data');
  }
}

/**
 * Encrypts data with a password
 * @param {string|Uint8Array} data - Data to encrypt
 * @param {string} password - Encryption password
 * @returns {Promise<Object>} Encrypted data with salt and IV
 */
async function encryptWithPassword(data, password) {
  try {
    // Generate salt
    const salt = generateRandomBytes(16);
    
    // Derive key from password
    const keyBytes = await deriveKey(password, salt);
    
    // Import key
    const key = await importKey(keyBytes);
    
    // Encrypt data
    const { encryptedData, iv } = await encryptData(data, key);
    
    // Return encrypted data with salt and IV
    return {
      encryptedData,
      salt,
      iv
    };
  } catch (error) {
    console.error('Error encrypting data with password:', error);
    throw new Error('Failed to encrypt data with password');
  }
}

/**
 * Decrypts data with a password
 * @param {Uint8Array} encryptedData - Encrypted data
 * @param {Uint8Array} salt - Salt used for key derivation
 * @param {Uint8Array} iv - Initialization vector
 * @param {string} password - Decryption password
 * @param {boolean} asString - Whether to return the result as a string
 * @returns {Promise<Uint8Array|string>} Decrypted data
 */
async function decryptWithPassword(encryptedData, salt, iv, password, asString = false) {
  try {
    // Derive key from password
    const keyBytes = await deriveKey(password, salt);
    
    // Import key
    const key = await importKey(keyBytes);
    
    // Decrypt data
    return await decryptData(encryptedData, iv, key, asString);
  } catch (error) {
    console.error('Error decrypting data with password:', error);
    throw new Error('Failed to decrypt data with password');
  }
}

/**
 * Encrypts an object to a string
 * @param {Object} obj - Object to encrypt
 * @param {string} password - Encryption password
 * @returns {Promise<string>} Encrypted string
 */
async function encryptObject(obj, password) {
  try {
    // Convert object to JSON string
    const jsonString = JSON.stringify(obj);
    
    // Encrypt data
    const { encryptedData, salt, iv } = await encryptWithPassword(jsonString, password);
    
    // Convert to base64
    const encryptedBase64 = bytesToBase64(encryptedData);
    const saltBase64 = bytesToBase64(salt);
    const ivBase64 = bytesToBase64(iv);
    
    // Combine into a single string
    return `${encryptedBase64}:${saltBase64}:${ivBase64}`;
  } catch (error) {
    console.error('Error encrypting object:', error);
    throw new Error('Failed to encrypt object');
  }
}

/**
 * Decrypts a string to an object
 * @param {string} encryptedString - Encrypted string
 * @param {string} password - Decryption password
 * @returns {Promise<Object>} Decrypted object
 */
async function decryptObject(encryptedString, password) {
  try {
    // Split string
    const [encryptedBase64, saltBase64, ivBase64] = encryptedString.split(':');
    
    // Convert from base64
    const encryptedData = base64ToBytes(encryptedBase64);
    const salt = base64ToBytes(saltBase64);
    const iv = base64ToBytes(ivBase64);
    
    // Decrypt data
    const jsonString = await decryptWithPassword(encryptedData, salt, iv, password, true);
    
    // Parse JSON
    return JSON.parse(jsonString);
  } catch (error) {
    console.error('Error decrypting object:', error);
    throw new Error('Failed to decrypt object');
  }
}

/**
 * Securely compares two strings in constant time
 * @param {string} a - First string
 * @param {string} b - Second string
 * @returns {boolean} Whether the strings are equal
 */
function secureCompare(a, b) {
  // Check if lengths are equal
  if (a.length !== b.length) {
    return false;
  }
  
  // Compare in constant time
  let result = 0;
  for (let i = 0; i < a.length; i++) {
    result |= a.charCodeAt(i) ^ b.charCodeAt(i);
  }
  
  return result === 0;
}

/**
 * Generates a secure password
 * @param {number} length - Password length
 * @param {Object} options - Password options
 * @returns {string} Generated password
 */
function generateSecurePassword(length = 16, options = {}) {
  // Default options
  const defaultOptions = {
    includeUppercase: true,
    includeLowercase: true,
    includeNumbers: true,
    includeSpecialChars: true,
    excludeSimilarChars: true
  };
  
  // Merge options
  const mergedOptions = { ...defaultOptions, ...options };
  
  // Define character sets
  const uppercaseChars = 'ABCDEFGHJKLMNPQRSTUVWXYZ'; // Excluding I and O
  const lowercaseChars = 'abcdefghijkmnpqrstuvwxyz'; // Excluding l and o
  const numberChars = '23456789'; // Excluding 0 and 1
  const specialChars = '!@#$%^&*()_+-=[]{}|;:,.<>?';
  
  // Define similar characters
  const similarChars = 'iIlLoO01';
  
  // Build character set
  let charset = '';
  
  if (mergedOptions.includeUppercase) {
    charset += mergedOptions.excludeSimilarChars ? uppercaseChars : 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';
  }
  
  if (mergedOptions.includeLowercase) {
    charset += mergedOptions.excludeSimilarChars ? lowercaseChars : 'abcdefghijklmnopqrstuvwxyz';
  }
  
  if (mergedOptions.includeNumbers) {
    charset += mergedOptions.excludeSimilarChars ? numberChars : '0123456789';
  }
  
  if (mergedOptions.includeSpecialChars) {
    charset += specialChars;
  }
  
  // Ensure charset is not empty
  if (charset.length === 0) {
    charset = lowercaseChars;
  }
  
  // Generate password
  let password = generateRandomString(length, charset);
  
  // Ensure password includes required character types
  const hasUppercase = /[A-Z]/.test(password);
  const hasLowercase = /[a-z]/.test(password);
  const hasNumber = /[0-9]/.test(password);
  const hasSpecialChar = /[^A-Za-z0-9]/.test(password);
  
  // Replace characters if needed
  if (mergedOptions.includeUppercase && !hasUppercase) {
    const pos = Math.floor(Math.random() * length);
    const char = mergedOptions.excludeSimilarChars ? uppercaseChars[Math.floor(Math.random() * uppercaseChars.length)] : 'ABCDEFGHIJKLMNOPQRSTUVWXYZ'[Math.floor(Math.random() * 26)];
    password = password.substring(0, pos) + char + password.substring(pos + 1);
  }
  
  if (mergedOptions.includeLowercase && !hasLowercase) {
    const pos = Math.floor(Math.random() * length);
    const char = mergedOptions.excludeSimilarChars ? lowercaseChars[Math.floor(Math.random() * lowercaseChars.length)] : 'abcdefghijklmnopqrstuvwxyz'[Math.floor(Math.random() * 26)];
    password = password.substring(0, pos) + char + password.substring(pos + 1);
  }
  
  if (mergedOptions.includeNumbers && !hasNumber) {
    const pos = Math.floor(Math.random() * length);
    const char = mergedOptions.excludeSimilarChars ? numberChars[Math.floor(Math.random() * numberChars.length)] : '0123456789'[Math.floor(Math.random() * 10)];
    password = password.substring(0, pos) + char + password.substring(pos + 1);
  }
  
  if (mergedOptions.includeSpecialChars && !hasSpecialChar) {
    const pos = Math.floor(Math.random() * length);
    const char = specialChars[Math.floor(Math.random() * specialChars.length)];
    password = password.substring(0, pos) + char + password.substring(pos + 1);
  }
  
  return password;
}

/**
 * Generates a mnemonic phrase
 * @param {number} wordCount - Number of words
 * @returns {string} Mnemonic phrase
 */
function generateMnemonic(wordCount = 12) {
  // BIP39 word list (English)
  const wordList = [
    "abandon", "ability", "able", "about", "above", "absent", "absorb", "abstract", "absurd", "abuse",
    "access", "accident", "account", "accuse", "achieve", "acid", "acoustic", "acquire", "across", "act",
    "action", "actor", "actress", "actual", "adapt", "add", "addict", "address", "adjust", "admit",
    "adult", "advance", "advice", "aerobic", "affair", "afford", "afraid", "again", "age", "agent",
    "agree", "ahead", "aim", "air", "airport", "aisle", "alarm", "album", "alcohol", "alert",
    "alien", "all", "alley", "allow", "almost", "alone", "alpha", "already", "also", "alter",
    "always", "amateur", "amazing", "among", "amount", "amused", "analyst", "anchor", "ancient", "anger",
    "angle", "angry", "animal", "ankle", "announce", "annual", "another", "answer", "antenna", "antique",
    "anxiety", "any", "apart", "apology", "appear", "apple", "approve", "april", "arch", "arctic",
    "area", "arena", "argue", "arm", "armed", "armor", "army", "around", "arrange", "arrest",
    "arrive", "arrow", "art", "artefact", "artist", "artwork", "ask", "aspect", "assault", "asset",
    "assist", "assume", "asthma", "athlete", "atom", "attack", "attend", "attitude", "attract", "auction",
    "audit", "august", "aunt", "author", "auto", "autumn", "average", "avocado", "avoid", "awake",
    "aware", "away", "awesome", "awful", "awkward", "axis", "baby", "bachelor", "bacon", "badge",
    "bag", "balance", "balcony", "ball", "bamboo", "banana", "banner", "bar", "barely", "bargain",
    "barrel", "base", "basic", "basket", "battle", "beach", "bean", "beauty", "because", "become",
    "beef", "before", "begin", "behave", "behind", "believe", "below", "belt", "bench", "benefit"
  ];
  
  // Generate random bytes
  const entropyBytes = generateRandomBytes(wordCount * 4 / 3);
  
  // Convert to binary string
  let binaryString = '';
  for (let i = 0; i < entropyBytes.length; i++) {
    binaryString += entropyBytes[i].toString(2).padStart(8, '0');
  }
  
  // Calculate checksum
  const checksumBits = Math.floor(entropyBytes.length * 8 / 32);
  const hashBytes = hashData(entropyBytes);
  let checksumBinary = '';
  for (let i = 0; i < Math.ceil(checksumBits / 8); i++) {
    checksumBinary += hashBytes[i].toString(2).padStart(8, '0');
  }
  checksumBinary = checksumBinary.slice(0, checksumBits);
  
  // Combine entropy and checksum
  const combinedBinary = binaryString + checksumBinary;
  
  // Split into 11-bit segments
  const words = [];
  for (let i = 0; i < wordCount; i++) {
    const wordIndex = parseInt(combinedBinary.slice(i * 11, (i + 1) * 11), 2);
    words.push(wordList[wordIndex]);
  }
  
  // Join words with spaces
  return words.join(' ');
}

// Export functions and constants
if (typeof module !== 'undefined' && module.exports) {
  module.exports = {
    EncryptionAlgorithms,
    HashAlgorithms,
    KeyDerivationAlgorithms,
    generateUUID,
    generateRandomString,
    generateRandomBytes,
    stringToBytes,
    bytesToString,
    bytesToHex,
    hexToBytes,
    bytesToBase64,
    base64ToBytes,
    hashData,
    deriveKey,
    generateEncryptionKey,
    exportKey,
    importKey,
    encryptData,
    decryptData,
    encryptWithPassword,
    decryptWithPassword,
    encryptObject,
    decryptObject,
    secureCompare,
    generateSecurePassword,
    generateMnemonic
  };
} else {
  // For browser environment
  window.cryptoUtils = {
    EncryptionAlgorithms,
    HashAlgorithms,
    KeyDerivationAlgorithms,
    generateUUID,
    generateRandomString,
    generateRandomBytes,
    stringToBytes,
    bytesToString,
    bytesToHex,
    hexToBytes,
    bytesToBase64,
    base64ToBytes,
    hashData,
    deriveKey,
    generateEncryptionKey,
    exportKey,
    importKey,
    encryptData,
    decryptData,
    encryptWithPassword,
    decryptWithPassword,
    encryptObject,
    decryptObject,
    secureCompare,
    generateSecurePassword,
    generateMnemonic
  };
}
