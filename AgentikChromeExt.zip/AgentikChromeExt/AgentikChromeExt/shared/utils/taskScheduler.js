/**
 * CryptoVoice - Task Scheduler Utilities
 * 
 * This file contains utility functions for scheduling and managing background tasks.
 */

/**
 * Task priorities
 * @enum {number}
 */
const TaskPriorities = {
  LOW: 0,
  NORMAL: 1,
  HIGH: 2,
  CRITICAL: 3
};

/**
 * Task statuses
 * @enum {string}
 */
const TaskStatuses = {
  PENDING: 'pending',
  RUNNING: 'running',
  COMPLETED: 'completed',
  FAILED: 'failed',
  CANCELED: 'canceled'
};

/**
 * Task types
 * @enum {string}
 */
const TaskTypes = {
  ONE_TIME: 'one_time',
  PERIODIC: 'periodic'
};

/**
 * Scheduled tasks
 * @type {Map<string, Object>}
 */
const tasks = new Map();

/**
 * Task timers
 * @type {Map<string, number>}
 */
const taskTimers = new Map();

/**
 * Generates a unique task ID
 * @returns {string} Task ID
 */
function generateTaskId() {
  return 'task_' + Math.random().toString(36).substring(2, 15) + 
         Math.random().toString(36).substring(2, 15) + 
         '_' + Date.now();
}

/**
 * Schedules a one-time task
 * @param {Function} taskFn - Task function
 * @param {number} delayMs - Delay in milliseconds
 * @param {Object} options - Task options
 * @returns {string} Task ID
 */
function scheduleTask(taskFn, delayMs, options = {}) {
  // Generate task ID
  const taskId = options.taskId || generateTaskId();
  
  // Create task object
  const task = {
    id: taskId,
    type: TaskTypes.ONE_TIME,
    fn: taskFn,
    delay: delayMs,
    priority: options.priority || TaskPriorities.NORMAL,
    status: TaskStatuses.PENDING,
    createdAt: Date.now(),
    scheduledAt: Date.now() + delayMs,
    lastRunAt: null,
    nextRunAt: Date.now() + delayMs,
    runCount: 0,
    maxRuns: 1,
    metadata: options.metadata || {},
    result: null,
    error: null
  };
  
  // Store task
  tasks.set(taskId, task);
  
  // Schedule task execution
  const timerId = setTimeout(() => {
    executeTask(taskId);
  }, delayMs);
  
  // Store timer ID
  taskTimers.set(taskId, timerId);
  
  // Persist tasks if needed
  if (options.persist !== false) {
    persistTasks();
  }
  
  return taskId;
}

/**
 * Schedules a periodic task
 * @param {Function} taskFn - Task function
 * @param {number} intervalMs - Interval in milliseconds
 * @param {Object} options - Task options
 * @returns {string} Task ID
 */
function schedulePeriodicTask(taskFn, intervalMs, options = {}) {
  // Generate task ID
  const taskId = options.taskId || generateTaskId();
  
  // Create task object
  const task = {
    id: taskId,
    type: TaskTypes.PERIODIC,
    fn: taskFn,
    interval: intervalMs,
    priority: options.priority || TaskPriorities.NORMAL,
    status: TaskStatuses.PENDING,
    createdAt: Date.now(),
    scheduledAt: Date.now() + (options.delayMs || 0),
    lastRunAt: null,
    nextRunAt: Date.now() + (options.delayMs || 0),
    runCount: 0,
    maxRuns: options.maxRuns || Infinity,
    metadata: options.metadata || {},
    result: null,
    error: null
  };
  
  // Store task
  tasks.set(taskId, task);
  
  // Schedule first execution
  const timerId = setTimeout(() => {
    executePeriodicTask(taskId);
  }, options.delayMs || 0);
  
  // Store timer ID
  taskTimers.set(taskId, timerId);
  
  // Persist tasks if needed
  if (options.persist !== false) {
    persistTasks();
  }
  
  return taskId;
}

/**
 * Executes a task
 * @param {string} taskId - Task ID
 * @returns {Promise<any>} Task result
 */
async function executeTask(taskId) {
  // Get task
  const task = tasks.get(taskId);
  
  // Skip if task doesn't exist or is not pending
  if (!task || task.status !== TaskStatuses.PENDING) {
    return null;
  }
  
  try {
    // Update task status
    task.status = TaskStatuses.RUNNING;
    task.lastRunAt = Date.now();
    task.runCount++;
    
    // Execute task function
    const result = await task.fn(task);
    
    // Update task status
    task.status = TaskStatuses.COMPLETED;
    task.result = result;
    
    // Clear timer
    clearTaskTimer(taskId);
    
    // Persist tasks
    persistTasks();
    
    return result;
  } catch (error) {
    // Update task status
    task.status = TaskStatuses.FAILED;
    task.error = error.message;
    
    // Clear timer
    clearTaskTimer(taskId);
    
    // Persist tasks
    persistTasks();
    
    // Log error
    console.error(`Error executing task ${taskId}:`, error);
    
    return null;
  }
}

/**
 * Executes a periodic task
 * @param {string} taskId - Task ID
 * @returns {Promise<any>} Task result
 */
async function executePeriodicTask(taskId) {
  // Get task
  const task = tasks.get(taskId);
  
  // Skip if task doesn't exist or is canceled
  if (!task || task.status === TaskStatuses.CANCELED) {
    return null;
  }
  
  try {
    // Update task status
    task.status = TaskStatuses.RUNNING;
    task.lastRunAt = Date.now();
    task.runCount++;
    
    // Execute task function
    const result = await task.fn(task);
    
    // Update task status and result
    task.status = TaskStatuses.PENDING;
    task.result = result;
    
    // Schedule next execution if not reached max runs
    if (task.runCount < task.maxRuns) {
      task.nextRunAt = Date.now() + task.interval;
      
      const timerId = setTimeout(() => {
        executePeriodicTask(taskId);
      }, task.interval);
      
      // Store timer ID
      taskTimers.set(taskId, timerId);
    } else {
      // Mark as completed if reached max runs
      task.status = TaskStatuses.COMPLETED;
      clearTaskTimer(taskId);
    }
    
    // Persist tasks
    persistTasks();
    
    return result;
  } catch (error) {
    // Update task status
    task.status = TaskStatuses.FAILED;
    task.error = error.message;
    
    // Schedule retry if not reached max runs
    if (task.runCount < task.maxRuns) {
      task.status = TaskStatuses.PENDING;
      task.nextRunAt = Date.now() + task.interval;
      
      const timerId = setTimeout(() => {
        executePeriodicTask(taskId);
      }, task.interval);
      
      // Store timer ID
      taskTimers.set(taskId, timerId);
    } else {
      // Clear timer if reached max runs
      clearTaskTimer(taskId);
    }
    
    // Persist tasks
    persistTasks();
    
    // Log error
    console.error(`Error executing periodic task ${taskId}:`, error);
    
    return null;
  }
}

/**
 * Cancels a task
 * @param {string} taskId - Task ID
 * @returns {boolean} Success status
 */
function cancelTask(taskId) {
  // Get task
  const task = tasks.get(taskId);
  
  // Skip if task doesn't exist
  if (!task) {
    return false;
  }
  
  // Update task status
  task.status = TaskStatuses.CANCELED;
  
  // Clear timer
  clearTaskTimer(taskId);
  
  // Persist tasks
  persistTasks();
  
  return true;
}

/**
 * Clears a task timer
 * @param {string} taskId - Task ID
 */
function clearTaskTimer(taskId) {
  // Get timer ID
  const timerId = taskTimers.get(taskId);
  
  // Clear timer if exists
  if (timerId) {
    clearTimeout(timerId);
    taskTimers.delete(taskId);
  }
}

/**
 * Gets a task by ID
 * @param {string} taskId - Task ID
 * @returns {Object|null} Task object or null if not found
 */
function getTask(taskId) {
  return tasks.get(taskId) || null;
}

/**
 * Gets all tasks
 * @param {Object} filters - Filters to apply
 * @returns {Array} Array of tasks
 */
function getAllTasks(filters = {}) {
  // Convert tasks map to array
  const taskArray = Array.from(tasks.values());
  
  // Apply filters
  return taskArray.filter(task => {
    // Filter by status
    if (filters.status && task.status !== filters.status) {
      return false;
    }
    
    // Filter by type
    if (filters.type && task.type !== filters.type) {
      return false;
    }
    
    // Filter by priority
    if (filters.priority !== undefined && task.priority !== filters.priority) {
      return false;
    }
    
    // Filter by metadata
    if (filters.metadata) {
      for (const [key, value] of Object.entries(filters.metadata)) {
        if (task.metadata[key] !== value) {
          return false;
        }
      }
    }
    
    return true;
  });
}

/**
 * Persists tasks to storage
 * @returns {Promise<boolean>} Success status
 */
async function persistTasks() {
  try {
    // Convert tasks to serializable format
    const serializableTasks = Array.from(tasks.entries())
      .filter(([_, task]) => task.persist !== false)
      .map(([id, task]) => {
        // Create a copy without the function
        const { fn, ...serializableTask } = task;
        return [id, serializableTask];
      });
    
    // Save to storage
    await new Promise((resolve, reject) => {
      chrome.storage.local.set({ 'cryptovoice_scheduled_tasks': serializableTasks }, () => {
        if (chrome.runtime.lastError) {
          reject(chrome.runtime.lastError);
        } else {
          resolve();
        }
      });
    });
    
    return true;
  } catch (error) {
    console.error('Error persisting tasks:', error);
    return false;
  }
}

/**
 * Loads tasks from storage
 * @returns {Promise<boolean>} Success status
 */
async function loadTasks() {
  try {
    // Load from storage
    const result = await new Promise((resolve, reject) => {
      chrome.storage.local.get('cryptovoice_scheduled_tasks', (result) => {
        if (chrome.runtime.lastError) {
          reject(chrome.runtime.lastError);
        } else {
          resolve(result);
        }
      });
    });
    
    // Skip if no tasks found
    if (!result.cryptovoice_scheduled_tasks) {
      return true;
    }
    
    // Clear existing tasks
    tasks.clear();
    
    // Clear existing timers
    for (const timerId of taskTimers.values()) {
      clearTimeout(timerId);
    }
    taskTimers.clear();
    
    // Restore tasks
    for (const [id, task] of result.cryptovoice_scheduled_tasks) {
      // Skip completed, failed, or canceled tasks
      if (task.status === TaskStatuses.COMPLETED || 
          task.status === TaskStatuses.FAILED || 
          task.status === TaskStatuses.CANCELED) {
        tasks.set(id, task);
        continue;
      }
      
      // Reset running tasks to pending
      if (task.status === TaskStatuses.RUNNING) {
        task.status = TaskStatuses.PENDING;
      }
      
      // Store task
      tasks.set(id, task);
      
      // Skip scheduling if no task function is registered
      if (!taskFunctions[task.metadata.functionName]) {
        continue;
      }
      
      // Restore task function
      task.fn = taskFunctions[task.metadata.functionName];
      
      // Schedule task execution
      if (task.type === TaskTypes.ONE_TIME) {
        const now = Date.now();
        const delay = Math.max(0, task.nextRunAt - now);
        
        const timerId = setTimeout(() => {
          executeTask(id);
        }, delay);
        
        taskTimers.set(id, timerId);
      } else if (task.type === TaskTypes.PERIODIC) {
        const now = Date.now();
        const delay = Math.max(0, task.nextRunAt - now);
        
        const timerId = setTimeout(() => {
          executePeriodicTask(id);
        }, delay);
        
        taskTimers.set(id, timerId);
      }
    }
    
    return true;
  } catch (error) {
    console.error('Error loading tasks:', error);
    return false;
  }
}

/**
 * Registered task functions
 * @type {Object}
 */
const taskFunctions = {};

/**
 * Registers a task function
 * @param {string} name - Function name
 * @param {Function} fn - Function implementation
 */
function registerTaskFunction(name, fn) {
  taskFunctions[name] = fn;
}

/**
 * Initializes the task scheduler
 * @returns {Promise<boolean>} Success status
 */
async function initTaskScheduler() {
  try {
    // Load tasks from storage
    await loadTasks();
    
    // Register event listeners
    chrome.runtime.onStartup.addListener(() => {
      loadTasks();
    });
    
    return true;
  } catch (error) {
    console.error('Error initializing task scheduler:', error);
    return false;
  }
}

// Initialize task scheduler when the module is loaded
if (typeof chrome !== 'undefined' && chrome.runtime) {
  initTaskScheduler().catch(console.error);
}

// Export functions and constants
if (typeof module !== 'undefined' && module.exports) {
  module.exports = {
    TaskPriorities,
    TaskStatuses,
    TaskTypes,
    scheduleTask,
    schedulePeriodicTask,
    cancelTask,
    getTask,
    getAllTasks,
    registerTaskFunction,
    initTaskScheduler
  };
} else {
  // For browser environment
  window.taskSchedulerUtils = {
    TaskPriorities,
    TaskStatuses,
    TaskTypes,
    scheduleTask,
    schedulePeriodicTask,
    cancelTask,
    getTask,
    getAllTasks,
    registerTaskFunction,
    initTaskScheduler
  };
}
