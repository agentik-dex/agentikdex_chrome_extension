/**
 * CryptoVoice - Voice Processing Utilities
 * 
 * This file contains utility functions for processing voice commands.
 */

/**
 * Processes a voice command to extract intent and entities
 * @param {string} command - The raw voice command
 * @returns {Object} Object containing intent and extracted entities
 */
function processVoiceCommand(command) {
  if (!command) {
    return {
      intent: 'unknown',
      entities: {},
      confidence: 0
    };
  }
  
  const lowerCommand = command.toLowerCase();
  
  // Check for balance inquiries
  if (containsAny(lowerCommand, ['balance', 'how much', 'what is my', 'worth'])) {
    return processBalanceCommand(lowerCommand);
  }
  
  // Check for send/transfer commands
  if (containsAny(lowerCommand, ['send', 'transfer', 'pay'])) {
    return processSendCommand(lowerCommand);
  }
  
  // Check for swap/exchange commands
  if (containsAny(lowerCommand, ['swap', 'exchange', 'trade', 'convert'])) {
    return processSwapCommand(lowerCommand);
  }
  
  // Check for transaction history commands
  if (containsAny(lowerCommand, ['history', 'transactions', 'recent', 'activity'])) {
    return processHistoryCommand(lowerCommand);
  }
  
  // Check for agent-related commands
  if (containsAny(lowerCommand, ['agent', 'trading', 'invest', 'portfolio'])) {
    return processAgentCommand(lowerCommand);
  }
  
  // Default to unknown intent
  return {
    intent: 'unknown',
    entities: {},
    confidence: 0.3,
    original: command
  };
}

/**
 * Processes a balance inquiry command
 * @param {string} command - The lowercase command
 * @returns {Object} Processed command with intent and entities
 */
function processBalanceCommand(command) {
  // Extract token if specified
  const tokenEntities = extractTokenEntities(command);
  
  return {
    intent: 'balance',
    entities: {
      token: tokenEntities.length > 0 ? tokenEntities[0] : null
    },
    confidence: tokenEntities.length > 0 ? 0.9 : 0.8,
    original: command
  };
}

/**
 * Processes a send/transfer command
 * @param {string} command - The lowercase command
 * @returns {Object} Processed command with intent and entities
 */
function processSendCommand(command) {
  // Extract amount
  const amountMatch = command.match(/(\d+(\.\d+)?)\s*([a-zA-Z]+)/);
  
  // Extract recipient
  const recipientMatch = command.match(/to\s+(0x[a-fA-F0-9]{40}|[a-zA-Z0-9]+)/);
  
  const amount = amountMatch ? parseFloat(amountMatch[1]) : null;
  const token = amountMatch ? amountMatch[3].toUpperCase() : null;
  const recipient = recipientMatch ? recipientMatch[1] : null;
  
  // Calculate confidence based on extracted entities
  let confidence = 0.5;
  if (amount !== null) confidence += 0.2;
  if (token !== null) confidence += 0.1;
  if (recipient !== null) confidence += 0.2;
  
  return {
    intent: 'send',
    entities: {
      amount,
      token,
      recipient
    },
    confidence,
    original: command
  };
}

/**
 * Processes a swap/exchange command
 * @param {string} command - The lowercase command
 * @returns {Object} Processed command with intent and entities
 */
function processSwapCommand(command) {
  // Extract from amount and token
  const fromMatch = command.match(/(\d+(\.\d+)?)\s*([a-zA-Z]+)/);
  
  // Extract to token
  const toMatch = command.match(/to\s+([a-zA-Z]+)/);
  
  const fromAmount = fromMatch ? parseFloat(fromMatch[1]) : null;
  const fromToken = fromMatch ? fromMatch[3].toUpperCase() : null;
  const toToken = toMatch ? mapTokenName(toMatch[1]) : null;
  
  // Calculate confidence based on extracted entities
  let confidence = 0.5;
  if (fromAmount !== null) confidence += 0.15;
  if (fromToken !== null) confidence += 0.15;
  if (toToken !== null) confidence += 0.2;
  
  return {
    intent: 'swap',
    entities: {
      fromAmount,
      fromToken,
      toToken
    },
    confidence,
    original: command
  };
}

/**
 * Processes a transaction history command
 * @param {string} command - The lowercase command
 * @returns {Object} Processed command with intent and entities
 */
function processHistoryCommand(command) {
  // Extract time period if specified
  const timeEntities = extractTimeEntities(command);
  
  // Extract token if specified
  const tokenEntities = extractTokenEntities(command);
  
  return {
    intent: 'history',
    entities: {
      period: timeEntities.length > 0 ? timeEntities[0] : 'recent',
      token: tokenEntities.length > 0 ? tokenEntities[0] : null
    },
    confidence: 0.85,
    original: command
  };
}

/**
 * Processes an agent-related command
 * @param {string} command - The lowercase command
 * @returns {Object} Processed command with intent and entities
 */
function processAgentCommand(command) {
  let subIntent = 'status';
  let entities = {};
  let confidence = 0.7;
  
  // Check for setup/create intent
  if (containsAny(command, ['create', 'setup', 'configure'])) {
    subIntent = 'setup';
    confidence = 0.85;
  }
  // Check for risk level configuration
  else if (command.includes('risk')) {
    subIntent = 'config';
    
    // Extract risk level
    let riskLevel = 'moderate';
    if (command.includes('conservative')) riskLevel = 'conservative';
    if (command.includes('aggressive')) riskLevel = 'aggressive';
    
    entities.setting = 'riskLevel';
    entities.value = riskLevel;
    confidence = 0.9;
  }
  // Check for target return configuration
  else if (containsAny(command, ['target', 'return', 'profit']) && 
           containsAny(command, ['percent', '%', 'monthly', 'yearly'])) {
    subIntent = 'config';
    
    // Extract percentage
    const percentMatch = command.match(/(\d+)%/);
    const percent = percentMatch ? parseInt(percentMatch[1]) : 5;
    
    entities.setting = 'targetReturn';
    entities.value = percent;
    confidence = 0.85;
  }
  // Check for control commands
  else if (containsAny(command, ['pause', 'stop', 'halt'])) {
    subIntent = 'control';
    entities.action = 'pause';
    confidence = 0.9;
  }
  else if (containsAny(command, ['resume', 'start', 'continue'])) {
    subIntent = 'control';
    entities.action = 'resume';
    confidence = 0.9;
  }
  // Default to status query
  else if (containsAny(command, ['status', 'performance', 'how', 'results'])) {
    subIntent = 'status';
    confidence = 0.8;
  }
  
  return {
    intent: 'agent_' + subIntent,
    entities,
    confidence,
    original: command
  };
}

/**
 * Extracts token entities from a command
 * @param {string} command - The command to extract from
 * @returns {string[]} Array of token symbols
 */
function extractTokenEntities(command) {
  const tokens = [];
  
  // Common token names and their symbols
  const tokenMap = {
    'ethereum': 'ETH',
    'ether': 'ETH',
    'eth': 'ETH',
    'bitcoin': 'BTC',
    'btc': 'BTC',
    'solana': 'SOL',
    'sol': 'SOL',
    'usdc': 'USDC',
    'usd coin': 'USDC',
    'tether': 'USDT',
    'usdt': 'USDT',
    'binance': 'BNB',
    'bnb': 'BNB',
    'cardano': 'ADA',
    'ada': 'ADA',
    'polygon': 'MATIC',
    'matic': 'MATIC'
  };
  
  // Check for token names in the command
  for (const [name, symbol] of Object.entries(tokenMap)) {
    if (command.includes(name)) {
      tokens.push(symbol);
    }
  }
  
  return tokens;
}

/**
 * Extracts time entities from a command
 * @param {string} command - The command to extract from
 * @returns {string[]} Array of time periods
 */
function extractTimeEntities(command) {
  const periods = [];
  
  // Time period mapping
  const periodMap = {
    'today': 'today',
    'yesterday': 'yesterday',
    'this week': 'week',
    'this month': 'month',
    'last week': 'last_week',
    'last month': 'last_month',
    'recent': 'recent'
  };
  
  // Check for time periods in the command
  for (const [phrase, period] of Object.entries(periodMap)) {
    if (command.includes(phrase)) {
      periods.push(period);
    }
  }
  
  return periods;
}

/**
 * Maps a token name to its symbol
 * @param {string} name - The token name
 * @returns {string} The token symbol
 */
function mapTokenName(name) {
  const lowerName = name.toLowerCase();
  
  if (lowerName.includes('ethereum') || lowerName.includes('ether')) {
    return 'ETH';
  } else if (lowerName.includes('bitcoin')) {
    return 'BTC';
  } else if (lowerName.includes('solana')) {
    return 'SOL';
  } else if (lowerName.includes('usd') && lowerName.includes('coin')) {
    return 'USDC';
  } else if (lowerName === 'usdc') {
    return 'USDC';
  } else if (lowerName.includes('tether') || lowerName === 'usdt') {
    return 'USDT';
  } else if (lowerName.includes('binance') || lowerName === 'bnb') {
    return 'BNB';
  } else if (lowerName.includes('cardano') || lowerName === 'ada') {
    return 'ADA';
  } else if (lowerName.includes('polygon') || lowerName === 'matic') {
    return 'MATIC';
  }
  
  // Return the original name capitalized if no match
  return name.toUpperCase();
}

/**
 * Checks if a string contains any of the specified phrases
 * @param {string} str - The string to check
 * @param {string[]} phrases - Array of phrases to look for
 * @returns {boolean} True if any phrase is found
 */
function containsAny(str, phrases) {
  return phrases.some(phrase => str.includes(phrase));
}

/**
 * Generates a speech response based on the command processing result
 * @param {Object} result - The processed command result
 * @returns {string} A natural language response
 */
function generateSpeechResponse(result) {
  switch (result.intent) {
    case 'balance':
      if (result.entities.token) {
        return `I'll check your ${result.entities.token} balance for you.`;
      } else {
        return `I'll check your wallet balance for you.`;
      }
      
    case 'send':
      if (result.entities.amount && result.entities.token && result.entities.recipient) {
        return `I'll prepare to send ${result.entities.amount} ${result.entities.token} to ${result.entities.recipient}.`;
      } else {
        return `I need more information to send funds. Please specify the amount, token, and recipient.`;
      }
      
    case 'swap':
      if (result.entities.fromAmount && result.entities.fromToken && result.entities.toToken) {
        return `I'll prepare to swap ${result.entities.fromAmount} ${result.entities.fromToken} to ${result.entities.toToken}.`;
      } else {
        return `I need more information to perform a swap. Please specify the amount, from token, and to token.`;
      }
      
    case 'history':
      if (result.entities.token) {
        return `I'll show your ${result.entities.token} transaction history.`;
      } else {
        return `I'll show your recent transaction history.`;
      }
      
    case 'agent_setup':
      return `Let's set up your trading agent. I'll help you configure your preferences.`;
      
    case 'agent_config':
      if (result.entities.setting === 'riskLevel') {
        return `I'll set your risk level to ${result.entities.value}.`;
      } else if (result.entities.setting === 'targetReturn') {
        return `I'll set your target return to ${result.entities.value}%.`;
      } else {
        return `I'll update your agent configuration.`;
      }
      
    case 'agent_control':
      if (result.entities.action === 'pause') {
        return `I'll pause your trading agent.`;
      } else if (result.entities.action === 'resume') {
        return `I'll resume your trading agent.`;
      } else {
        return `I'll adjust your trading agent as requested.`;
      }
      
    case 'agent_status':
      return `I'll check your trading agent's performance for you.`;
      
    default:
      return `I'm not sure what you're asking for. Could you please rephrase that?`;
  }
}

// Export functions
if (typeof module !== 'undefined' && module.exports) {
  module.exports = {
    processVoiceCommand,
    generateSpeechResponse,
    extractTokenEntities,
    extractTimeEntities,
    mapTokenName,
    containsAny
  };
} else {
  // For browser environment
  window.voiceProcessor = {
    processVoiceCommand,
    generateSpeechResponse,
    extractTokenEntities,
    extractTimeEntities,
    mapTokenName,
    containsAny
  };
}
