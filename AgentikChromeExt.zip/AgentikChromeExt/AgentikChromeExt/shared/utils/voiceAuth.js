/**
 * CryptoVoice - Voice Authentication Utilities
 * 
 * This file contains utility functions for voice-based biometric authentication.
 */

/**
 * Records audio for voice authentication
 * @param {number} duration - Recording duration in milliseconds
 * @returns {Promise<AudioBuffer>} Promise that resolves with the recorded audio
 */
async function recordVoiceAudio(duration = 3000) {
  // This is a simplified implementation
  // In a real implementation, this would use the Web Audio API more extensively
  
  return new Promise((resolve, reject) => {
    // Check if getUserMedia is supported
    if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
      reject(new Error('Audio recording not supported in this browser'));
      return;
    }
    
    // Request microphone access
    navigator.mediaDevices.getUserMedia({ audio: true, video: false })
      .then(stream => {
        // Create audio context
        const audioContext = new (window.AudioContext || window.webkitAudioContext)();
        const audioChunks = [];
        
        // Create media recorder
        const mediaRecorder = new MediaRecorder(stream);
        
        // Set up data handler
        mediaRecorder.ondataavailable = (event) => {
          if (event.data.size > 0) {
            audioChunks.push(event.data);
          }
        };
        
        // Set up stop handler
        mediaRecorder.onstop = () => {
          // Stop all tracks
          stream.getTracks().forEach(track => track.stop());
          
          // Create blob from chunks
          const audioBlob = new Blob(audioChunks, { type: 'audio/wav' });
          
          // Convert blob to array buffer
          const fileReader = new FileReader();
          fileReader.onloadend = () => {
            // Decode audio data
            audioContext.decodeAudioData(fileReader.result)
              .then(audioBuffer => {
                resolve(audioBuffer);
              })
              .catch(error => {
                reject(error);
              });
          };
          
          fileReader.onerror = () => {
            reject(new Error('Error reading audio data'));
          };
          
          fileReader.readAsArrayBuffer(audioBlob);
        };
        
        // Start recording
        mediaRecorder.start();
        
        // Stop after duration
        setTimeout(() => {
          if (mediaRecorder.state !== 'inactive') {
            mediaRecorder.stop();
          }
        }, duration);
      })
      .catch(error => {
        reject(error);
      });
  });
}

/**
 * Extracts voice features from audio data for authentication
 * @param {AudioBuffer} audioBuffer - Recorded audio buffer
 * @returns {Float32Array} Extracted features
 */
function extractVoiceFeatures(audioBuffer) {
  // This is a simplified implementation
  // In a real implementation, this would use MFCC, spectral features, etc.
  
  if (!audioBuffer) {
    return new Float32Array(20);
  }
  
  try {
    // Get audio data
    const audioData = audioBuffer.getChannelData(0);
    
    // Extract simple features (in reality, these would be more sophisticated)
    const features = new Float32Array(20);
    
    // 1. Energy (average amplitude)
    features[0] = calculateEnergy(audioData);
    
    // 2. Zero crossing rate
    features[1] = calculateZeroCrossingRate(audioData);
    
    // 3. Spectral centroid (simplified)
    features[2] = calculateSpectralCentroid(audioData);
    
    // 4-20. Fill with random values for demonstration
    // In a real implementation, these would be meaningful features
    for (let i = 3; i < 20; i++) {
      features[i] = Math.random();
    }
    
    return features;
  } catch (error) {
    console.error('Error extracting voice features:', error);
    return new Float32Array(20);
  }
}

/**
 * Calculates energy (average amplitude) of audio data
 * @param {Float32Array} audioData - Audio data
 * @returns {number} Energy value
 */
function calculateEnergy(audioData) {
  if (!audioData || audioData.length === 0) {
    return 0;
  }
  
  let sum = 0;
  for (let i = 0; i < audioData.length; i++) {
    sum += Math.abs(audioData[i]);
  }
  
  return sum / audioData.length;
}

/**
 * Calculates zero crossing rate of audio data
 * @param {Float32Array} audioData - Audio data
 * @returns {number} Zero crossing rate
 */
function calculateZeroCrossingRate(audioData) {
  if (!audioData || audioData.length <= 1) {
    return 0;
  }
  
  let crossings = 0;
  for (let i = 1; i < audioData.length; i++) {
    if ((audioData[i] >= 0 && audioData[i - 1] < 0) || 
        (audioData[i] < 0 && audioData[i - 1] >= 0)) {
      crossings++;
    }
  }
  
  return crossings / (audioData.length - 1);
}

/**
 * Calculates spectral centroid of audio data (simplified)
 * @param {Float32Array} audioData - Audio data
 * @returns {number} Spectral centroid
 */
function calculateSpectralCentroid(audioData) {
  if (!audioData || audioData.length === 0) {
    return 0;
  }
  
  // This is a very simplified version
  // In reality, this would involve FFT and weighted frequency calculations
  
  // For demonstration, return a value based on the audio characteristics
  let sum = 0;
  let weightedSum = 0;
  
  for (let i = 0; i < audioData.length; i++) {
    const weight = i / audioData.length; // Simple weight based on position
    weightedSum += Math.abs(audioData[i]) * weight;
    sum += Math.abs(audioData[i]);
  }
  
  return sum > 0 ? weightedSum / sum : 0;
}

/**
 * Creates a voice profile from multiple audio samples
 * @param {AudioBuffer[]} audioSamples - Array of audio samples
 * @returns {Object} Voice profile
 */
function createVoiceProfile(audioSamples) {
  if (!audioSamples || audioSamples.length === 0) {
    return null;
  }
  
  try {
    // Extract features from each sample
    const featuresList = audioSamples.map(sample => extractVoiceFeatures(sample));
    
    // Average the features
    const averageFeatures = new Float32Array(20);
    for (let i = 0; i < 20; i++) {
      let sum = 0;
      for (let j = 0; j < featuresList.length; j++) {
        sum += featuresList[j][i];
      }
      averageFeatures[i] = sum / featuresList.length;
    }
    
    // Create profile
    return {
      features: Array.from(averageFeatures),
      createdAt: new Date().toISOString(),
      sampleCount: audioSamples.length
    };
  } catch (error) {
    console.error('Error creating voice profile:', error);
    return null;
  }
}

/**
 * Verifies a voice sample against a stored profile
 * @param {AudioBuffer} audioSample - Audio sample to verify
 * @param {Object} voiceProfile - Stored voice profile
 * @param {number} threshold - Similarity threshold (0-1)
 * @returns {Object} Verification result
 */
function verifyVoice(audioSample, voiceProfile, threshold = 0.7) {
  if (!audioSample || !voiceProfile || !voiceProfile.features) {
    return {
      verified: false,
      confidence: 0,
      reason: 'Invalid sample or profile'
    };
  }
  
  try {
    // Extract features from sample
    const sampleFeatures = extractVoiceFeatures(audioSample);
    
    // Convert profile features to Float32Array
    const profileFeatures = new Float32Array(voiceProfile.features);
    
    // Calculate similarity
    const similarity = calculateCosineSimilarity(sampleFeatures, profileFeatures);
    
    // Determine verification result
    const verified = similarity >= threshold;
    
    return {
      verified,
      confidence: similarity,
      reason: verified 
        ? 'Voice pattern matched stored profile'
        : 'Voice pattern did not match stored profile'
    };
  } catch (error) {
    console.error('Error verifying voice:', error);
    return {
      verified: false,
      confidence: 0,
      reason: 'Error during verification: ' + error.message
    };
  }
}

/**
 * Calculates cosine similarity between two feature vectors
 * @param {Float32Array} featuresA - First feature vector
 * @param {Float32Array} featuresB - Second feature vector
 * @returns {number} Similarity score (0-1)
 */
function calculateCosineSimilarity(featuresA, featuresB) {
  if (!featuresA || !featuresB || featuresA.length !== featuresB.length) {
    return 0;
  }
  
  let dotProduct = 0;
  let normA = 0;
  let normB = 0;
  
  for (let i = 0; i < featuresA.length; i++) {
    dotProduct += featuresA[i] * featuresB[i];
    normA += featuresA[i] * featuresA[i];
    normB += featuresB[i] * featuresB[i];
  }
  
  if (normA === 0 || normB === 0) {
    return 0;
  }
  
  return dotProduct / (Math.sqrt(normA) * Math.sqrt(normB));
}

/**
 * Enrolls a user with a new voice profile
 * @param {number} sampleCount - Number of samples to record
 * @param {number} sampleDuration - Duration of each sample in milliseconds
 * @param {Function} progressCallback - Callback for enrollment progress
 * @returns {Promise<Object>} Promise that resolves with the created profile
 */
async function enrollVoiceProfile(sampleCount = 3, sampleDuration = 3000, progressCallback = null) {
  try {
    const samples = [];
    
    // Record multiple samples
    for (let i = 0; i < sampleCount; i++) {
      // Update progress
      if (progressCallback) {
        progressCallback({
          step: i + 1,
          totalSteps: sampleCount,
          message: `Recording sample ${i + 1} of ${sampleCount}...`
        });
      }
      
      // Record sample
      const sample = await recordVoiceAudio(sampleDuration);
      samples.push(sample);
      
      // Wait between samples
      if (i < sampleCount - 1) {
        await new Promise(resolve => setTimeout(resolve, 1000));
      }
    }
    
    // Update progress
    if (progressCallback) {
      progressCallback({
        step: sampleCount + 1,
        totalSteps: sampleCount + 1,
        message: 'Creating voice profile...'
      });
    }
    
    // Create profile
    const profile = createVoiceProfile(samples);
    
    return profile;
  } catch (error) {
    console.error('Error enrolling voice profile:', error);
    throw error;
  }
}

/**
 * Simulates voice authentication for demonstration purposes
 * @param {string} phrase - Phrase spoken by the user
 * @param {Object} storedProfile - Stored voice profile
 * @returns {Object} Authentication result
 */
function simulateVoiceAuth(phrase, storedProfile) {
  // This is a simplified implementation for demonstration
  // In a real implementation, this would use actual voice biometrics
  
  if (!phrase || !storedProfile) {
    return {
      authenticated: false,
      confidence: 0,
      reason: 'Invalid input'
    };
  }
  
  // Generate a deterministic but seemingly random confidence score
  // based on the phrase and stored profile
  let confidence = 0;
  
  // If the phrase contains "hey cryptovoice", increase confidence
  if (phrase.toLowerCase().includes('hey cryptovoice')) {
    confidence += 0.4;
  }
  
  // Add some randomness, but weighted toward success for demo purposes
  confidence += Math.random() * 0.4 + 0.2;
  
  // Cap at 1.0
  confidence = Math.min(1.0, confidence);
  
  // Determine authentication result
  const authenticated = confidence >= 0.7;
  
  return {
    authenticated,
    confidence,
    reason: authenticated 
      ? 'Voice authenticated successfully'
      : 'Voice authentication failed'
  };
}

// Export functions
if (typeof module !== 'undefined' && module.exports) {
  module.exports = {
    recordVoiceAudio,
    extractVoiceFeatures,
    createVoiceProfile,
    verifyVoice,
    calculateCosineSimilarity,
    enrollVoiceProfile,
    simulateVoiceAuth
  };
} else {
  // For browser environment
  window.voiceAuthUtils = {
    recordVoiceAudio,
    extractVoiceFeatures,
    createVoiceProfile,
    verifyVoice,
    calculateCosineSimilarity,
    enrollVoiceProfile,
    simulateVoiceAuth
  };
}
