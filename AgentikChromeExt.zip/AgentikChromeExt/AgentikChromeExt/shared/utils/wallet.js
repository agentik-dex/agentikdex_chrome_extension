/**
 * CryptoVoice - Wallet Utilities
 * 
 * This file contains utility functions for wallet operations.
 */

/**
 * Formats an address for display by showing only the first and last few characters
 * @param {string} address - The full wallet address
 * @param {number} [prefixLength=6] - Number of characters to show at the beginning
 * @param {number} [suffixLength=4] - Number of characters to show at the end
 * @returns {string} Formatted address (e.g., "0x1234...5678")
 */
function formatAddress(address, prefixLength = 6, suffixLength = 4) {
  if (!address || address.length < (prefixLength + suffixLength + 3)) {
    return address || '';
  }
  
  const prefix = address.substring(0, prefixLength);
  const suffix = address.substring(address.length - suffixLength);
  
  return `${prefix}...${suffix}`;
}

/**
 * Formats a token amount for display with appropriate decimal places
 * @param {number} amount - The token amount
 * @param {number} [decimals=4] - Maximum decimal places to show
 * @returns {string} Formatted amount
 */
function formatTokenAmount(amount, decimals = 4) {
  if (typeof amount !== 'number') {
    return '0';
  }
  
  // For very small amounts, show more decimals
  if (amount > 0 && amount < 0.0001) {
    return amount.toExponential(2);
  }
  
  // For larger amounts, limit decimals based on size
  if (amount >= 1000) {
    return amount.toLocaleString('en-US', { maximumFractionDigits: 2 });
  } else if (amount >= 1) {
    return amount.toLocaleString('en-US', { maximumFractionDigits: decimals });
  } else {
    // For amounts between 0 and 1, show more precision
    return amount.toLocaleString('en-US', { maximumFractionDigits: decimals + 2 });
  }
}

/**
 * Formats a USD value for display
 * @param {number} value - The USD value
 * @returns {string} Formatted value with $ symbol
 */
function formatUsdValue(value) {
  if (typeof value !== 'number') {
    return '$0.00';
  }
  
  return '$' + value.toLocaleString('en-US', { 
    minimumFractionDigits: 2,
    maximumFractionDigits: 2
  });
}

/**
 * Validates an Ethereum address
 * @param {string} address - The address to validate
 * @returns {boolean} Whether the address is valid
 */
function isValidEthereumAddress(address) {
  return /^0x[a-fA-F0-9]{40}$/.test(address);
}

/**
 * Validates a Solana address
 * @param {string} address - The address to validate
 * @returns {boolean} Whether the address is valid
 */
function isValidSolanaAddress(address) {
  // Solana addresses are base58 encoded and typically 32-44 characters
  return /^[1-9A-HJ-NP-Za-km-z]{32,44}$/.test(address);
}

/**
 * Gets the network type from an address
 * @param {string} address - The wallet address
 * @returns {string|null} Network type or null if unknown
 */
function getNetworkFromAddress(address) {
  if (!address) return null;
  
  if (isValidEthereumAddress(address)) {
    return 'ethereum';
  } else if (isValidSolanaAddress(address)) {
    return 'solana';
  }
  
  return null;
}

/**
 * Generates a mock wallet address for demonstration purposes
 * @param {string} [network='ethereum'] - The network type
 * @returns {string} A mock wallet address
 */
function generateMockAddress(network = 'ethereum') {
  if (network === 'ethereum') {
    let address = '0x';
    for (let i = 0; i < 40; i++) {
      address += '0123456789abcdef'[Math.floor(Math.random() * 16)];
    }
    return address;
  } else if (network === 'solana') {
    const base58Chars = '123456789ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz';
    let address = '';
    for (let i = 0; i < 44; i++) {
      address += base58Chars[Math.floor(Math.random() * base58Chars.length)];
    }
    return address;
  }
  
  return '';
}

// Export functions
if (typeof module !== 'undefined' && module.exports) {
  module.exports = {
    formatAddress,
    formatTokenAmount,
    formatUsdValue,
    isValidEthereumAddress,
    isValidSolanaAddress,
    getNetworkFromAddress,
    generateMockAddress
  };
} else {
  // For browser environment
  window.walletUtils = {
    formatAddress,
    formatTokenAmount,
    formatUsdValue,
    isValidEthereumAddress,
    isValidSolanaAddress,
    getNetworkFromAddress,
    generateMockAddress
  };
}
