/**
 * CryptoVoice - Storage Utilities
 * 
 * This file contains utility functions for persistent storage operations.
 */

/**
 * Saves data to Chrome's local storage
 * @param {string} key - Storage key
 * @param {any} data - Data to store
 * @returns {Promise<void>} Promise that resolves when data is saved
 */
function saveToStorage(key, data) {
  return new Promise((resolve, reject) => {
    try {
      const storageData = {};
      storageData[key] = data;
      
      chrome.storage.local.set(storageData, () => {
        if (chrome.runtime.lastError) {
          reject(chrome.runtime.lastError);
        } else {
          resolve();
        }
      });
    } catch (error) {
      reject(error);
    }
  });
}

/**
 * Loads data from Chrome's local storage
 * @param {string} key - Storage key
 * @returns {Promise<any>} Promise that resolves with the loaded data
 */
function loadFromStorage(key) {
  return new Promise((resolve, reject) => {
    try {
      chrome.storage.local.get(key, (result) => {
        if (chrome.runtime.lastError) {
          reject(chrome.runtime.lastError);
        } else {
          resolve(result[key]);
        }
      });
    } catch (error) {
      reject(error);
    }
  });
}

/**
 * Removes data from Chrome's local storage
 * @param {string} key - Storage key to remove
 * @returns {Promise<void>} Promise that resolves when data is removed
 */
function removeFromStorage(key) {
  return new Promise((resolve, reject) => {
    try {
      chrome.storage.local.remove(key, () => {
        if (chrome.runtime.lastError) {
          reject(chrome.runtime.lastError);
        } else {
          resolve();
        }
      });
    } catch (error) {
      reject(error);
    }
  });
}

/**
 * Clears all data from Chrome's local storage
 * @returns {Promise<void>} Promise that resolves when storage is cleared
 */
function clearStorage() {
  return new Promise((resolve, reject) => {
    try {
      chrome.storage.local.clear(() => {
        if (chrome.runtime.lastError) {
          reject(chrome.runtime.lastError);
        } else {
          resolve();
        }
      });
    } catch (error) {
      reject(error);
    }
  });
}

/**
 * Saves wallet state to storage
 * @param {Object} walletState - Wallet state object
 * @returns {Promise<void>} Promise that resolves when data is saved
 */
function saveWalletState(walletState) {
  return saveToStorage('walletState', walletState);
}

/**
 * Loads wallet state from storage
 * @returns {Promise<Object>} Promise that resolves with wallet state
 */
function loadWalletState() {
  return loadFromStorage('walletState');
}

/**
 * Saves agent state to storage
 * @param {Object} agentState - Agent state object
 * @returns {Promise<void>} Promise that resolves when data is saved
 */
function saveAgentState(agentState) {
  return saveToStorage('agentState', agentState);
}

/**
 * Loads agent state from storage
 * @returns {Promise<Object>} Promise that resolves with agent state
 */
function loadAgentState() {
  return loadFromStorage('agentState');
}

/**
 * Saves user preferences to storage
 * @param {Object} preferences - User preferences object
 * @returns {Promise<void>} Promise that resolves when data is saved
 */
function saveUserPreferences(preferences) {
  return saveToStorage('userPreferences', preferences);
}

/**
 * Loads user preferences from storage
 * @returns {Promise<Object>} Promise that resolves with user preferences
 */
function loadUserPreferences() {
  return loadFromStorage('userPreferences');
}

/**
 * Saves voice profile to storage
 * @param {Object} voiceProfile - Voice profile object
 * @returns {Promise<void>} Promise that resolves when data is saved
 */
function saveVoiceProfile(voiceProfile) {
  return saveToStorage('voiceProfile', voiceProfile);
}

/**
 * Loads voice profile from storage
 * @returns {Promise<Object>} Promise that resolves with voice profile
 */
function loadVoiceProfile() {
  return loadFromStorage('voiceProfile');
}

/**
 * Initializes default storage values if they don't exist
 * @returns {Promise<void>} Promise that resolves when initialization is complete
 */
async function initializeStorage() {
  try {
    // Check if wallet state exists
    const walletState = await loadWalletState();
    if (!walletState) {
      // Initialize with default wallet state
      await saveWalletState({
        connected: false,
        address: null,
        network: null,
        balances: {},
        transactions: []
      });
    }
    
    // Check if agent state exists
    const agentState = await loadAgentState();
    if (!agentState) {
      // Initialize with default agent state
      await saveAgentState({
        active: false,
        riskProfile: 'moderate',
        dailyLimit: 1000,
        targetReturn: 5,
        allowedAssets: ['BTC', 'ETH', 'SOL', 'USDC', 'USDT'],
        lastDecision: null,
        performance: {
          dailyProfit: 0,
          weeklyProfit: 0,
          monthlyProfit: 0,
          activePositions: 0
        }
      });
    }
    
    // Check if user preferences exist
    const userPreferences = await loadUserPreferences();
    if (!userPreferences) {
      // Initialize with default user preferences
      await saveUserPreferences({
        theme: 'light',
        language: 'en',
        notifications: true,
        autoLock: true,
        lockTimeout: 5, // minutes
        defaultNetwork: 'ethereum',
        useWhitelist: false,
        whitelist: [],
        allowedTransactionTypes: ['send', 'swap'],
        allowedTokens: []
      });
    }
    
    return true;
  } catch (error) {
    console.error('Failed to initialize storage:', error);
    return false;
  }
}

// Export functions
if (typeof module !== 'undefined' && module.exports) {
  module.exports = {
    saveToStorage,
    loadFromStorage,
    removeFromStorage,
    clearStorage,
    saveWalletState,
    loadWalletState,
    saveAgentState,
    loadAgentState,
    saveUserPreferences,
    loadUserPreferences,
    saveVoiceProfile,
    loadVoiceProfile,
    initializeStorage
  };
} else {
  // For browser environment
  window.storageUtils = {
    saveToStorage,
    loadFromStorage,
    removeFromStorage,
    clearStorage,
    saveWalletState,
    loadWalletState,
    saveAgentState,
    loadAgentState,
    saveUserPreferences,
    loadUserPreferences,
    saveVoiceProfile,
    loadVoiceProfile,
    initializeStorage
  };
}
