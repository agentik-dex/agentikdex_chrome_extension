/**
 * Agentik Wallet - Internationalization (i18n) Utilities
 * 
 * This file contains utility functions for handling internationalization and localization.
 */

/**
 * Default language for the extension
 * @type {string}
 */
const DEFAULT_LANGUAGE = 'en';

/**
 * Supported languages
 * @type {Object}
 */
const SUPPORTED_LANGUAGES = {
  en: 'English',
  es: 'Español',
  fr: 'Français',
  de: 'Deutsch',
  ja: '日本語',
  zh: '中文',
  ko: '한국어',
  ru: 'Русский'
};

/**
 * Translation keys for all supported languages
 * This is a simplified mock implementation. In a real extension, translations would be
 * loaded from separate JSON files or from Chrome's i18n API.
 * @type {Object}
 */
const TRANSLATIONS = {
  // English translations (default)
  en: {
    // General
    'app_name': 'Agentik Wallet',
    'loading': 'Loading...',
    'save': 'Save',
    'cancel': 'Cancel',
    'confirm': 'Confirm',
    'delete': 'Delete',
    'edit': 'Edit',
    'back': 'Back',
    'next': 'Next',
    'done': 'Done',
    'error': 'Error',
    'success': 'Success',
    'warning': 'Warning',
    'info': 'Information',
    
    // Wallet
    'wallet_connect': 'Connect Wallet',
    'wallet_disconnect': 'Disconnect Wallet',
    'wallet_balance': 'Balance',
    'wallet_send': 'Send',
    'wallet_receive': 'Receive',
    'wallet_swap': 'Swap',
    'wallet_history': 'Transaction History',
    'wallet_tokens': 'Tokens',
    'wallet_networks': 'Networks',
    'wallet_address': 'Wallet Address',
    'wallet_copy_address': 'Copy Address',
    'wallet_address_copied': 'Address copied to clipboard',
    'wallet_total_value': 'Total Value',
    
    // Voice Commands
    'voice_listening': 'Listening...',
    'voice_processing': 'Processing...',
    'voice_command_recognized': 'Command recognized',
    'voice_command_not_recognized': 'Command not recognized',
    'voice_wake_word': 'Say "Hey Agentik" to start',
    'voice_command_examples': 'Example commands',
    'voice_command_help': 'Voice Command Help',
    'voice_auth_required': 'Voice authentication required',
    'voice_auth_success': 'Voice authenticated',
    'voice_auth_failed': 'Voice authentication failed',
    'voice_enroll': 'Enroll your voice',
    'voice_enroll_instructions': 'Please repeat the following phrases',
    
    // Trading Agent
    'agent_status': 'Agent Status',
    'agent_enable': 'Enable Trading Agent',
    'agent_disable': 'Disable Trading Agent',
    'agent_risk_profile': 'Risk Profile',
    'agent_conservative': 'Conservative',
    'agent_moderate': 'Moderate',
    'agent_aggressive': 'Aggressive',
    'agent_decisions': 'Trading Decisions',
    'agent_performance': 'Agent Performance',
    'agent_settings': 'Agent Settings',
    'agent_no_decisions': 'No trading decisions yet',
    'agent_decision_details': 'Decision Details',
    
    // DeFi Platforms
    'defi_detected': 'DeFi platform detected',
    'defi_connect': 'Connect to {{platform}}',
    'defi_swap_details': 'Swap Details',
    'defi_lending_details': 'Lending Details',
    'defi_approve_token': 'Approve Token',
    'defi_slippage': 'Slippage Tolerance',
    'defi_gas_price': 'Gas Price',
    'defi_transaction_details': 'Transaction Details',
    'defi_liquidity': 'Liquidity',
    'defi_platforms': 'DeFi Platforms',
    
    // Settings
    'settings_title': 'Settings',
    'settings_general': 'General',
    'settings_voice': 'Voice',
    'settings_wallet': 'Wallet',
    'settings_agent': 'Trading Agent',
    'settings_defi': 'DeFi',
    'settings_security': 'Security',
    'settings_advanced': 'Advanced',
    'settings_language': 'Language',
    'settings_theme': 'Theme',
    'settings_notifications': 'Notifications',
    'settings_reset': 'Reset Settings',
    'settings_export': 'Export Settings',
    'settings_import': 'Import Settings',
    
    // Security
    'security_title': 'Security',
    'security_permissions': 'Permissions',
    'security_transaction_limits': 'Transaction Limits',
    'security_voice_auth': 'Voice Authentication',
    'security_logout': 'Logout',
    'security_clear_data': 'Clear Data',
    'security_backup': 'Backup',
    'security_restore': 'Restore',
    'security_warning': 'Security Warning',
    
    // Errors
    'error_network': 'Network error. Please check your connection.',
    'error_transaction': 'Transaction failed. Please try again.',
    'error_wallet_connection': 'Failed to connect wallet. Please try again.',
    'error_insufficient_funds': 'Insufficient funds for this transaction.',
    'error_voice_recognition': 'Voice recognition error. Please try again.',
    'error_permission_denied': 'Permission denied. Please check your settings.',
    'error_unknown': 'An unknown error occurred. Please try again.',
    
    // Notifications
    'notification_transaction_sent': 'Transaction sent',
    'notification_transaction_confirmed': 'Transaction confirmed',
    'notification_transaction_failed': 'Transaction failed',
    'notification_agent_decision': 'Trading agent made a decision',
    'notification_price_alert': 'Price alert',
    'notification_wallet_connected': 'Wallet connected',
    'notification_wallet_disconnected': 'Wallet disconnected',
    
    // Time and Date
    'time_now': 'now',
    'time_minute_ago': '1 minute ago',
    'time_minutes_ago': '{{count}} minutes ago',
    'time_hour_ago': '1 hour ago',
    'time_hours_ago': '{{count}} hours ago',
    'time_day_ago': '1 day ago',
    'time_days_ago': '{{count}} days ago',
    'time_week_ago': '1 week ago',
    'time_weeks_ago': '{{count}} weeks ago',
    
    // Tokens and Amounts
    'amount_max': 'Max',
    'amount_enter': 'Enter amount',
    'token_select': 'Select token',
    'token_balance': 'Balance: {{amount}}',
    'token_value': 'Value: {{value}}',
    'token_price': 'Price: {{price}}',
    'token_24h_change': '24h: {{change}}',
  },
  
  // Spanish translations (simplified example)
  es: {
    'app_name': 'Agentik Wallet',
    'loading': 'Cargando...',
    'save': 'Guardar',
    'cancel': 'Cancelar',
    'confirm': 'Confirmar',
    'delete': 'Eliminar',
    'edit': 'Editar',
    'back': 'Atrás',
    'next': 'Siguiente',
    'done': 'Hecho',
    'error': 'Error',
    'success': 'Éxito',
    'warning': 'Advertencia',
    'info': 'Información',
    
    // Wallet
    'wallet_connect': 'Conectar Billetera',
    'wallet_disconnect': 'Desconectar Billetera',
    'wallet_balance': 'Saldo',
    'wallet_send': 'Enviar',
    'wallet_receive': 'Recibir',
    'wallet_swap': 'Intercambiar',
    'wallet_history': 'Historial de Transacciones',
    'wallet_tokens': 'Tokens',
    'wallet_networks': 'Redes',
    'wallet_address': 'Dirección de Billetera',
    'wallet_copy_address': 'Copiar Dirección',
    'wallet_address_copied': 'Dirección copiada al portapapeles',
    'wallet_total_value': 'Valor Total',
    
    // More translations would be added here...
  },
  
  // Other languages would follow the same pattern
};

/**
 * Gets the current language from storage
 * @returns {Promise<string>} Current language code
 */
async function getCurrentLanguage() {
  try {
    // Try to get language from config manager if available
    if (typeof window.configManagerUtils !== 'undefined' && 
        typeof window.configManagerUtils.getConfigValue === 'function') {
      const language = await window.configManagerUtils.getConfigValue('general', 'language');
      if (language && SUPPORTED_LANGUAGES[language]) {
        return language;
      }
    }
    
    // Fallback to Chrome storage
    return await new Promise((resolve) => {
      chrome.storage.local.get('cryptovoice_language', (result) => {
        const language = result.cryptovoice_language;
        resolve(language && SUPPORTED_LANGUAGES[language] ? language : DEFAULT_LANGUAGE);
      });
    });
  } catch (error) {
    console.error('Error getting current language:', error);
    return DEFAULT_LANGUAGE;
  }
}

/**
 * Sets the current language
 * @param {string} language - Language code
 * @returns {Promise<boolean>} Success status
 */
async function setLanguage(language) {
  try {
    // Validate language
    if (!SUPPORTED_LANGUAGES[language]) {
      throw new Error(`Unsupported language: ${language}`);
    }
    
    // Try to set language in config manager if available
    if (typeof window.configManagerUtils !== 'undefined' && 
        typeof window.configManagerUtils.updateConfigValue === 'function') {
      await window.configManagerUtils.updateConfigValue('general', 'language', language);
    }
    
    // Also set in Chrome storage for components that might not use config manager
    await new Promise((resolve, reject) => {
      chrome.storage.local.set({ 'cryptovoice_language': language }, () => {
        if (chrome.runtime.lastError) {
          reject(chrome.runtime.lastError);
        } else {
          resolve();
        }
      });
    });
    
    // Notify about language change
    notifyLanguageChanged(language);
    
    return true;
  } catch (error) {
    console.error('Error setting language:', error);
    return false;
  }
}

/**
 * Gets a translated string for the current language
 * @param {string} key - Translation key
 * @param {Object} params - Parameters for interpolation
 * @returns {Promise<string>} Translated string
 */
async function getTranslation(key, params = {}) {
  try {
    const language = await getCurrentLanguage();
    return translateKey(key, language, params);
  } catch (error) {
    console.error('Error getting translation:', error);
    return key;
  }
}

/**
 * Gets a translated string synchronously (uses cached language)
 * @param {string} key - Translation key
 * @param {Object} params - Parameters for interpolation
 * @returns {string} Translated string
 */
function getTranslationSync(key, params = {}) {
  try {
    // Use cached language or default
    const language = cachedLanguage || DEFAULT_LANGUAGE;
    return translateKey(key, language, params);
  } catch (error) {
    console.error('Error getting translation synchronously:', error);
    return key;
  }
}

/**
 * Translates a key for a specific language
 * @param {string} key - Translation key
 * @param {string} language - Language code
 * @param {Object} params - Parameters for interpolation
 * @returns {string} Translated string
 */
function translateKey(key, language, params = {}) {
  // Get translations for language
  const translations = TRANSLATIONS[language] || TRANSLATIONS[DEFAULT_LANGUAGE];
  
  // Get translation for key
  let translation = translations[key];
  
  // Fallback to default language if translation not found
  if (!translation && language !== DEFAULT_LANGUAGE) {
    translation = TRANSLATIONS[DEFAULT_LANGUAGE][key];
  }
  
  // Fallback to key if translation not found
  if (!translation) {
    return key;
  }
  
  // Interpolate parameters
  return interpolateParams(translation, params);
}

/**
 * Interpolates parameters in a translation string
 * @param {string} translation - Translation string
 * @param {Object} params - Parameters for interpolation
 * @returns {string} Interpolated string
 */
function interpolateParams(translation, params = {}) {
  return translation.replace(/{{([^}]+)}}/g, (match, key) => {
    return params[key] !== undefined ? params[key] : match;
  });
}

/**
 * Gets all translations for a language
 * @param {string} language - Language code
 * @returns {Promise<Object>} Translations
 */
async function getAllTranslations(language = null) {
  try {
    // Get language if not specified
    if (!language) {
      language = await getCurrentLanguage();
    }
    
    // Get translations for language
    return TRANSLATIONS[language] || TRANSLATIONS[DEFAULT_LANGUAGE];
  } catch (error) {
    console.error('Error getting all translations:', error);
    return TRANSLATIONS[DEFAULT_LANGUAGE];
  }
}

/**
 * Gets supported languages
 * @returns {Object} Supported languages
 */
function getSupportedLanguages() {
  return { ...SUPPORTED_LANGUAGES };
}

/**
 * Formats a date according to the current language
 * @param {Date|string|number} date - Date to format
 * @param {Object} options - Intl.DateTimeFormat options
 * @returns {Promise<string>} Formatted date
 */
async function formatDate(date, options = {}) {
  try {
    const language = await getCurrentLanguage();
    const dateObj = date instanceof Date ? date : new Date(date);
    
    return new Intl.DateTimeFormat(language, options).format(dateObj);
  } catch (error) {
    console.error('Error formatting date:', error);
    return String(date);
  }
}

/**
 * Formats a number according to the current language
 * @param {number} number - Number to format
 * @param {Object} options - Intl.NumberFormat options
 * @returns {Promise<string>} Formatted number
 */
async function formatNumber(number, options = {}) {
  try {
    const language = await getCurrentLanguage();
    return new Intl.NumberFormat(language, options).format(number);
  } catch (error) {
    console.error('Error formatting number:', error);
    return String(number);
  }
}

/**
 * Formats a currency amount according to the current language
 * @param {number} amount - Amount to format
 * @param {string} currency - Currency code
 * @param {Object} options - Additional Intl.NumberFormat options
 * @returns {Promise<string>} Formatted currency amount
 */
async function formatCurrency(amount, currency = 'USD', options = {}) {
  try {
    const language = await getCurrentLanguage();
    return new Intl.NumberFormat(language, {
      style: 'currency',
      currency,
      ...options
    }).format(amount);
  } catch (error) {
    console.error('Error formatting currency:', error);
    return String(amount);
  }
}

/**
 * Formats a relative time according to the current language
 * @param {Date|string|number} date - Date to format
 * @returns {Promise<string>} Formatted relative time
 */
async function formatRelativeTime(date) {
  try {
    const language = await getCurrentLanguage();
    const dateObj = date instanceof Date ? date : new Date(date);
    const now = new Date();
    const diffMs = now - dateObj;
    
    // Convert to seconds
    const diffSec = Math.floor(diffMs / 1000);
    
    // Less than a minute
    if (diffSec < 60) {
      return await getTranslation('time_now');
    }
    
    // Less than an hour
    if (diffSec < 3600) {
      const minutes = Math.floor(diffSec / 60);
      const key = minutes === 1 ? 'time_minute_ago' : 'time_minutes_ago';
      return await getTranslation(key, { count: minutes });
    }
    
    // Less than a day
    if (diffSec < 86400) {
      const hours = Math.floor(diffSec / 3600);
      const key = hours === 1 ? 'time_hour_ago' : 'time_hours_ago';
      return await getTranslation(key, { count: hours });
    }
    
    // Less than a week
    if (diffSec < 604800) {
      const days = Math.floor(diffSec / 86400);
      const key = days === 1 ? 'time_day_ago' : 'time_days_ago';
      return await getTranslation(key, { count: days });
    }
    
    // More than a week
    const weeks = Math.floor(diffSec / 604800);
    const key = weeks === 1 ? 'time_week_ago' : 'time_weeks_ago';
    return await getTranslation(key, { count: weeks });
  } catch (error) {
    console.error('Error formatting relative time:', error);
    return String(date);
  }
}

/**
 * Cached language for synchronous translations
 * @type {string}
 */
let cachedLanguage = null;

/**
 * Initializes the i18n module
 * @returns {Promise<void>}
 */
async function initI18n() {
  try {
    // Get current language and cache it
    cachedLanguage = await getCurrentLanguage();
    
    // Set up language change listener
    chrome.storage.onChanged.addListener((changes) => {
      if (changes.cryptovoice_language) {
        cachedLanguage = changes.cryptovoice_language.newValue;
        notifyLanguageChanged(cachedLanguage);
      }
    });
    
    // If config manager is available, listen for config changes
    if (typeof window.configManagerUtils !== 'undefined' && 
        typeof window.configManagerUtils.onConfigChanged === 'function') {
      window.configManagerUtils.onConfigChanged((config, section, key) => {
        if (section === 'general' && key === 'language') {
          cachedLanguage = config.general.language;
          notifyLanguageChanged(cachedLanguage);
        }
      });
    }
  } catch (error) {
    console.error('Error initializing i18n:', error);
  }
}

/**
 * Notifies about language changes
 * @param {string} language - New language
 */
function notifyLanguageChanged(language) {
  // Dispatch event for in-page components
  const event = new CustomEvent('cryptovoice:languageChanged', {
    detail: { language }
  });
  
  window.dispatchEvent(event);
}

/**
 * Listens for language changes
 * @param {Function} callback - Callback function
 * @returns {Function} Function to remove the listener
 */
function onLanguageChanged(callback) {
  // Create event listener
  const handleEvent = (event) => {
    callback(event.detail.language);
  };
  
  // Add event listener
  window.addEventListener('cryptovoice:languageChanged', handleEvent);
  
  // Return function to remove listener
  return () => {
    window.removeEventListener('cryptovoice:languageChanged', handleEvent);
  };
}

// Initialize i18n when the module is loaded
if (typeof window !== 'undefined') {
  initI18n().catch(console.error);
}

// Export functions and constants
if (typeof module !== 'undefined' && module.exports) {
  module.exports = {
    DEFAULT_LANGUAGE,
    SUPPORTED_LANGUAGES,
    getCurrentLanguage,
    setLanguage,
    getTranslation,
    getTranslationSync,
    getAllTranslations,
    getSupportedLanguages,
    formatDate,
    formatNumber,
    formatCurrency,
    formatRelativeTime,
    onLanguageChanged,
    initI18n
  };
} else {
  // For browser environment
  window.i18nUtils = {
    DEFAULT_LANGUAGE,
    SUPPORTED_LANGUAGES,
    getCurrentLanguage,
    setLanguage,
    getTranslation,
    getTranslationSync,
    getAllTranslations,
    getSupportedLanguages,
    formatDate,
    formatNumber,
    formatCurrency,
    formatRelativeTime,
    onLanguageChanged,
    initI18n
  };
}
