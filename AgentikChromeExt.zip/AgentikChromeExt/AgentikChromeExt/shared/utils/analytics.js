/**
 * CryptoVoice - Analytics Utilities
 * 
 * This file contains utility functions for tracking and analyzing user interactions.
 * Note: This is a privacy-focused implementation that keeps all data local by default.
 */

/**
 * Event types for analytics tracking
 * @enum {string}
 */
const EventTypes = {
  // Voice command events
  VOICE_COMMAND_STARTED: 'voice_command_started',
  VOICE_COMMAND_RECOGNIZED: 'voice_command_recognized',
  VOICE_COMMAND_EXECUTED: 'voice_command_executed',
  VOICE_COMMAND_FAILED: 'voice_command_failed',
  
  // Wallet events
  WALLET_CONNECTED: 'wallet_connected',
  WALLET_DISCONNECTED: 'wallet_disconnected',
  TRANSACTION_INITIATED: 'transaction_initiated',
  TRANSACTION_COMPLETED: 'transaction_completed',
  TRANSACTION_FAILED: 'transaction_failed',
  
  // Trading agent events
  AGENT_ENABLED: 'agent_enabled',
  AGENT_DISABLED: 'agent_disabled',
  AGENT_DECISION_MADE: 'agent_decision_made',
  AGENT_TRANSACTION_EXECUTED: 'agent_transaction_executed',
  
  // UI events
  PAGE_VIEW: 'page_view',
  BUTTON_CLICK: 'button_click',
  FORM_SUBMIT: 'form_submit',
  MODAL_OPEN: 'modal_open',
  MODAL_CLOSE: 'modal_close',
  
  // DeFi platform events
  PLATFORM_DETECTED: 'platform_detected',
  SWAP_INITIATED: 'swap_initiated',
  SWAP_COMPLETED: 'swap_completed',
  LENDING_INITIATED: 'lending_initiated',
  LENDING_COMPLETED: 'lending_completed',
  
  // Error events
  ERROR_OCCURRED: 'error_occurred',
  
  // Session events
  SESSION_STARTED: 'session_started',
  SESSION_ENDED: 'session_ended'
};

/**
 * Tracks an event with the specified properties
 * @param {string} eventType - Type of event from EventTypes enum
 * @param {Object} eventProperties - Properties associated with the event
 * @returns {Promise<boolean>} Success status
 */
async function trackEvent(eventType, eventProperties = {}) {
  try {
    // Create event object
    const event = {
      eventType,
      eventProperties,
      timestamp: new Date().toISOString(),
      sessionId: await getSessionId()
    };
    
    // Log event to console in development mode
    if (process.env.NODE_ENV === 'development') {
      console.log('Analytics Event:', event);
    }
    
    // Store event locally
    await storeEventLocally(event);
    
    // Send event to remote if enabled
    if (await isRemoteTrackingEnabled()) {
      await sendEventToRemote(event);
    }
    
    return true;
  } catch (error) {
    console.error('Error tracking event:', error);
    return false;
  }
}

/**
 * Stores an event in local storage
 * @param {Object} event - Event to store
 * @returns {Promise<boolean>} Success status
 */
async function storeEventLocally(event) {
  try {
    // Get existing events
    const existingEvents = await getLocalEvents();
    
    // Add new event
    existingEvents.push(event);
    
    // Trim events if too many (keep last 1000)
    const trimmedEvents = existingEvents.slice(-1000);
    
    // Save events
    await new Promise((resolve, reject) => {
      chrome.storage.local.set({ 'cryptovoice_analytics_events': trimmedEvents }, () => {
        if (chrome.runtime.lastError) {
          reject(chrome.runtime.lastError);
        } else {
          resolve();
        }
      });
    });
    
    return true;
  } catch (error) {
    console.error('Error storing event locally:', error);
    return false;
  }
}

/**
 * Gets events from local storage
 * @returns {Promise<Array>} Array of events
 */
async function getLocalEvents() {
  try {
    return await new Promise((resolve, reject) => {
      chrome.storage.local.get('cryptovoice_analytics_events', (result) => {
        if (chrome.runtime.lastError) {
          reject(chrome.runtime.lastError);
        } else {
          resolve(result.cryptovoice_analytics_events || []);
        }
      });
    });
  } catch (error) {
    console.error('Error getting local events:', error);
    return [];
  }
}

/**
 * Sends an event to remote analytics service if enabled
 * @param {Object} event - Event to send
 * @returns {Promise<boolean>} Success status
 */
async function sendEventToRemote(event) {
  try {
    // Check if remote tracking is enabled
    if (!await isRemoteTrackingEnabled()) {
      return false;
    }
    
    // Get API key and endpoint
    const apiKey = await getAnalyticsApiKey();
    const endpoint = await getAnalyticsEndpoint();
    
    if (!apiKey || !endpoint) {
      return false;
    }
    
    // Send event to remote service
    // This is a placeholder - in a real implementation, this would use fetch
    console.log('Would send to remote:', endpoint, event);
    
    // Simulate successful remote tracking
    return true;
  } catch (error) {
    console.error('Error sending event to remote:', error);
    return false;
  }
}

/**
 * Checks if remote tracking is enabled
 * @returns {Promise<boolean>} Whether remote tracking is enabled
 */
async function isRemoteTrackingEnabled() {
  try {
    return await new Promise((resolve) => {
      chrome.storage.local.get('cryptovoice_remote_tracking_enabled', (result) => {
        resolve(!!result.cryptovoice_remote_tracking_enabled);
      });
    });
  } catch (error) {
    console.error('Error checking if remote tracking is enabled:', error);
    return false;
  }
}

/**
 * Gets the analytics API key
 * @returns {Promise<string|null>} API key or null if not set
 */
async function getAnalyticsApiKey() {
  try {
    return await new Promise((resolve) => {
      chrome.storage.local.get('cryptovoice_analytics_api_key', (result) => {
        resolve(result.cryptovoice_analytics_api_key || null);
      });
    });
  } catch (error) {
    console.error('Error getting analytics API key:', error);
    return null;
  }
}

/**
 * Gets the analytics endpoint
 * @returns {Promise<string|null>} Endpoint or null if not set
 */
async function getAnalyticsEndpoint() {
  try {
    return await new Promise((resolve) => {
      chrome.storage.local.get('cryptovoice_analytics_endpoint', (result) => {
        resolve(result.cryptovoice_analytics_endpoint || null);
      });
    });
  } catch (error) {
    console.error('Error getting analytics endpoint:', error);
    return null;
  }
}

/**
 * Gets or creates a session ID
 * @returns {Promise<string>} Session ID
 */
async function getSessionId() {
  try {
    // Get existing session ID
    const sessionId = await new Promise((resolve) => {
      chrome.storage.local.get('cryptovoice_session_id', (result) => {
        resolve(result.cryptovoice_session_id || null);
      });
    });
    
    // If session ID exists, return it
    if (sessionId) {
      return sessionId;
    }
    
    // Create new session ID
    const newSessionId = generateSessionId();
    
    // Save new session ID
    await new Promise((resolve, reject) => {
      chrome.storage.local.set({ 'cryptovoice_session_id': newSessionId }, () => {
        if (chrome.runtime.lastError) {
          reject(chrome.runtime.lastError);
        } else {
          resolve();
        }
      });
    });
    
    // Track session started event
    await trackEvent(EventTypes.SESSION_STARTED, {
      sessionId: newSessionId,
      timestamp: new Date().toISOString()
    });
    
    return newSessionId;
  } catch (error) {
    console.error('Error getting session ID:', error);
    return generateSessionId(); // Fallback to new session ID
  }
}

/**
 * Generates a new session ID
 * @returns {string} Generated session ID
 */
function generateSessionId() {
  return 'session_' + Math.random().toString(36).substring(2, 15) + 
         Math.random().toString(36).substring(2, 15) + 
         '_' + Date.now();
}

/**
 * Ends the current session
 * @returns {Promise<boolean>} Success status
 */
async function endSession() {
  try {
    // Get current session ID
    const sessionId = await getSessionId();
    
    // Track session ended event
    await trackEvent(EventTypes.SESSION_ENDED, {
      sessionId,
      timestamp: new Date().toISOString()
    });
    
    // Clear session ID
    await new Promise((resolve, reject) => {
      chrome.storage.local.remove('cryptovoice_session_id', () => {
        if (chrome.runtime.lastError) {
          reject(chrome.runtime.lastError);
        } else {
          resolve();
        }
      });
    });
    
    return true;
  } catch (error) {
    console.error('Error ending session:', error);
    return false;
  }
}

/**
 * Enables or disables remote tracking
 * @param {boolean} enabled - Whether remote tracking should be enabled
 * @returns {Promise<boolean>} Success status
 */
async function setRemoteTrackingEnabled(enabled) {
  try {
    await new Promise((resolve, reject) => {
      chrome.storage.local.set({ 'cryptovoice_remote_tracking_enabled': enabled }, () => {
        if (chrome.runtime.lastError) {
          reject(chrome.runtime.lastError);
        } else {
          resolve();
        }
      });
    });
    
    return true;
  } catch (error) {
    console.error('Error setting remote tracking enabled:', error);
    return false;
  }
}

/**
 * Sets the analytics API key
 * @param {string} apiKey - API key
 * @returns {Promise<boolean>} Success status
 */
async function setAnalyticsApiKey(apiKey) {
  try {
    await new Promise((resolve, reject) => {
      chrome.storage.local.set({ 'cryptovoice_analytics_api_key': apiKey }, () => {
        if (chrome.runtime.lastError) {
          reject(chrome.runtime.lastError);
        } else {
          resolve();
        }
      });
    });
    
    return true;
  } catch (error) {
    console.error('Error setting analytics API key:', error);
    return false;
  }
}

/**
 * Sets the analytics endpoint
 * @param {string} endpoint - Endpoint URL
 * @returns {Promise<boolean>} Success status
 */
async function setAnalyticsEndpoint(endpoint) {
  try {
    await new Promise((resolve, reject) => {
      chrome.storage.local.set({ 'cryptovoice_analytics_endpoint': endpoint }, () => {
        if (chrome.runtime.lastError) {
          reject(chrome.runtime.lastError);
        } else {
          resolve();
        }
      });
    });
    
    return true;
  } catch (error) {
    console.error('Error setting analytics endpoint:', error);
    return false;
  }
}

/**
 * Clears all stored analytics data
 * @returns {Promise<boolean>} Success status
 */
async function clearAnalyticsData() {
  try {
    await new Promise((resolve, reject) => {
      chrome.storage.local.remove([
        'cryptovoice_analytics_events',
        'cryptovoice_session_id'
      ], () => {
        if (chrome.runtime.lastError) {
          reject(chrome.runtime.lastError);
        } else {
          resolve();
        }
      });
    });
    
    return true;
  } catch (error) {
    console.error('Error clearing analytics data:', error);
    return false;
  }
}

/**
 * Gets analytics data for the specified time period
 * @param {string} period - Time period (day, week, month, all)
 * @returns {Promise<Object>} Analytics data
 */
async function getAnalyticsData(period = 'all') {
  try {
    // Get all events
    const events = await getLocalEvents();
    
    // Filter events by time period
    const filteredEvents = filterEventsByPeriod(events, period);
    
    // Group events by type
    const eventsByType = groupEventsByType(filteredEvents);
    
    // Calculate metrics
    const metrics = calculateMetrics(filteredEvents, eventsByType);
    
    return {
      period,
      eventCount: filteredEvents.length,
      eventsByType,
      metrics
    };
  } catch (error) {
    console.error('Error getting analytics data:', error);
    return {
      period,
      eventCount: 0,
      eventsByType: {},
      metrics: {}
    };
  }
}

/**
 * Filters events by time period
 * @param {Array} events - Events to filter
 * @param {string} period - Time period (day, week, month, all)
 * @returns {Array} Filtered events
 */
function filterEventsByPeriod(events, period) {
  if (period === 'all') {
    return events;
  }
  
  const now = new Date();
  let cutoff;
  
  switch (period) {
    case 'day':
      cutoff = new Date(now);
      cutoff.setDate(now.getDate() - 1);
      break;
    case 'week':
      cutoff = new Date(now);
      cutoff.setDate(now.getDate() - 7);
      break;
    case 'month':
      cutoff = new Date(now);
      cutoff.setMonth(now.getMonth() - 1);
      break;
    default:
      return events;
  }
  
  return events.filter(event => {
    const eventDate = new Date(event.timestamp);
    return eventDate >= cutoff;
  });
}

/**
 * Groups events by type
 * @param {Array} events - Events to group
 * @returns {Object} Events grouped by type
 */
function groupEventsByType(events) {
  const result = {};
  
  for (const event of events) {
    if (!result[event.eventType]) {
      result[event.eventType] = [];
    }
    
    result[event.eventType].push(event);
  }
  
  return result;
}

/**
 * Calculates metrics from events
 * @param {Array} events - All events
 * @param {Object} eventsByType - Events grouped by type
 * @returns {Object} Calculated metrics
 */
function calculateMetrics(events, eventsByType) {
  // Initialize metrics
  const metrics = {
    // Voice command metrics
    voiceCommandCount: 0,
    voiceCommandSuccessRate: 0,
    
    // Transaction metrics
    transactionCount: 0,
    transactionSuccessRate: 0,
    
    // Agent metrics
    agentDecisionCount: 0,
    agentTransactionCount: 0,
    
    // Session metrics
    sessionCount: 0,
    averageSessionDuration: 0,
    
    // Error metrics
    errorCount: 0
  };
  
  // Calculate voice command metrics
  const voiceCommandStarted = eventsByType[EventTypes.VOICE_COMMAND_STARTED] || [];
  const voiceCommandExecuted = eventsByType[EventTypes.VOICE_COMMAND_EXECUTED] || [];
  
  metrics.voiceCommandCount = voiceCommandStarted.length;
  metrics.voiceCommandSuccessRate = voiceCommandStarted.length > 0 
    ? voiceCommandExecuted.length / voiceCommandStarted.length 
    : 0;
  
  // Calculate transaction metrics
  const transactionInitiated = eventsByType[EventTypes.TRANSACTION_INITIATED] || [];
  const transactionCompleted = eventsByType[EventTypes.TRANSACTION_COMPLETED] || [];
  
  metrics.transactionCount = transactionInitiated.length;
  metrics.transactionSuccessRate = transactionInitiated.length > 0 
    ? transactionCompleted.length / transactionInitiated.length 
    : 0;
  
  // Calculate agent metrics
  metrics.agentDecisionCount = (eventsByType[EventTypes.AGENT_DECISION_MADE] || []).length;
  metrics.agentTransactionCount = (eventsByType[EventTypes.AGENT_TRANSACTION_EXECUTED] || []).length;
  
  // Calculate session metrics
  const sessionStarted = eventsByType[EventTypes.SESSION_STARTED] || [];
  const sessionEnded = eventsByType[EventTypes.SESSION_ENDED] || [];
  
  metrics.sessionCount = sessionStarted.length;
  
  // Calculate average session duration
  let totalDuration = 0;
  let validSessionCount = 0;
  
  for (const startEvent of sessionStarted) {
    // Find matching end event
    const endEvent = sessionEnded.find(endEvent => 
      endEvent.eventProperties.sessionId === startEvent.eventProperties.sessionId
    );
    
    if (endEvent) {
      const startTime = new Date(startEvent.timestamp).getTime();
      const endTime = new Date(endEvent.timestamp).getTime();
      const duration = endTime - startTime;
      
      if (duration > 0) {
        totalDuration += duration;
        validSessionCount++;
      }
    }
  }
  
  metrics.averageSessionDuration = validSessionCount > 0 
    ? totalDuration / validSessionCount 
    : 0;
  
  // Calculate error metrics
  metrics.errorCount = (eventsByType[EventTypes.ERROR_OCCURRED] || []).length;
  
  return metrics;
}

// Export functions and constants
if (typeof module !== 'undefined' && module.exports) {
  module.exports = {
    EventTypes,
    trackEvent,
    getLocalEvents,
    isRemoteTrackingEnabled,
    setRemoteTrackingEnabled,
    getSessionId,
    endSession,
    setAnalyticsApiKey,
    setAnalyticsEndpoint,
    clearAnalyticsData,
    getAnalyticsData
  };
} else {
  // For browser environment
  window.analyticsUtils = {
    EventTypes,
    trackEvent,
    getLocalEvents,
    isRemoteTrackingEnabled,
    setRemoteTrackingEnabled,
    getSessionId,
    endSession,
    setAnalyticsApiKey,
    setAnalyticsEndpoint,
    clearAnalyticsData,
    getAnalyticsData
  };
}
