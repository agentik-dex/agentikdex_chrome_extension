/**
 * Agentik Wallet - Error Management Utilities
 * 
 * This file contains utility functions for handling, logging, and reporting errors
 * throughout the extension.
 */

/**
 * Error categories for different types of errors
 * @enum {string}
 */
const ErrorCategories = {
  WALLET: 'wallet',
  VOICE: 'voice',
  AGENT: 'agent',
  NETWORK: 'network',
  STORAGE: 'storage',
  SECURITY: 'security',
  UI: 'ui',
  DEFI: 'defi',
  EXTENSION: 'extension',
  GENERAL: 'general'
};

/**
 * Error severity levels
 * @enum {number}
 */
const ErrorSeverity = {
  INFO: 0,    // Informational, not an error but worth noting
  LOW: 1,     // Minor issue, doesn't affect functionality
  MEDIUM: 2,  // Affects some functionality but not critical
  HIGH: 3,    // Significant issue affecting core functionality
  CRITICAL: 4 // Fatal error preventing operation
};

/**
 * Error codes for specific error types
 * @enum {string}
 */
const ErrorCodes = {
  // Wallet errors
  WALLET_CONNECTION_FAILED: 'W001',
  WALLET_DISCONNECTED: 'W002',
  WALLET_TRANSACTION_FAILED: 'W003',
  WALLET_INSUFFICIENT_FUNDS: 'W004',
  WALLET_INVALID_ADDRESS: 'W005',
  WALLET_REJECTED_TRANSACTION: 'W006',
  WALLET_NETWORK_MISMATCH: 'W007',
  WALLET_GAS_ESTIMATION_FAILED: 'W008',
  WALLET_TOKEN_APPROVAL_FAILED: 'W009',
  
  // Voice errors
  VOICE_RECOGNITION_FAILED: 'V001',
  VOICE_COMMAND_UNRECOGNIZED: 'V002',
  VOICE_AUTHENTICATION_FAILED: 'V003',
  VOICE_MICROPHONE_ACCESS_DENIED: 'V004',
  VOICE_PROCESSING_ERROR: 'V005',
  VOICE_WAKE_WORD_DETECTION_FAILED: 'V006',
  
  // Agent errors
  AGENT_INITIALIZATION_FAILED: 'A001',
  AGENT_DECISION_ERROR: 'A002',
  AGENT_EXECUTION_FAILED: 'A003',
  AGENT_DATA_FETCH_FAILED: 'A004',
  AGENT_PERMISSION_DENIED: 'A005',
  
  // Network errors
  NETWORK_REQUEST_FAILED: 'N001',
  NETWORK_TIMEOUT: 'N002',
  NETWORK_OFFLINE: 'N003',
  NETWORK_API_ERROR: 'N004',
  NETWORK_RATE_LIMIT: 'N005',
  
  // Storage errors
  STORAGE_READ_FAILED: 'S001',
  STORAGE_WRITE_FAILED: 'S002',
  STORAGE_QUOTA_EXCEEDED: 'S003',
  STORAGE_SYNC_FAILED: 'S004',
  STORAGE_PERMISSION_DENIED: 'S005',
  STORAGE_CORRUPTION: 'S006',
  
  // Security errors
  SECURITY_UNAUTHORIZED_ACCESS: 'SEC001',
  SECURITY_PERMISSION_DENIED: 'SEC002',
  SECURITY_VALIDATION_FAILED: 'SEC003',
  SECURITY_ENCRYPTION_FAILED: 'SEC004',
  SECURITY_DECRYPTION_FAILED: 'SEC005',
  SECURITY_PHISHING_DETECTED: 'SEC006',
  
  // UI errors
  UI_RENDER_FAILED: 'UI001',
  UI_EVENT_ERROR: 'UI002',
  UI_COMPONENT_ERROR: 'UI003',
  UI_ANIMATION_ERROR: 'UI004',
  
  // DeFi errors
  DEFI_PLATFORM_CONNECTION_FAILED: 'D001',
  DEFI_SWAP_FAILED: 'D002',
  DEFI_LIQUIDITY_INSUFFICIENT: 'D003',
  DEFI_SLIPPAGE_EXCEEDED: 'D004',
  DEFI_CONTRACT_INTERACTION_FAILED: 'D005',
  
  // Extension errors
  EXTENSION_INITIALIZATION_FAILED: 'E001',
  EXTENSION_PERMISSION_DENIED: 'E002',
  EXTENSION_API_ERROR: 'E003',
  EXTENSION_CONTEXT_INVALID: 'E004',
  EXTENSION_UPDATE_FAILED: 'E005',
  
  // General errors
  GENERAL_UNEXPECTED_ERROR: 'G001',
  GENERAL_NOT_IMPLEMENTED: 'G002',
  GENERAL_INVALID_PARAMETER: 'G003',
  GENERAL_TIMEOUT: 'G004',
  GENERAL_RESOURCE_NOT_FOUND: 'G005'
};

/**
 * Default error manager configuration
 * @type {Object}
 */
const DefaultErrorManagerConfig = {
  // Whether to log errors to console
  logToConsole: true,
  
  // Whether to log errors to storage
  logToStorage: true,
  
  // Whether to report critical errors remotely
  reportCriticalErrors: false,
  
  // Maximum number of errors to keep in memory
  maxErrorsInMemory: 100,
  
  // Whether to show error notifications
  showErrorNotifications: true,
  
  // Minimum severity level for notifications
  notificationMinSeverity: ErrorSeverity.MEDIUM,
  
  // Whether to include stack traces in error logs
  includeStackTraces: true,
  
  // Whether to attempt automatic recovery
  attemptAutomaticRecovery: true,
  
  // Error reporting endpoint (if enabled)
  errorReportingEndpoint: '',
  
  // Custom error handlers by category
  customHandlers: {}
};

/**
 * In-memory error storage
 * @type {Array}
 */
let errorLog = [];

/**
 * Current error manager configuration
 * @type {Object}
 */
let errorManagerConfig = { ...DefaultErrorManagerConfig };

/**
 * Creates a structured error object
 * @param {string} code - Error code from ErrorCodes enum
 * @param {string} message - Error message
 * @param {string} category - Error category from ErrorCategories enum
 * @param {number} severity - Error severity from ErrorSeverity enum
 * @param {Error|null} originalError - Original error object if available
 * @param {Object} additionalData - Additional error data
 * @returns {Object} Structured error object
 */
function createErrorObject(code, message, category, severity, originalError = null, additionalData = {}) {
  const timestamp = new Date().toISOString();
  
  // Create error object
  const errorObject = {
    code,
    message,
    category,
    severity,
    timestamp,
    additionalData: { ...additionalData }
  };
  
  // Add stack trace if available and enabled
  if (errorManagerConfig.includeStackTraces && originalError && originalError.stack) {
    errorObject.stack = originalError.stack;
  }
  
  return errorObject;
}

/**
 * Logs an error
 * @param {string} code - Error code from ErrorCodes enum
 * @param {string} message - Error message
 * @param {string} category - Error category from ErrorCategories enum
 * @param {number} severity - Error severity from ErrorSeverity enum
 * @param {Error|null} originalError - Original error object if available
 * @param {Object} additionalData - Additional error data
 * @returns {Object} Logged error object
 */
function logError(code, message, category, severity, originalError = null, additionalData = {}) {
  try {
    // Create error object
    const errorObject = createErrorObject(code, message, category, severity, originalError, additionalData);
    
    // Log to console if enabled
    if (errorManagerConfig.logToConsole) {
      const consoleMethod = severity >= ErrorSeverity.HIGH ? console.error : 
                           severity === ErrorSeverity.MEDIUM ? console.warn : 
                           console.info;
      
      consoleMethod(`[${errorObject.code}] ${errorObject.category.toUpperCase()}: ${errorObject.message}`, {
        severity: severity,
        timestamp: errorObject.timestamp,
        additionalData: errorObject.additionalData,
        stack: errorObject.stack
      });
    }
    
    // Add to in-memory log
    errorLog.push(errorObject);
    
    // Trim error log if too large
    if (errorLog.length > errorManagerConfig.maxErrorsInMemory) {
      errorLog = errorLog.slice(-errorManagerConfig.maxErrorsInMemory);
    }
    
    // Log to storage if enabled
    if (errorManagerConfig.logToStorage) {
      storeError(errorObject);
    }
    
    // Show notification if enabled and severity is high enough
    if (errorManagerConfig.showErrorNotifications && severity >= errorManagerConfig.notificationMinSeverity) {
      showErrorNotification(errorObject);
    }
    
    // Report critical errors if enabled
    if (errorManagerConfig.reportCriticalErrors && severity >= ErrorSeverity.HIGH) {
      reportError(errorObject);
    }
    
    // Call custom handler if available for this category
    if (errorManagerConfig.customHandlers[category]) {
      try {
        errorManagerConfig.customHandlers[category](errorObject);
      } catch (handlerError) {
        console.error('Error in custom error handler:', handlerError);
      }
    }
    
    // Attempt automatic recovery if enabled
    if (errorManagerConfig.attemptAutomaticRecovery) {
      attemptRecovery(errorObject);
    }
    
    return errorObject;
  } catch (metaError) {
    // Fallback if error logging itself fails
    console.error('Error in error logging system:', metaError);
    return {
      code,
      message,
      category,
      severity,
      timestamp: new Date().toISOString(),
      metaError: metaError.message
    };
  }
}

/**
 * Stores an error in storage
 * @param {Object} errorObject - Error object to store
 */
function storeError(errorObject) {
  try {
    // Skip if not in extension context
    if (typeof chrome === 'undefined' || !chrome.storage || !chrome.storage.local) {
      return;
    }
    
    // Get stored errors
    chrome.storage.local.get('cryptovoice_errors', (result) => {
      // Get existing errors or initialize empty array
      const storedErrors = result.cryptovoice_errors || [];
      
      // Add new error
      storedErrors.push(errorObject);
      
      // Trim errors if too many
      const trimmedErrors = storedErrors.slice(-errorManagerConfig.maxErrorsInMemory);
      
      // Save errors
      chrome.storage.local.set({ 'cryptovoice_errors': trimmedErrors });
    });
  } catch (error) {
    // Log to console if storage fails
    console.error('Error storing error:', error);
  }
}

/**
 * Shows an error notification
 * @param {Object} errorObject - Error object to show notification for
 */
function showErrorNotification(errorObject) {
  try {
    // Skip if not in extension context
    if (typeof chrome === 'undefined') {
      return;
    }
    
    // Check if notification manager is available
    if (typeof window.notificationManagerUtils !== 'undefined' && 
        typeof window.notificationManagerUtils.showNotification === 'function') {
      // Use notification manager
      window.notificationManagerUtils.showNotification({
        type: 'error',
        title: `Error ${errorObject.code}`,
        message: errorObject.message,
        priority: errorObject.severity >= ErrorSeverity.HIGH ? 'high' : 'normal',
        data: {
          errorCode: errorObject.code,
          errorCategory: errorObject.category,
          timestamp: errorObject.timestamp
        }
      });
    } else if (chrome.notifications) {
      // Use Chrome notifications API directly
      chrome.notifications.create({
        type: 'basic',
        iconUrl: chrome.runtime.getURL('assets/icons/error_icon.png'),
        title: `Agentik Wallet Error (${errorObject.code})`,
        message: errorObject.message,
        priority: errorObject.severity >= ErrorSeverity.HIGH ? 2 : 1
      });
    }
  } catch (error) {
    console.error('Error showing notification:', error);
  }
}

/**
 * Reports an error to the remote error reporting service
 * @param {Object} errorObject - Error object to report
 */
async function reportError(errorObject) {
  try {
    // Skip if reporting is disabled or no endpoint is configured
    if (!errorManagerConfig.reportCriticalErrors || !errorManagerConfig.errorReportingEndpoint) {
      return;
    }
    
    // Skip if not in extension context or no network
    if (typeof navigator === 'undefined' || !navigator.onLine) {
      return;
    }
    
    // Prepare report data
    const reportData = {
      ...errorObject,
      extensionVersion: chrome.runtime.getManifest().version,
      userAgent: navigator.userAgent,
      timestamp: new Date().toISOString()
    };
    
    // Remove potentially sensitive data
    if (reportData.additionalData) {
      // Remove wallet addresses, private keys, etc.
      delete reportData.additionalData.walletAddress;
      delete reportData.additionalData.privateKey;
      delete reportData.additionalData.mnemonic;
      delete reportData.additionalData.seed;
      delete reportData.additionalData.password;
    }
    
    // Send report
    await fetch(errorManagerConfig.errorReportingEndpoint, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify(reportData)
    });
  } catch (error) {
    console.error('Error reporting error:', error);
  }
}

/**
 * Attempts to recover from an error
 * @param {Object} errorObject - Error object to recover from
 */
function attemptRecovery(errorObject) {
  try {
    // Skip if recovery is disabled
    if (!errorManagerConfig.attemptAutomaticRecovery) {
      return;
    }
    
    // Implement recovery strategies based on error code and category
    switch (errorObject.code) {
      case ErrorCodes.NETWORK_OFFLINE:
        // Set up reconnection when online
        window.addEventListener('online', () => {
          // Trigger reconnection logic
          if (typeof window.networkUtils !== 'undefined' && 
              typeof window.networkUtils.reconnect === 'function') {
            window.networkUtils.reconnect();
          }
        }, { once: true });
        break;
        
      case ErrorCodes.WALLET_DISCONNECTED:
        // Attempt to reconnect wallet
        if (typeof window.walletUtils !== 'undefined' && 
            typeof window.walletUtils.reconnectWallet === 'function') {
          setTimeout(() => {
            window.walletUtils.reconnectWallet();
          }, 2000);
        }
        break;
        
      case ErrorCodes.STORAGE_SYNC_FAILED:
        // Retry sync after delay
        if (typeof window.syncManagerUtils !== 'undefined' && 
            typeof window.syncManagerUtils.syncData === 'function') {
          setTimeout(() => {
            window.syncManagerUtils.syncData();
          }, 5000);
        }
        break;
        
      case ErrorCodes.VOICE_RECOGNITION_FAILED:
        // Restart voice recognition
        if (typeof window.voiceUtils !== 'undefined' && 
            typeof window.voiceUtils.restartRecognition === 'function') {
          setTimeout(() => {
            window.voiceUtils.restartRecognition();
          }, 1000);
        }
        break;
        
      // Add more recovery strategies as needed
    }
  } catch (error) {
    console.error('Error attempting recovery:', error);
  }
}

/**
 * Gets errors from storage
 * @returns {Promise<Array>} Errors
 */
async function getStoredErrors() {
  try {
    // Skip if not in extension context
    if (typeof chrome === 'undefined' || !chrome.storage || !chrome.storage.local) {
      return [];
    }
    
    // Get stored errors
    return await new Promise((resolve) => {
      chrome.storage.local.get('cryptovoice_errors', (result) => {
        resolve(result.cryptovoice_errors || []);
      });
    });
  } catch (error) {
    console.error('Error getting stored errors:', error);
    return [];
  }
}

/**
 * Clears errors from storage
 * @returns {Promise<boolean>} Success status
 */
async function clearStoredErrors() {
  try {
    // Skip if not in extension context
    if (typeof chrome === 'undefined' || !chrome.storage || !chrome.storage.local) {
      return false;
    }
    
    // Clear stored errors
    await new Promise((resolve) => {
      chrome.storage.local.remove('cryptovoice_errors', resolve);
    });
    
    return true;
  } catch (error) {
    console.error('Error clearing stored errors:', error);
    return false;
  }
}

/**
 * Gets in-memory errors
 * @returns {Array} Errors
 */
function getInMemoryErrors() {
  return [...errorLog];
}

/**
 * Clears in-memory errors
 */
function clearInMemoryErrors() {
  errorLog = [];
}

/**
 * Gets error manager configuration
 * @returns {Object} Error manager configuration
 */
function getErrorManagerConfig() {
  return { ...errorManagerConfig };
}

/**
 * Updates error manager configuration
 * @param {Object} config - New configuration
 * @returns {Object} Updated configuration
 */
function updateErrorManagerConfig(config) {
  // Merge with current config
  errorManagerConfig = {
    ...errorManagerConfig,
    ...config,
    customHandlers: {
      ...errorManagerConfig.customHandlers,
      ...(config.customHandlers || {})
    }
  };
  
  return { ...errorManagerConfig };
}

/**
 * Resets error manager configuration to defaults
 * @returns {Object} Default configuration
 */
function resetErrorManagerConfig() {
  errorManagerConfig = { ...DefaultErrorManagerConfig };
  return { ...errorManagerConfig };
}

/**
 * Registers a custom error handler for a category
 * @param {string} category - Error category from ErrorCategories enum
 * @param {Function} handler - Error handler function
 */
function registerErrorHandler(category, handler) {
  if (typeof handler !== 'function') {
    throw new Error('Error handler must be a function');
  }
  
  errorManagerConfig.customHandlers[category] = handler;
}

/**
 * Unregisters a custom error handler for a category
 * @param {string} category - Error category from ErrorCategories enum
 */
function unregisterErrorHandler(category) {
  delete errorManagerConfig.customHandlers[category];
}

/**
 * Filters errors by criteria
 * @param {Object} filters - Filter criteria
 * @returns {Array} Filtered errors
 */
function filterErrors(filters = {}) {
  try {
    // Get all errors
    const allErrors = [...errorLog];
    
    // Apply filters
    return allErrors.filter(error => {
      // Filter by code
      if (filters.code && error.code !== filters.code) {
        return false;
      }
      
      // Filter by category
      if (filters.category && error.category !== filters.category) {
        return false;
      }
      
      // Filter by minimum severity
      if (filters.minSeverity !== undefined && error.severity < filters.minSeverity) {
        return false;
      }
      
      // Filter by maximum severity
      if (filters.maxSeverity !== undefined && error.severity > filters.maxSeverity) {
        return false;
      }
      
      // Filter by start date
      if (filters.startDate) {
        const errorDate = new Date(error.timestamp);
        const startDate = new Date(filters.startDate);
        
        if (errorDate < startDate) {
          return false;
        }
      }
      
      // Filter by end date
      if (filters.endDate) {
        const errorDate = new Date(error.timestamp);
        const endDate = new Date(filters.endDate);
        
        if (errorDate > endDate) {
          return false;
        }
      }
      
      // Filter by search term
      if (filters.searchTerm) {
        const searchTerm = filters.searchTerm.toLowerCase();
        const messageMatches = error.message.toLowerCase().includes(searchTerm);
        const codeMatches = error.code.toLowerCase().includes(searchTerm);
        const categoryMatches = error.category.toLowerCase().includes(searchTerm);
        
        if (!messageMatches && !codeMatches && !categoryMatches) {
          return false;
        }
      }
      
      return true;
    });
  } catch (error) {
    console.error('Error filtering errors:', error);
    return [];
  }
}

/**
 * Gets error statistics
 * @param {Array} errors - Errors to analyze, defaults to in-memory errors
 * @returns {Object} Error statistics
 */
function getErrorStatistics(errors = errorLog) {
  try {
    // Initialize statistics
    const statistics = {
      total: errors.length,
      bySeverity: {
        [ErrorSeverity.INFO]: 0,
        [ErrorSeverity.LOW]: 0,
        [ErrorSeverity.MEDIUM]: 0,
        [ErrorSeverity.HIGH]: 0,
        [ErrorSeverity.CRITICAL]: 0
      },
      byCategory: {},
      byCode: {},
      mostFrequent: [],
      recentErrors: []
    };
    
    // Count errors by severity, category, and code
    for (const error of errors) {
      // Count by severity
      statistics.bySeverity[error.severity] = (statistics.bySeverity[error.severity] || 0) + 1;
      
      // Count by category
      statistics.byCategory[error.category] = (statistics.byCategory[error.category] || 0) + 1;
      
      // Count by code
      statistics.byCode[error.code] = (statistics.byCode[error.code] || 0) + 1;
    }
    
    // Get most frequent errors
    const codeCounts = Object.entries(statistics.byCode)
      .map(([code, count]) => ({ code, count }))
      .sort((a, b) => b.count - a.count);
    
    statistics.mostFrequent = codeCounts.slice(0, 5);
    
    // Get recent errors
    statistics.recentErrors = [...errors]
      .sort((a, b) => new Date(b.timestamp) - new Date(a.timestamp))
      .slice(0, 5);
    
    return statistics;
  } catch (error) {
    console.error('Error getting error statistics:', error);
    return {
      total: 0,
      bySeverity: {},
      byCategory: {},
      byCode: {},
      mostFrequent: [],
      recentErrors: []
    };
  }
}

/**
 * Creates an error handler for a specific category
 * @param {string} category - Error category from ErrorCategories enum
 * @returns {Object} Category error handler
 */
function createCategoryErrorHandler(category) {
  return {
    logError: (code, message, severity, originalError = null, additionalData = {}) => 
      logError(code, message, category, severity, originalError, additionalData),
    
    logInfo: (code, message, originalError = null, additionalData = {}) => 
      logError(code, message, category, ErrorSeverity.INFO, originalError, additionalData),
    
    logLow: (code, message, originalError = null, additionalData = {}) => 
      logError(code, message, category, ErrorSeverity.LOW, originalError, additionalData),
    
    logMedium: (code, message, originalError = null, additionalData = {}) => 
      logError(code, message, category, ErrorSeverity.MEDIUM, originalError, additionalData),
    
    logHigh: (code, message, originalError = null, additionalData = {}) => 
      logError(code, message, category, ErrorSeverity.HIGH, originalError, additionalData),
    
    logCritical: (code, message, originalError = null, additionalData = {}) => 
      logError(code, message, category, ErrorSeverity.CRITICAL, originalError, additionalData)
  };
}

/**
 * Wraps a function with error handling
 * @param {Function} fn - Function to wrap
 * @param {string} errorCode - Error code to use if function throws
 * @param {string} errorCategory - Error category
 * @param {number} errorSeverity - Error severity
 * @param {string} errorMessage - Error message template
 * @returns {Function} Wrapped function
 */
function withErrorHandling(fn, errorCode, errorCategory, errorSeverity, errorMessage) {
  return async function(...args) {
    try {
      return await fn(...args);
    } catch (error) {
      // Log the error
      const formattedMessage = errorMessage.replace('{error}', error.message);
      logError(errorCode, formattedMessage, errorCategory, errorSeverity, error, { args });
      
      // Re-throw the error
      throw error;
    }
  };
}

// Export functions and constants
if (typeof module !== 'undefined' && module.exports) {
  module.exports = {
    ErrorCategories,
    ErrorSeverity,
    ErrorCodes,
    DefaultErrorManagerConfig,
    logError,
    getStoredErrors,
    clearStoredErrors,
    getInMemoryErrors,
    clearInMemoryErrors,
    getErrorManagerConfig,
    updateErrorManagerConfig,
    resetErrorManagerConfig,
    registerErrorHandler,
    unregisterErrorHandler,
    filterErrors,
    getErrorStatistics,
    createCategoryErrorHandler,
    withErrorHandling
  };
} else {
  // For browser environment
  window.errorManagerUtils = {
    ErrorCategories,
    ErrorSeverity,
    ErrorCodes,
    DefaultErrorManagerConfig,
    logError,
    getStoredErrors,
    clearStoredErrors,
    getInMemoryErrors,
    clearInMemoryErrors,
    getErrorManagerConfig,
    updateErrorManagerConfig,
    resetErrorManagerConfig,
    registerErrorHandler,
    unregisterErrorHandler,
    filterErrors,
    getErrorStatistics,
    createCategoryErrorHandler,
    withErrorHandling
  };
}
