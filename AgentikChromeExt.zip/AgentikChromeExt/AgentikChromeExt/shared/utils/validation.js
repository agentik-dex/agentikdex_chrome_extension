/**
 * CryptoVoice - Validation Utilities
 * 
 * This file contains utility functions for validating various types of data
 * used throughout the extension.
 */

/**
 * Validation error types
 * @enum {string}
 */
const ValidationErrorTypes = {
  REQUIRED: 'required',
  TYPE: 'type',
  FORMAT: 'format',
  RANGE: 'range',
  LENGTH: 'length',
  PATTERN: 'pattern',
  CUSTOM: 'custom'
};

/**
 * Validates an Ethereum address
 * @param {string} address - Ethereum address to validate
 * @returns {boolean} Whether the address is valid
 */
function isValidEthereumAddress(address) {
  // Check if address is a string
  if (typeof address !== 'string') {
    return false;
  }
  
  // Check if address matches Ethereum address pattern
  return /^0x[a-fA-F0-9]{40}$/.test(address);
}

/**
 * Validates a Solana address
 * @param {string} address - Solana address to validate
 * @returns {boolean} Whether the address is valid
 */
function isValidSolanaAddress(address) {
  // Check if address is a string
  if (typeof address !== 'string') {
    return false;
  }
  
  // Check if address matches Solana address pattern (base58 encoding, 32-44 chars)
  return /^[1-9A-HJ-NP-Za-km-z]{32,44}$/.test(address);
}

/**
 * Validates a blockchain address for the specified network
 * @param {string} address - Address to validate
 * @param {string} network - Network name
 * @returns {boolean} Whether the address is valid
 */
function isValidBlockchainAddress(address, network) {
  // Check if address is a string
  if (typeof address !== 'string') {
    return false;
  }
  
  // Normalize network name
  const normalizedNetwork = network.toLowerCase();
  
  // Validate based on network
  if (normalizedNetwork.includes('ethereum') || 
      normalizedNetwork.includes('polygon') || 
      normalizedNetwork.includes('arbitrum') || 
      normalizedNetwork.includes('optimism') || 
      normalizedNetwork.includes('bsc') || 
      normalizedNetwork.includes('avalanche') || 
      normalizedNetwork === 'eth' || 
      normalizedNetwork === 'evm') {
    return isValidEthereumAddress(address);
  } else if (normalizedNetwork.includes('solana') || normalizedNetwork === 'sol') {
    return isValidSolanaAddress(address);
  }
  
  // Unknown network
  return false;
}

/**
 * Validates a transaction amount
 * @param {string|number} amount - Amount to validate
 * @returns {boolean} Whether the amount is valid
 */
function isValidTransactionAmount(amount) {
  // Convert to number if string
  const numAmount = typeof amount === 'string' ? parseFloat(amount) : amount;
  
  // Check if amount is a number
  if (isNaN(numAmount) || typeof numAmount !== 'number') {
    return false;
  }
  
  // Check if amount is positive
  return numAmount > 0;
}

/**
 * Validates a token symbol
 * @param {string} symbol - Token symbol to validate
 * @returns {boolean} Whether the symbol is valid
 */
function isValidTokenSymbol(symbol) {
  // Check if symbol is a string
  if (typeof symbol !== 'string') {
    return false;
  }
  
  // Check if symbol matches token symbol pattern (1-10 alphanumeric chars)
  return /^[A-Za-z0-9]{1,10}$/.test(symbol);
}

/**
 * Validates a contract address
 * @param {string} address - Contract address to validate
 * @param {string} network - Network name
 * @returns {boolean} Whether the contract address is valid
 */
function isValidContractAddress(address, network) {
  // First check if it's a valid blockchain address
  if (!isValidBlockchainAddress(address, network)) {
    return false;
  }
  
  // For Ethereum and EVM-compatible networks, check if it's not the zero address
  if (network.toLowerCase().includes('ethereum') || 
      network.toLowerCase().includes('polygon') || 
      network.toLowerCase().includes('arbitrum') || 
      network.toLowerCase().includes('optimism') || 
      network.toLowerCase().includes('bsc') || 
      network.toLowerCase().includes('avalanche') || 
      network.toLowerCase() === 'eth' || 
      network.toLowerCase() === 'evm') {
    return address !== '0x0000000000000000000000000000000000000000';
  }
  
  // For other networks, just return true if it's a valid address
  return true;
}

/**
 * Validates a transaction hash
 * @param {string} hash - Transaction hash to validate
 * @param {string} network - Network name
 * @returns {boolean} Whether the transaction hash is valid
 */
function isValidTransactionHash(hash, network) {
  // Check if hash is a string
  if (typeof hash !== 'string') {
    return false;
  }
  
  // Normalize network name
  const normalizedNetwork = network.toLowerCase();
  
  // Validate based on network
  if (normalizedNetwork.includes('ethereum') || 
      normalizedNetwork.includes('polygon') || 
      normalizedNetwork.includes('arbitrum') || 
      normalizedNetwork.includes('optimism') || 
      normalizedNetwork.includes('bsc') || 
      normalizedNetwork.includes('avalanche') || 
      normalizedNetwork === 'eth' || 
      normalizedNetwork === 'evm') {
    // Ethereum transaction hash: 0x followed by 64 hex chars
    return /^0x[a-fA-F0-9]{64}$/.test(hash);
  } else if (normalizedNetwork.includes('solana') || normalizedNetwork === 'sol') {
    // Solana transaction hash: base58 encoding, 43-44 chars
    return /^[1-9A-HJ-NP-Za-km-z]{43,44}$/.test(hash);
  }
  
  // Unknown network
  return false;
}

/**
 * Validates a URL
 * @param {string} url - URL to validate
 * @returns {boolean} Whether the URL is valid
 */
function isValidUrl(url) {
  try {
    // Try to create a URL object
    new URL(url);
    return true;
  } catch (error) {
    return false;
  }
}

/**
 * Validates an email address
 * @param {string} email - Email address to validate
 * @returns {boolean} Whether the email address is valid
 */
function isValidEmail(email) {
  // Check if email is a string
  if (typeof email !== 'string') {
    return false;
  }
  
  // Check if email matches email pattern
  return /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/.test(email);
}

/**
 * Validates a password
 * @param {string} password - Password to validate
 * @param {Object} options - Validation options
 * @returns {Object} Validation result
 */
function validatePassword(password, options = {}) {
  // Default options
  const defaultOptions = {
    minLength: 8,
    requireUppercase: true,
    requireLowercase: true,
    requireNumbers: true,
    requireSpecialChars: true
  };
  
  // Merge options
  const mergedOptions = { ...defaultOptions, ...options };
  
  // Check if password is a string
  if (typeof password !== 'string') {
    return {
      valid: false,
      errors: [{ type: ValidationErrorTypes.TYPE, message: 'Password must be a string' }]
    };
  }
  
  // Initialize errors array
  const errors = [];
  
  // Check length
  if (password.length < mergedOptions.minLength) {
    errors.push({
      type: ValidationErrorTypes.LENGTH,
      message: `Password must be at least ${mergedOptions.minLength} characters long`
    });
  }
  
  // Check uppercase
  if (mergedOptions.requireUppercase && !/[A-Z]/.test(password)) {
    errors.push({
      type: ValidationErrorTypes.PATTERN,
      message: 'Password must contain at least one uppercase letter'
    });
  }
  
  // Check lowercase
  if (mergedOptions.requireLowercase && !/[a-z]/.test(password)) {
    errors.push({
      type: ValidationErrorTypes.PATTERN,
      message: 'Password must contain at least one lowercase letter'
    });
  }
  
  // Check numbers
  if (mergedOptions.requireNumbers && !/[0-9]/.test(password)) {
    errors.push({
      type: ValidationErrorTypes.PATTERN,
      message: 'Password must contain at least one number'
    });
  }
  
  // Check special characters
  if (mergedOptions.requireSpecialChars && !/[^A-Za-z0-9]/.test(password)) {
    errors.push({
      type: ValidationErrorTypes.PATTERN,
      message: 'Password must contain at least one special character'
    });
  }
  
  // Return validation result
  return {
    valid: errors.length === 0,
    errors
  };
}

/**
 * Validates a risk profile
 * @param {string} riskProfile - Risk profile to validate
 * @returns {boolean} Whether the risk profile is valid
 */
function isValidRiskProfile(riskProfile) {
  // Check if risk profile is a string
  if (typeof riskProfile !== 'string') {
    return false;
  }
  
  // Check if risk profile is one of the valid values
  const validRiskProfiles = ['conservative', 'moderate', 'aggressive'];
  return validRiskProfiles.includes(riskProfile.toLowerCase());
}

/**
 * Validates a voice command
 * @param {string} command - Voice command to validate
 * @returns {boolean} Whether the command is valid
 */
function isValidVoiceCommand(command) {
  // Check if command is a string
  if (typeof command !== 'string') {
    return false;
  }
  
  // Check if command is not empty
  return command.trim().length > 0;
}

/**
 * Validates a language code
 * @param {string} languageCode - Language code to validate
 * @returns {boolean} Whether the language code is valid
 */
function isValidLanguageCode(languageCode) {
  // Check if language code is a string
  if (typeof languageCode !== 'string') {
    return false;
  }
  
  // Check if language code matches ISO 639-1 pattern (2 lowercase letters)
  return /^[a-z]{2}(-[A-Z]{2})?$/.test(languageCode);
}

/**
 * Validates a configuration object against a schema
 * @param {Object} config - Configuration object to validate
 * @param {Object} schema - Schema to validate against
 * @returns {Object} Validation result
 */
function validateConfig(config, schema) {
  // Initialize errors array
  const errors = [];
  
  // Validate each field in the schema
  for (const [field, fieldSchema] of Object.entries(schema)) {
    // Skip if field is not required and not present
    if (!fieldSchema.required && (config[field] === undefined || config[field] === null)) {
      continue;
    }
    
    // Check if required field is present
    if (fieldSchema.required && (config[field] === undefined || config[field] === null)) {
      errors.push({
        field,
        type: ValidationErrorTypes.REQUIRED,
        message: `Field '${field}' is required`
      });
      continue;
    }
    
    // Skip further validation if field is not present
    if (config[field] === undefined || config[field] === null) {
      continue;
    }
    
    // Check type
    if (fieldSchema.type && typeof config[field] !== fieldSchema.type) {
      errors.push({
        field,
        type: ValidationErrorTypes.TYPE,
        message: `Field '${field}' must be of type '${fieldSchema.type}'`
      });
      continue;
    }
    
    // Check enum
    if (fieldSchema.enum && !fieldSchema.enum.includes(config[field])) {
      errors.push({
        field,
        type: ValidationErrorTypes.FORMAT,
        message: `Field '${field}' must be one of: ${fieldSchema.enum.join(', ')}`
      });
    }
    
    // Check min/max for numbers
    if (fieldSchema.type === 'number') {
      if (fieldSchema.min !== undefined && config[field] < fieldSchema.min) {
        errors.push({
          field,
          type: ValidationErrorTypes.RANGE,
          message: `Field '${field}' must be at least ${fieldSchema.min}`
        });
      }
      
      if (fieldSchema.max !== undefined && config[field] > fieldSchema.max) {
        errors.push({
          field,
          type: ValidationErrorTypes.RANGE,
          message: `Field '${field}' must be at most ${fieldSchema.max}`
        });
      }
    }
    
    // Check minLength/maxLength for strings
    if (fieldSchema.type === 'string') {
      if (fieldSchema.minLength !== undefined && config[field].length < fieldSchema.minLength) {
        errors.push({
          field,
          type: ValidationErrorTypes.LENGTH,
          message: `Field '${field}' must be at least ${fieldSchema.minLength} characters long`
        });
      }
      
      if (fieldSchema.maxLength !== undefined && config[field].length > fieldSchema.maxLength) {
        errors.push({
          field,
          type: ValidationErrorTypes.LENGTH,
          message: `Field '${field}' must be at most ${fieldSchema.maxLength} characters long`
        });
      }
      
      // Check pattern
      if (fieldSchema.pattern && !fieldSchema.pattern.test(config[field])) {
        errors.push({
          field,
          type: ValidationErrorTypes.PATTERN,
          message: `Field '${field}' must match the required pattern`
        });
      }
    }
    
    // Check nested objects
    if (fieldSchema.type === 'object' && fieldSchema.properties) {
      const nestedResult = validateConfig(config[field], fieldSchema.properties);
      
      if (!nestedResult.valid) {
        for (const error of nestedResult.errors) {
          errors.push({
            field: `${field}.${error.field}`,
            type: error.type,
            message: error.message
          });
        }
      }
    }
    
    // Check array items
    if (fieldSchema.type === 'array' && fieldSchema.items) {
      if (!Array.isArray(config[field])) {
        errors.push({
          field,
          type: ValidationErrorTypes.TYPE,
          message: `Field '${field}' must be an array`
        });
      } else {
        // Check array length
        if (fieldSchema.minItems !== undefined && config[field].length < fieldSchema.minItems) {
          errors.push({
            field,
            type: ValidationErrorTypes.LENGTH,
            message: `Field '${field}' must have at least ${fieldSchema.minItems} items`
          });
        }
        
        if (fieldSchema.maxItems !== undefined && config[field].length > fieldSchema.maxItems) {
          errors.push({
            field,
            type: ValidationErrorTypes.LENGTH,
            message: `Field '${field}' must have at most ${fieldSchema.maxItems} items`
          });
        }
        
        // Validate each item
        for (let i = 0; i < config[field].length; i++) {
          if (fieldSchema.items.type === 'object' && fieldSchema.items.properties) {
            const itemResult = validateConfig(config[field][i], fieldSchema.items.properties);
            
            if (!itemResult.valid) {
              for (const error of itemResult.errors) {
                errors.push({
                  field: `${field}[${i}].${error.field}`,
                  type: error.type,
                  message: error.message
                });
              }
            }
          } else if (typeof config[field][i] !== fieldSchema.items.type) {
            errors.push({
              field: `${field}[${i}]`,
              type: ValidationErrorTypes.TYPE,
              message: `Item at index ${i} must be of type '${fieldSchema.items.type}'`
            });
          }
        }
      }
    }
    
    // Check custom validator
    if (fieldSchema.validator && typeof fieldSchema.validator === 'function') {
      const validatorResult = fieldSchema.validator(config[field]);
      
      if (validatorResult !== true) {
        errors.push({
          field,
          type: ValidationErrorTypes.CUSTOM,
          message: validatorResult || `Field '${field}' failed custom validation`
        });
      }
    }
  }
  
  // Return validation result
  return {
    valid: errors.length === 0,
    errors
  };
}

/**
 * Validates a transaction object
 * @param {Object} transaction - Transaction object to validate
 * @returns {Object} Validation result
 */
function validateTransaction(transaction) {
  // Define transaction schema
  const transactionSchema = {
    from: {
      required: true,
      type: 'string',
      validator: (value) => isValidBlockchainAddress(value, transaction.network) || 'Invalid sender address'
    },
    to: {
      required: true,
      type: 'string',
      validator: (value) => isValidBlockchainAddress(value, transaction.network) || 'Invalid recipient address'
    },
    amount: {
      required: true,
      type: 'string',
      validator: (value) => isValidTransactionAmount(value) || 'Invalid transaction amount'
    },
    token: {
      required: true,
      type: 'string',
      validator: (value) => isValidTokenSymbol(value) || 'Invalid token symbol'
    },
    network: {
      required: true,
      type: 'string'
    }
  };
  
  // Validate transaction against schema
  return validateConfig(transaction, transactionSchema);
}

/**
 * Validates a swap transaction object
 * @param {Object} swap - Swap transaction object to validate
 * @returns {Object} Validation result
 */
function validateSwap(swap) {
  // Define swap schema
  const swapSchema = {
    fromToken: {
      required: true,
      type: 'string',
      validator: (value) => isValidTokenSymbol(value) || 'Invalid source token symbol'
    },
    toToken: {
      required: true,
      type: 'string',
      validator: (value) => isValidTokenSymbol(value) || 'Invalid destination token symbol'
    },
    amount: {
      required: true,
      type: 'string',
      validator: (value) => isValidTransactionAmount(value) || 'Invalid swap amount'
    },
    network: {
      required: true,
      type: 'string'
    },
    slippage: {
      required: false,
      type: 'number',
      min: 0,
      max: 100
    }
  };
  
  // Validate swap against schema
  return validateConfig(swap, swapSchema);
}

// Export functions and constants
if (typeof module !== 'undefined' && module.exports) {
  module.exports = {
    ValidationErrorTypes,
    isValidEthereumAddress,
    isValidSolanaAddress,
    isValidBlockchainAddress,
    isValidTransactionAmount,
    isValidTokenSymbol,
    isValidContractAddress,
    isValidTransactionHash,
    isValidUrl,
    isValidEmail,
    validatePassword,
    isValidRiskProfile,
    isValidVoiceCommand,
    isValidLanguageCode,
    validateConfig,
    validateTransaction,
    validateSwap
  };
} else {
  // For browser environment
  window.validationUtils = {
    ValidationErrorTypes,
    isValidEthereumAddress,
    isValidSolanaAddress,
    isValidBlockchainAddress,
    isValidTransactionAmount,
    isValidTokenSymbol,
    isValidContractAddress,
    isValidTransactionHash,
    isValidUrl,
    isValidEmail,
    validatePassword,
    isValidRiskProfile,
    isValidVoiceCommand,
    isValidLanguageCode,
    validateConfig,
    validateTransaction,
    validateSwap
  };
}
