/**
 * CryptoVoice - Market Data Utilities
 * 
 * This file contains utility functions for market data and analytics.
 */

/**
 * Fetches market data for specified tokens
 * @param {string[]} tokens - Array of token symbols
 * @returns {Promise<Object>} Market data for the tokens
 */
async function fetchMarketData(tokens = ['BTC', 'ETH', 'SOL', 'USDC', 'USDT']) {
  // In a real implementation, this would call CoinGecko or similar APIs
  // For now, we'll use mock data
  
  // Simulate API delay
  await new Promise(resolve => setTimeout(resolve, 1200));
  
  const result = {};
  
  for (const token of tokens) {
    // Generate mock market data
    result[token] = generateMockMarketData(token);
  }
  
  return result;
}

/**
 * Generates mock market data for a token
 * @param {string} token - Token symbol
 * @returns {Object} Mock market data
 */
function generateMockMarketData(token) {
  // Base prices for common tokens
  const basePrices = {
    BTC: 35000,
    ETH: 2000,
    SOL: 80,
    USDC: 1,
    USDT: 1,
    BNB: 300,
    MATIC: 0.8,
    LINK: 15,
    UNI: 5,
    AAVE: 80,
    QUICK: 50,
    RAY: 3,
    SRM: 2,
    CAKE: 2,
    ADA: 0.5,
    BUSD: 1
  };
  
  // Get base price or generate a random one
  const basePrice = basePrices[token] || Math.random() * 100;
  
  // Generate price with some randomness
  const priceFactor = 0.95 + (Math.random() * 0.1); // 0.95 to 1.05
  const price = basePrice * priceFactor;
  
  // Generate 24h change (-5% to +5%)
  const change24h = (Math.random() * 10) - 5;
  
  // Generate 7d change (-15% to +15%)
  const change7d = (Math.random() * 30) - 15;
  
  // Generate volume with some correlation to price
  const volume24h = price * (1000000 + Math.random() * 9000000);
  
  // Generate market cap
  const marketCap = price * (10000000 + Math.random() * 90000000);
  
  // Generate price history (24 hours, hourly data points)
  const priceHistory24h = generatePriceHistory(price, 24, 0.5);
  
  // Generate price history (7 days, daily data points)
  const priceHistory7d = generatePriceHistory(price, 7, 2);
  
  // Generate price history (30 days, daily data points)
  const priceHistory30d = generatePriceHistory(price, 30, 5);
  
  return {
    symbol: token,
    name: getTokenName(token),
    price: parseFloat(price.toFixed(6)),
    change24h: parseFloat(change24h.toFixed(2)),
    change7d: parseFloat(change7d.toFixed(2)),
    volume24h: Math.round(volume24h),
    marketCap: Math.round(marketCap),
    priceHistory: {
      '24h': priceHistory24h,
      '7d': priceHistory7d,
      '30d': priceHistory30d
    },
    lastUpdated: new Date().toISOString()
  };
}

/**
 * Generates price history data
 * @param {number} currentPrice - Current price
 * @param {number} periods - Number of periods
 * @param {number} volatility - Price volatility percentage
 * @returns {Array} Array of price data points
 */
function generatePriceHistory(currentPrice, periods, volatility) {
  const history = [];
  let lastPrice = currentPrice;
  
  // Generate timestamps
  const now = new Date();
  const timestamps = [];
  
  for (let i = periods - 1; i >= 0; i--) {
    const timestamp = new Date(now);
    timestamp.setHours(now.getHours() - i);
    timestamps.push(timestamp.toISOString());
  }
  
  // Start from the oldest price and work forward
  for (let i = 0; i < periods; i++) {
    // Random price movement based on volatility
    const changePercent = (Math.random() * volatility * 2) - volatility;
    const changeAmount = lastPrice * (changePercent / 100);
    
    // Calculate new price
    const price = i === periods - 1 ? currentPrice : lastPrice + changeAmount;
    
    // Add to history
    history.push({
      timestamp: timestamps[i],
      price: parseFloat(price.toFixed(6))
    });
    
    lastPrice = price;
  }
  
  return history;
}

/**
 * Gets the full name of a token from its symbol
 * @param {string} symbol - Token symbol
 * @returns {string} Token name
 */
function getTokenName(symbol) {
  const tokenNames = {
    BTC: 'Bitcoin',
    ETH: 'Ethereum',
    SOL: 'Solana',
    USDC: 'USD Coin',
    USDT: 'Tether',
    BNB: 'Binance Coin',
    MATIC: 'Polygon',
    LINK: 'Chainlink',
    UNI: 'Uniswap',
    AAVE: 'Aave',
    QUICK: 'QuickSwap',
    RAY: 'Raydium',
    SRM: 'Serum',
    CAKE: 'PancakeSwap',
    ADA: 'Cardano',
    BUSD: 'Binance USD'
  };
  
  return tokenNames[symbol] || symbol;
}

/**
 * Fetches market sentiment data
 * @param {string[]} tokens - Array of token symbols
 * @returns {Promise<Object>} Market sentiment data
 */
async function fetchMarketSentiment(tokens = ['BTC', 'ETH', 'SOL']) {
  // In a real implementation, this would call sentiment analysis APIs
  // For now, we'll use mock data
  
  // Simulate API delay
  await new Promise(resolve => setTimeout(resolve, 1000));
  
  const result = {};
  
  for (const token of tokens) {
    // Generate mock sentiment data
    result[token] = {
      sentiment: generateRandomSentiment(),
      socialVolume: Math.floor(Math.random() * 10000),
      newsCount: Math.floor(Math.random() * 100),
      trendingScore: parseFloat((Math.random() * 10).toFixed(1)),
      lastUpdated: new Date().toISOString()
    };
  }
  
  return result;
}

/**
 * Generates a random sentiment score and label
 * @returns {Object} Sentiment data
 */
function generateRandomSentiment() {
  // Generate a random score between 0 and 1
  const score = Math.random();
  
  // Determine sentiment label based on score
  let label;
  if (score < 0.3) {
    label = 'bearish';
  } else if (score < 0.45) {
    label = 'slightly_bearish';
  } else if (score < 0.55) {
    label = 'neutral';
  } else if (score < 0.7) {
    label = 'slightly_bullish';
  } else {
    label = 'bullish';
  }
  
  return {
    score: parseFloat(score.toFixed(2)),
    label
  };
}

/**
 * Fetches technical indicators for a token
 * @param {string} token - Token symbol
 * @param {string} timeframe - Timeframe (1h, 4h, 1d, 1w)
 * @returns {Promise<Object>} Technical indicators
 */
async function fetchTechnicalIndicators(token, timeframe = '1d') {
  // In a real implementation, this would calculate actual indicators
  // For now, we'll use mock data
  
  // Simulate calculation delay
  await new Promise(resolve => setTimeout(resolve, 800));
  
  // Generate random indicator values
  const rsi = Math.floor(Math.random() * 100);
  const macd = parseFloat((Math.random() * 2 - 1).toFixed(2));
  const ema20 = generateMockMarketData(token).price * (0.95 + Math.random() * 0.1);
  const ema50 = generateMockMarketData(token).price * (0.9 + Math.random() * 0.2);
  const ema200 = generateMockMarketData(token).price * (0.85 + Math.random() * 0.3);
  
  // Determine indicator signals
  const rsiSignal = rsi < 30 ? 'oversold' : rsi > 70 ? 'overbought' : 'neutral';
  const macdSignal = macd > 0.2 ? 'bullish' : macd < -0.2 ? 'bearish' : 'neutral';
  const emaSignal = ema20 > ema50 && ema50 > ema200 ? 'bullish' : 
                    ema20 < ema50 && ema50 < ema200 ? 'bearish' : 'neutral';
  
  // Overall signal based on indicators
  const signals = [rsiSignal, macdSignal, emaSignal];
  const bullishCount = signals.filter(s => s === 'bullish').length;
  const bearishCount = signals.filter(s => s === 'bearish').length;
  
  let overallSignal;
  if (bullishCount > bearishCount) {
    overallSignal = 'bullish';
  } else if (bearishCount > bullishCount) {
    overallSignal = 'bearish';
  } else {
    overallSignal = 'neutral';
  }
  
  return {
    token,
    timeframe,
    indicators: {
      rsi: {
        value: rsi,
        signal: rsiSignal
      },
      macd: {
        value: macd,
        signal: macdSignal
      },
      ema: {
        ema20: parseFloat(ema20.toFixed(2)),
        ema50: parseFloat(ema50.toFixed(2)),
        ema200: parseFloat(ema200.toFixed(2)),
        signal: emaSignal
      }
    },
    overallSignal,
    lastUpdated: new Date().toISOString()
  };
}

/**
 * Analyzes portfolio performance
 * @param {Object} portfolio - User's portfolio
 * @param {Object} marketData - Current market data
 * @returns {Object} Portfolio analysis
 */
function analyzePortfolio(portfolio, marketData) {
  if (!portfolio || !portfolio.balances || !marketData) {
    return {
      totalValue: 0,
      performance: {
        daily: 0,
        weekly: 0,
        monthly: 0
      },
      allocation: {},
      risk: 'unknown'
    };
  }
  
  // Calculate total value and allocation
  let totalValue = 0;
  const allocation = {};
  
  for (const [token, amount] of Object.entries(portfolio.balances)) {
    if (marketData[token]) {
      const tokenValue = amount * marketData[token].price;
      totalValue += tokenValue;
      allocation[token] = {
        amount,
        value: tokenValue
      };
    }
  }
  
  // Calculate allocation percentages
  for (const token in allocation) {
    allocation[token].percentage = totalValue > 0 ? 
      (allocation[token].value / totalValue) * 100 : 0;
  }
  
  // Generate mock performance data
  const performance = {
    daily: parseFloat((Math.random() * 10 - 5).toFixed(2)),
    weekly: parseFloat((Math.random() * 20 - 10).toFixed(2)),
    monthly: parseFloat((Math.random() * 40 - 20).toFixed(2))
  };
  
  // Calculate portfolio risk score
  const riskScore = calculatePortfolioRisk(allocation, marketData);
  
  // Determine risk level
  let riskLevel;
  if (riskScore < 0.3) {
    riskLevel = 'low';
  } else if (riskScore < 0.6) {
    riskLevel = 'medium';
  } else {
    riskLevel = 'high';
  }
  
  return {
    totalValue,
    performance,
    allocation,
    risk: {
      score: riskScore,
      level: riskLevel
    },
    lastUpdated: new Date().toISOString()
  };
}

/**
 * Calculates portfolio risk score
 * @param {Object} allocation - Portfolio allocation
 * @param {Object} marketData - Market data
 * @returns {number} Risk score between 0 and 1
 */
function calculatePortfolioRisk(allocation, marketData) {
  // In a real implementation, this would use correlation, volatility, etc.
  // For now, we'll use a simple implementation based on volatility
  
  // Define volatility scores for different tokens
  const volatilityScores = {
    BTC: 0.7,
    ETH: 0.65,
    SOL: 0.8,
    USDC: 0.05,
    USDT: 0.05,
    BNB: 0.6,
    MATIC: 0.75,
    LINK: 0.7,
    UNI: 0.75,
    AAVE: 0.7,
    QUICK: 0.8,
    RAY: 0.8,
    SRM: 0.75,
    CAKE: 0.7,
    ADA: 0.65,
    BUSD: 0.05
  };
  
  // Calculate weighted volatility
  let weightedVolatility = 0;
  let totalWeight = 0;
  
  for (const [token, data] of Object.entries(allocation)) {
    const volatility = volatilityScores[token] || 0.5;
    const weight = data.percentage || 0;
    
    weightedVolatility += volatility * weight;
    totalWeight += weight;
  }
  
  // Normalize to 0-1 range
  return totalWeight > 0 ? weightedVolatility / totalWeight / 100 : 0.5;
}

/**
 * Predicts price movement based on technical analysis
 * @param {string} token - Token symbol
 * @param {string} timeframe - Prediction timeframe (1d, 1w, 1m)
 * @returns {Promise<Object>} Price prediction
 */
async function predictPriceMovement(token, timeframe = '1d') {
  // In a real implementation, this would use ML models or technical analysis
  // For now, we'll use a simple implementation
  
  // Simulate analysis delay
  await new Promise(resolve => setTimeout(resolve, 1500));
  
  // Get current market data
  const marketData = generateMockMarketData(token);
  const currentPrice = marketData.price;
  
  // Generate random prediction factors
  const technicalFactor = Math.random() * 2 - 1; // -1 to 1
  const sentimentFactor = Math.random() * 2 - 1; // -1 to 1
  const fundamentalFactor = Math.random() * 2 - 1; // -1 to 1
  
  // Combine factors with weights
  const combinedFactor = (
    technicalFactor * 0.5 + 
    sentimentFactor * 0.3 + 
    fundamentalFactor * 0.2
  );
  
  // Calculate predicted change
  let predictedChange;
  if (timeframe === '1d') {
    predictedChange = combinedFactor * 5; // -5% to 5%
  } else if (timeframe === '1w') {
    predictedChange = combinedFactor * 15; // -15% to 15%
  } else if (timeframe === '1m') {
    predictedChange = combinedFactor * 30; // -30% to 30%
  } else {
    predictedChange = combinedFactor * 10; // -10% to 10%
  }
  
  // Calculate predicted price
  const predictedPrice = currentPrice * (1 + predictedChange / 100);
  
  // Determine confidence based on factor consistency
  const factorConsistency = Math.abs(
    (Math.sign(technicalFactor) === Math.sign(sentimentFactor) ? 1 : 0) +
    (Math.sign(sentimentFactor) === Math.sign(fundamentalFactor) ? 1 : 0) +
    (Math.sign(technicalFactor) === Math.sign(fundamentalFactor) ? 1 : 0)
  ) / 3;
  
  const confidence = 0.5 + factorConsistency * 0.4;
  
  // Determine direction
  const direction = predictedChange > 0 ? 'up' : predictedChange < 0 ? 'down' : 'sideways';
  
  return {
    token,
    timeframe,
    currentPrice,
    predictedPrice: parseFloat(predictedPrice.toFixed(6)),
    predictedChange: parseFloat(predictedChange.toFixed(2)),
    direction,
    confidence: parseFloat(confidence.toFixed(2)),
    factors: {
      technical: parseFloat(technicalFactor.toFixed(2)),
      sentiment: parseFloat(sentimentFactor.toFixed(2)),
      fundamental: parseFloat(fundamentalFactor.toFixed(2))
    },
    lastUpdated: new Date().toISOString()
  };
}

// Export functions
if (typeof module !== 'undefined' && module.exports) {
  module.exports = {
    fetchMarketData,
    generateMockMarketData,
    generatePriceHistory,
    getTokenName,
    fetchMarketSentiment,
    generateRandomSentiment,
    fetchTechnicalIndicators,
    analyzePortfolio,
    calculatePortfolioRisk,
    predictPriceMovement
  };
} else {
  // For browser environment
  window.marketDataUtils = {
    fetchMarketData,
    generateMockMarketData,
    generatePriceHistory,
    getTokenName,
    fetchMarketSentiment,
    generateRandomSentiment,
    fetchTechnicalIndicators,
    analyzePortfolio,
    calculatePortfolioRisk,
    predictPriceMovement
  };
}
