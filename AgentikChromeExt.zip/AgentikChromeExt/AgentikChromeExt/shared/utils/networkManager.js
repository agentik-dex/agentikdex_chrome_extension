/**
 * Agentik Wallet - Network Manager Utilities
 * 
 * This file contains utility functions for managing network requests,
 * API interactions, and handling network-related operations.
 */

/**
 * Request methods
 * @enum {string}
 */
const RequestMethods = {
  GET: 'GET',
  POST: 'POST',
  PUT: 'PUT',
  DELETE: 'DELETE',
  PATCH: 'PATCH'
};

/**
 * Content types
 * @enum {string}
 */
const ContentTypes = {
  JSON: 'application/json',
  FORM: 'application/x-www-form-urlencoded',
  TEXT: 'text/plain',
  HTML: 'text/html',
  XML: 'application/xml',
  MULTIPART: 'multipart/form-data'
};

/**
 * API endpoints
 * @enum {string}
 */
const ApiEndpoints = {
  // Placeholder for actual API endpoints
  // These would be populated from environment variables or config
  PRICE_API: 'https://api.example.com/prices',
  TRANSACTION_API: 'https://api.example.com/transactions',
  MARKET_DATA_API: 'https://api.example.com/market',
  NEWS_API: 'https://api.example.com/news',
  VOICE_PROCESSING_API: 'https://api.example.com/voice',
  AGENT_API: 'https://api.example.com/agent'
};

/**
 * Default network manager configuration
 * @type {Object}
 */
const DefaultNetworkConfig = {
  // Default timeout in milliseconds
  timeout: 30000,
  
  // Default number of retries
  maxRetries: 3,
  
  // Default retry delay in milliseconds
  retryDelay: 1000,
  
  // Whether to use exponential backoff for retries
  useExponentialBackoff: true,
  
  // Default headers
  defaultHeaders: {
    'Content-Type': ContentTypes.JSON,
    'Accept': ContentTypes.JSON
  },
  
  // Whether to cache responses
  cacheResponses: true,
  
  // Cache TTL in milliseconds (5 minutes)
  cacheTTL: 5 * 60 * 1000,
  
  // Whether to automatically handle rate limiting
  handleRateLimiting: true,
  
  // Whether to automatically refresh authentication tokens
  autoRefreshTokens: true,
  
  // Whether to log requests and responses
  logRequests: false,
  
  // Whether to include credentials in requests
  includeCredentials: false,
  
  // API keys for various services
  apiKeys: {}
};

/**
 * Response cache
 * @type {Map}
 */
const responseCache = new Map();

/**
 * Rate limit tracking
 * @type {Object}
 */
const rateLimitTracking = {};

/**
 * Current network configuration
 * @type {Object}
 */
let networkConfig = { ...DefaultNetworkConfig };

/**
 * Gets the network configuration
 * @returns {Promise<Object>} Network configuration
 */
async function getNetworkConfig() {
  try {
    // Try to get config from storage
    if (typeof chrome !== 'undefined' && chrome.storage && chrome.storage.local) {
      return await new Promise((resolve) => {
        chrome.storage.local.get('cryptovoice_network_config', (result) => {
          const storedConfig = result.cryptovoice_network_config || {};
          // Merge with default config
          networkConfig = { ...DefaultNetworkConfig, ...storedConfig };
          resolve(networkConfig);
        });
      });
    }
    
    return networkConfig;
  } catch (error) {
    console.error('Error getting network config:', error);
    return networkConfig;
  }
}

/**
 * Updates the network configuration
 * @param {Object} config - New network configuration
 * @returns {Promise<boolean>} Success status
 */
async function updateNetworkConfig(config) {
  try {
    // Merge with current config
    networkConfig = { ...networkConfig, ...config };
    
    // Save to storage if available
    if (typeof chrome !== 'undefined' && chrome.storage && chrome.storage.local) {
      await new Promise((resolve, reject) => {
        chrome.storage.local.set({ 'cryptovoice_network_config': networkConfig }, () => {
          if (chrome.runtime.lastError) {
            reject(chrome.runtime.lastError);
          } else {
            resolve();
          }
        });
      });
    }
    
    return true;
  } catch (error) {
    console.error('Error updating network config:', error);
    return false;
  }
}

/**
 * Resets the network configuration to defaults
 * @returns {Promise<boolean>} Success status
 */
async function resetNetworkConfig() {
  try {
    networkConfig = { ...DefaultNetworkConfig };
    
    // Save to storage if available
    if (typeof chrome !== 'undefined' && chrome.storage && chrome.storage.local) {
      await new Promise((resolve, reject) => {
        chrome.storage.local.set({ 'cryptovoice_network_config': networkConfig }, () => {
          if (chrome.runtime.lastError) {
            reject(chrome.runtime.lastError);
          } else {
            resolve();
          }
        });
      });
    }
    
    return true;
  } catch (error) {
    console.error('Error resetting network config:', error);
    return false;
  }
}

/**
 * Generates a cache key for a request
 * @param {string} url - Request URL
 * @param {Object} options - Request options
 * @returns {string} Cache key
 */
function generateCacheKey(url, options) {
  const method = options.method || RequestMethods.GET;
  const body = options.body ? JSON.stringify(options.body) : '';
  return `${method}:${url}:${body}`;
}

/**
 * Checks if a cached response is still valid
 * @param {Object} cachedResponse - Cached response
 * @returns {boolean} Whether the cached response is still valid
 */
function isCacheValid(cachedResponse) {
  if (!cachedResponse) return false;
  
  const now = Date.now();
  return now - cachedResponse.timestamp < networkConfig.cacheTTL;
}

/**
 * Calculates retry delay with exponential backoff
 * @param {number} retryCount - Retry count
 * @param {number} baseDelay - Base delay in milliseconds
 * @returns {number} Retry delay in milliseconds
 */
function calculateRetryDelay(retryCount, baseDelay) {
  if (networkConfig.useExponentialBackoff) {
    // Exponential backoff with jitter
    const exponentialDelay = baseDelay * Math.pow(2, retryCount);
    const jitter = Math.random() * 0.3 * exponentialDelay;
    return exponentialDelay + jitter;
  }
  
  return baseDelay;
}

/**
 * Handles rate limiting
 * @param {string} url - Request URL
 * @param {Object} response - Response object
 */
function handleRateLimit(url, response) {
  // Extract rate limit headers
  const remaining = parseInt(response.headers.get('X-RateLimit-Remaining') || '-1');
  const resetTime = parseInt(response.headers.get('X-RateLimit-Reset') || '0');
  const retryAfter = parseInt(response.headers.get('Retry-After') || '0');
  
  // Track rate limit for this endpoint
  const domain = new URL(url).hostname;
  rateLimitTracking[domain] = {
    remaining,
    resetTime: resetTime * 1000, // Convert to milliseconds
    retryAfter: retryAfter * 1000, // Convert to milliseconds
    timestamp: Date.now()
  };
}

/**
 * Checks if a request would exceed rate limits
 * @param {string} url - Request URL
 * @returns {boolean} Whether the request would exceed rate limits
 */
function wouldExceedRateLimit(url) {
  const domain = new URL(url).hostname;
  const rateLimit = rateLimitTracking[domain];
  
  if (!rateLimit) return false;
  
  // Check if we have any requests remaining
  if (rateLimit.remaining === 0) {
    const now = Date.now();
    
    // Check if reset time has passed
    if (rateLimit.resetTime && now < rateLimit.resetTime) {
      return true;
    }
    
    // Check if retry-after time has passed
    if (rateLimit.retryAfter && now < rateLimit.timestamp + rateLimit.retryAfter) {
      return true;
    }
  }
  
  return false;
}

/**
 * Waits until rate limit reset
 * @param {string} url - Request URL
 * @returns {Promise<void>} Promise that resolves when rate limit reset has passed
 */
async function waitForRateLimitReset(url) {
  const domain = new URL(url).hostname;
  const rateLimit = rateLimitTracking[domain];
  
  if (!rateLimit) return;
  
  const now = Date.now();
  
  // Calculate wait time based on reset time or retry-after
  let waitTime = 0;
  
  if (rateLimit.resetTime && now < rateLimit.resetTime) {
    waitTime = rateLimit.resetTime - now + 1000; // Add 1 second buffer
  } else if (rateLimit.retryAfter && now < rateLimit.timestamp + rateLimit.retryAfter) {
    waitTime = rateLimit.timestamp + rateLimit.retryAfter - now + 1000; // Add 1 second buffer
  }
  
  if (waitTime > 0) {
    await new Promise(resolve => setTimeout(resolve, waitTime));
  }
}

/**
 * Makes a network request
 * @param {string} url - Request URL
 * @param {Object} options - Request options
 * @param {boolean} useCache - Whether to use cache
 * @returns {Promise<Object>} Response data
 */
async function makeRequest(url, options = {}, useCache = true) {
  try {
    // Get network config
    await getNetworkConfig();
    
    // Check if we're offline
    if (typeof navigator !== 'undefined' && !navigator.onLine) {
      throw new Error('Network is offline');
    }
    
    // Merge options with defaults
    const requestOptions = {
      method: RequestMethods.GET,
      headers: { ...networkConfig.defaultHeaders },
      timeout: networkConfig.timeout,
      credentials: networkConfig.includeCredentials ? 'include' : 'same-origin',
      ...options,
      headers: { ...networkConfig.defaultHeaders, ...options.headers }
    };
    
    // Check cache for GET requests
    if (useCache && networkConfig.cacheResponses && requestOptions.method === RequestMethods.GET) {
      const cacheKey = generateCacheKey(url, requestOptions);
      const cachedResponse = responseCache.get(cacheKey);
      
      if (isCacheValid(cachedResponse)) {
        return cachedResponse.data;
      }
    }
    
    // Handle rate limiting if enabled
    if (networkConfig.handleRateLimiting && wouldExceedRateLimit(url)) {
      await waitForRateLimitReset(url);
    }
    
    // Make the request with retries
    let response;
    let error;
    let retryCount = 0;
    
    while (retryCount <= networkConfig.maxRetries) {
      try {
        // Create AbortController for timeout
        const controller = new AbortController();
        const timeoutId = setTimeout(() => controller.abort(), networkConfig.timeout);
        
        // Add signal to request options
        const optionsWithSignal = {
          ...requestOptions,
          signal: controller.signal
        };
        
        // Make the request
        response = await fetch(url, optionsWithSignal);
        
        // Clear timeout
        clearTimeout(timeoutId);
        
        // Track rate limits if enabled
        if (networkConfig.handleRateLimiting) {
          handleRateLimit(url, response);
        }
        
        // Handle response status
        if (response.ok) {
          break;
        } else if (response.status === 429) {
          // Rate limited, wait and retry
          const retryAfter = parseInt(response.headers.get('Retry-After') || '1');
          await new Promise(resolve => setTimeout(resolve, retryAfter * 1000));
          retryCount++;
        } else if (response.status >= 500) {
          // Server error, retry
          error = new Error(`Server error: ${response.status}`);
          retryCount++;
          await new Promise(resolve => setTimeout(
            resolve, 
            calculateRetryDelay(retryCount, networkConfig.retryDelay)
          ));
        } else {
          // Client error, don't retry
          const responseText = await response.text();
          error = new Error(`Request failed with status ${response.status}: ${responseText}`);
          break;
        }
      } catch (e) {
        // Network error or timeout
        error = e;
        retryCount++;
        
        // Don't retry if we're offline
        if (typeof navigator !== 'undefined' && !navigator.onLine) {
          error = new Error('Network is offline');
          break;
        }
        
        // Don't retry if aborted
        if (e.name === 'AbortError') {
          error = new Error('Request timed out');
          break;
        }
        
        // Wait before retrying
        await new Promise(resolve => setTimeout(
          resolve, 
          calculateRetryDelay(retryCount, networkConfig.retryDelay)
        ));
      }
    }
    
    // If we exhausted retries or had an error, throw it
    if (!response || !response.ok) {
      throw error || new Error(`Request failed after ${retryCount} retries`);
    }
    
    // Parse response based on content type
    let data;
    const contentType = response.headers.get('Content-Type') || '';
    
    if (contentType.includes('application/json')) {
      data = await response.json();
    } else if (contentType.includes('text/')) {
      data = await response.text();
    } else {
      // Binary data
      data = await response.blob();
    }
    
    // Cache response for GET requests
    if (useCache && networkConfig.cacheResponses && requestOptions.method === RequestMethods.GET) {
      const cacheKey = generateCacheKey(url, requestOptions);
      responseCache.set(cacheKey, {
        data,
        timestamp: Date.now()
      });
    }
    
    // Log request if enabled
    if (networkConfig.logRequests && typeof window !== 'undefined' && window.errorManagerUtils) {
      window.errorManagerUtils.logInfo(
        'N000', // Info code
        `Request to ${url} succeeded`,
        null,
        {
          url,
          method: requestOptions.method,
          status: response.status,
          contentType
        }
      );
    }
    
    return data;
  } catch (error) {
    // Log error if enabled
    if (typeof window !== 'undefined' && window.errorManagerUtils) {
      window.errorManagerUtils.logError(
        'N001', // Network request failed
        `Request to ${url} failed: ${error.message}`,
        'network',
        3, // High severity
        error,
        {
          url,
          method: options.method || RequestMethods.GET
        }
      );
    } else {
      console.error('Network request failed:', error);
    }
    
    throw error;
  }
}

/**
 * Makes a GET request
 * @param {string} url - Request URL
 * @param {Object} options - Request options
 * @param {boolean} useCache - Whether to use cache
 * @returns {Promise<Object>} Response data
 */
async function get(url, options = {}, useCache = true) {
  return makeRequest(url, { ...options, method: RequestMethods.GET }, useCache);
}

/**
 * Makes a POST request
 * @param {string} url - Request URL
 * @param {Object} data - Request data
 * @param {Object} options - Request options
 * @returns {Promise<Object>} Response data
 */
async function post(url, data, options = {}) {
  const requestOptions = {
    ...options,
    method: RequestMethods.POST,
    body: JSON.stringify(data)
  };
  
  return makeRequest(url, requestOptions, false);
}

/**
 * Makes a PUT request
 * @param {string} url - Request URL
 * @param {Object} data - Request data
 * @param {Object} options - Request options
 * @returns {Promise<Object>} Response data
 */
async function put(url, data, options = {}) {
  const requestOptions = {
    ...options,
    method: RequestMethods.PUT,
    body: JSON.stringify(data)
  };
  
  return makeRequest(url, requestOptions, false);
}

/**
 * Makes a DELETE request
 * @param {string} url - Request URL
 * @param {Object} options - Request options
 * @returns {Promise<Object>} Response data
 */
async function del(url, options = {}) {
  const requestOptions = {
    ...options,
    method: RequestMethods.DELETE
  };
  
  return makeRequest(url, requestOptions, false);
}

/**
 * Makes a PATCH request
 * @param {string} url - Request URL
 * @param {Object} data - Request data
 * @param {Object} options - Request options
 * @returns {Promise<Object>} Response data
 */
async function patch(url, data, options = {}) {
  const requestOptions = {
    ...options,
    method: RequestMethods.PATCH,
    body: JSON.stringify(data)
  };
  
  return makeRequest(url, requestOptions, false);
}

/**
 * Clears the response cache
 * @param {string} url - Optional URL to clear cache for
 */
function clearCache(url = null) {
  if (url) {
    // Clear cache for specific URL
    for (const [key, _] of responseCache.entries()) {
      if (key.includes(url)) {
        responseCache.delete(key);
      }
    }
  } else {
    // Clear entire cache
    responseCache.clear();
  }
}

/**
 * Gets the cache size
 * @returns {number} Cache size
 */
function getCacheSize() {
  return responseCache.size;
}

/**
 * Gets the cache contents
 * @returns {Object} Cache contents
 */
function getCacheContents() {
  const contents = {};
  
  for (const [key, value] of responseCache.entries()) {
    contents[key] = {
      timestamp: value.timestamp,
      age: Date.now() - value.timestamp,
      isValid: isCacheValid(value)
    };
  }
  
  return contents;
}

/**
 * Gets the rate limit status
 * @returns {Object} Rate limit status
 */
function getRateLimitStatus() {
  const now = Date.now();
  const status = {};
  
  for (const [domain, rateLimit] of Object.entries(rateLimitTracking)) {
    status[domain] = {
      remaining: rateLimit.remaining,
      resetTime: rateLimit.resetTime,
      retryAfter: rateLimit.retryAfter,
      timeUntilReset: Math.max(0, rateLimit.resetTime - now),
      timeUntilRetry: Math.max(0, rateLimit.timestamp + rateLimit.retryAfter - now),
      isLimited: wouldExceedRateLimit(`https://${domain}`)
    };
  }
  
  return status;
}

/**
 * Checks if the network is online
 * @returns {boolean} Whether the network is online
 */
function isOnline() {
  return typeof navigator !== 'undefined' ? navigator.onLine : true;
}

/**
 * Sets up network status listeners
 * @param {Function} onlineCallback - Callback for online event
 * @param {Function} offlineCallback - Callback for offline event
 * @returns {Function} Function to remove listeners
 */
function setupNetworkListeners(onlineCallback, offlineCallback) {
  if (typeof window === 'undefined') {
    return () => {};
  }
  
  // Add listeners
  window.addEventListener('online', onlineCallback);
  window.addEventListener('offline', offlineCallback);
  
  // Return function to remove listeners
  return () => {
    window.removeEventListener('online', onlineCallback);
    window.removeEventListener('offline', offlineCallback);
  };
}

/**
 * Formats a URL with query parameters
 * @param {string} url - Base URL
 * @param {Object} params - Query parameters
 * @returns {string} Formatted URL
 */
function formatUrl(url, params = {}) {
  const urlObj = new URL(url);
  
  // Add query parameters
  for (const [key, value] of Object.entries(params)) {
    if (value !== undefined && value !== null) {
      urlObj.searchParams.append(key, value);
    }
  }
  
  return urlObj.toString();
}

/**
 * Gets data from an API endpoint
 * @param {string} endpoint - API endpoint
 * @param {Object} params - Query parameters
 * @param {Object} options - Request options
 * @returns {Promise<Object>} Response data
 */
async function getFromApi(endpoint, params = {}, options = {}) {
  // Format URL with query parameters
  const url = formatUrl(endpoint, params);
  
  // Make GET request
  return get(url, options);
}

/**
 * Posts data to an API endpoint
 * @param {string} endpoint - API endpoint
 * @param {Object} data - Request data
 * @param {Object} options - Request options
 * @returns {Promise<Object>} Response data
 */
async function postToApi(endpoint, data = {}, options = {}) {
  // Make POST request
  return post(endpoint, data, options);
}

/**
 * Fetches price data for tokens
 * @param {Array<string>} tokens - Token symbols
 * @param {string} currency - Currency to convert to
 * @returns {Promise<Object>} Price data
 */
async function fetchPriceData(tokens, currency = 'USD') {
  try {
    // Get API endpoint from config
    const endpoint = ApiEndpoints.PRICE_API;
    
    // Make request
    return await getFromApi(endpoint, {
      symbols: tokens.join(','),
      currency
    });
  } catch (error) {
    console.error('Error fetching price data:', error);
    throw error;
  }
}

/**
 * Fetches market data
 * @param {string} market - Market symbol
 * @param {string} timeframe - Timeframe
 * @returns {Promise<Object>} Market data
 */
async function fetchMarketData(market, timeframe = '1d') {
  try {
    // Get API endpoint from config
    const endpoint = ApiEndpoints.MARKET_DATA_API;
    
    // Make request
    return await getFromApi(endpoint, {
      market,
      timeframe
    });
  } catch (error) {
    console.error('Error fetching market data:', error);
    throw error;
  }
}

/**
 * Fetches news data
 * @param {string} category - News category
 * @param {number} limit - Number of news items to fetch
 * @returns {Promise<Object>} News data
 */
async function fetchNewsData(category = 'crypto', limit = 10) {
  try {
    // Get API endpoint from config
    const endpoint = ApiEndpoints.NEWS_API;
    
    // Make request
    return await getFromApi(endpoint, {
      category,
      limit
    });
  } catch (error) {
    console.error('Error fetching news data:', error);
    throw error;
  }
}

/**
 * Processes voice data
 * @param {Blob} audioData - Audio data
 * @returns {Promise<Object>} Processing result
 */
async function processVoiceData(audioData) {
  try {
    // Get API endpoint from config
    const endpoint = ApiEndpoints.VOICE_PROCESSING_API;
    
    // Create form data
    const formData = new FormData();
    formData.append('audio', audioData);
    
    // Make request
    return await makeRequest(endpoint, {
      method: RequestMethods.POST,
      body: formData,
      headers: {
        // Don't set Content-Type, it will be set automatically for FormData
      }
    }, false);
  } catch (error) {
    console.error('Error processing voice data:', error);
    throw error;
  }
}

/**
 * Gets agent decision
 * @param {Object} context - Agent context
 * @returns {Promise<Object>} Agent decision
 */
async function getAgentDecision(context) {
  try {
    // Get API endpoint from config
    const endpoint = ApiEndpoints.AGENT_API;
    
    // Make request
    return await postToApi(endpoint, context);
  } catch (error) {
    console.error('Error getting agent decision:', error);
    throw error;
  }
}

/**
 * Initializes the network manager
 * @returns {Promise<boolean>} Success status
 */
async function initNetworkManager() {
  try {
    // Get network config
    await getNetworkConfig();
    
    // Set up network listeners
    setupNetworkListeners(
      // Online callback
      () => {
        if (typeof window !== 'undefined' && window.errorManagerUtils) {
          window.errorManagerUtils.logInfo(
            'N003', // Network online
            'Network is online',
            'network'
          );
        }
      },
      // Offline callback
      () => {
        if (typeof window !== 'undefined' && window.errorManagerUtils) {
          window.errorManagerUtils.logError(
            'N003', // Network offline
            'Network is offline',
            'network',
            2, // Medium severity
            null,
            {}
          );
        }
      }
    );
    
    return true;
  } catch (error) {
    console.error('Error initializing network manager:', error);
    return false;
  }
}

// Initialize network manager when the module is loaded
if (typeof window !== 'undefined') {
  initNetworkManager().catch(console.error);
}

// Export functions and constants
if (typeof module !== 'undefined' && module.exports) {
  module.exports = {
    RequestMethods,
    ContentTypes,
    ApiEndpoints,
    DefaultNetworkConfig,
    getNetworkConfig,
    updateNetworkConfig,
    resetNetworkConfig,
    makeRequest,
    get,
    post,
    put,
    del,
    patch,
    clearCache,
    getCacheSize,
    getCacheContents,
    getRateLimitStatus,
    isOnline,
    setupNetworkListeners,
    formatUrl,
    getFromApi,
    postToApi,
    fetchPriceData,
    fetchMarketData,
    fetchNewsData,
    processVoiceData,
    getAgentDecision,
    initNetworkManager
  };
} else {
  // For browser environment
  window.networkManagerUtils = {
    RequestMethods,
    ContentTypes,
    ApiEndpoints,
    DefaultNetworkConfig,
    getNetworkConfig,
    updateNetworkConfig,
    resetNetworkConfig,
    makeRequest,
    get,
    post,
    put,
    del,
    patch,
    clearCache,
    getCacheSize,
    getCacheContents,
    getRateLimitStatus,
    isOnline,
    setupNetworkListeners,
    formatUrl,
    getFromApi,
    postToApi,
    fetchPriceData,
    fetchMarketData,
    fetchNewsData,
    processVoiceData,
    getAgentDecision,
    initNetworkManager
  };
}
