/**
 * CryptoVoice - Trading Agent Utilities
 * 
 * This file contains utility functions for the autonomous trading agent.
 */

/**
 * Generates a trading decision based on market data and risk profile
 * @param {Object} marketData - Current market data
 * @param {Object} portfolio - User's portfolio
 * @param {Object} riskProfile - User's risk profile
 * @returns {Object} Trading decision
 */
function generateTradingDecision(marketData, portfolio, riskProfile) {
  // In a real implementation, this would use sophisticated algorithms
  // For now, we'll use a simple mock implementation
  
  // Get available assets
  const availableAssets = Object.keys(portfolio.balances || {});
  if (availableAssets.length === 0) {
    return {
      action: 'hold',
      asset: null,
      amount: 0,
      reasoning: 'No assets available for trading',
      confidence: 0.5,
      riskScore: 0.1
    };
  }
  
  // Randomly select an action based on risk profile
  const actions = ['buy', 'sell', 'hold', 'swap'];
  let actionWeights;
  
  switch (riskProfile.tolerance) {
    case 'conservative':
      actionWeights = [0.2, 0.2, 0.5, 0.1]; // More likely to hold
      break;
    case 'moderate':
      actionWeights = [0.3, 0.3, 0.3, 0.1]; // Balanced
      break;
    case 'aggressive':
      actionWeights = [0.4, 0.4, 0.1, 0.1]; // More likely to buy/sell
      break;
    default:
      actionWeights = [0.25, 0.25, 0.4, 0.1]; // Default to slightly conservative
  }
  
  const action = weightedRandomChoice(actions, actionWeights);
  
  // Select an asset
  const asset = availableAssets[Math.floor(Math.random() * availableAssets.length)];
  
  // Determine amount based on risk profile and portfolio
  const balance = portfolio.balances[asset] || 0;
  let amount = 0;
  
  if (action === 'buy' || action === 'swap') {
    // For buy/swap, use a percentage of available funds based on risk profile
    const maxPositionSize = riskProfile.maxPositionSize || 10;
    amount = balance * (maxPositionSize / 100) * (0.5 + Math.random() * 0.5);
  } else if (action === 'sell') {
    // For sell, use a percentage of the asset balance
    amount = balance * (0.1 + Math.random() * 0.4);
  }
  
  // Round to reasonable precision
  amount = parseFloat(amount.toFixed(6));
  
  // Generate reasoning
  const reasoning = generateDecisionReasoning(action, asset, marketData);
  
  // Calculate confidence and risk score
  const confidence = 0.5 + Math.random() * 0.4;
  const riskScore = calculateRiskScore(action, asset, amount, portfolio, riskProfile);
  
  return {
    action,
    asset,
    amount,
    reasoning,
    confidence,
    riskScore
  };
}

/**
 * Generates reasoning for a trading decision
 * @param {string} action - The trading action
 * @param {string} asset - The asset symbol
 * @param {Object} marketData - Current market data
 * @returns {string} Reasoning text
 */
function generateDecisionReasoning(action, asset, marketData) {
  const reasons = {
    buy: [
      `${asset} is showing bullish momentum with increasing volume`,
      `${asset} has formed a strong support level and is likely to bounce`,
      `${asset} is undervalued based on fundamental analysis`,
      `${asset} has positive news sentiment and increasing social media mentions`
    ],
    sell: [
      `${asset} is approaching resistance levels and showing signs of reversal`,
      `${asset} has declining volume and momentum indicators suggest a pullback`,
      `${asset} has reached the target profit threshold`,
      `${asset} has negative news sentiment and decreasing social media interest`
    ],
    hold: [
      `${asset} is in a consolidation phase with low volatility`,
      `${asset} market conditions are uncertain, waiting for clearer signals`,
      `${asset} position is currently at a loss, but fundamentals remain strong`,
      `${asset} has stable metrics and no significant market catalysts`
    ],
    swap: [
      `${asset} has underperformed compared to other assets in the portfolio`,
      `Diversification opportunity by reducing ${asset} exposure`,
      `${asset} correlation with other portfolio assets is too high`,
      `Better yield opportunities exist in other assets than ${asset}`
    ]
  };
  
  const reasonList = reasons[action] || reasons.hold;
  return reasonList[Math.floor(Math.random() * reasonList.length)];
}

/**
 * Calculates a risk score for a trading decision
 * @param {string} action - The trading action
 * @param {string} asset - The asset symbol
 * @param {number} amount - The trading amount
 * @param {Object} portfolio - User's portfolio
 * @param {Object} riskProfile - User's risk profile
 * @returns {number} Risk score between 0 and 1
 */
function calculateRiskScore(action, asset, amount, portfolio, riskProfile) {
  // Base risk by action
  const actionRisk = {
    buy: 0.6,
    sell: 0.4,
    hold: 0.1,
    swap: 0.5
  }[action] || 0.5;
  
  // Asset volatility factor (would use real data in production)
  const assetVolatility = {
    BTC: 0.7,
    ETH: 0.65,
    SOL: 0.8,
    USDC: 0.1,
    USDT: 0.1,
    BNB: 0.6,
    ADA: 0.7,
    MATIC: 0.75
  }[asset] || 0.5;
  
  // Position size risk
  const totalPortfolioValue = calculatePortfolioValue(portfolio);
  const positionSizeRisk = totalPortfolioValue > 0 
    ? (amount * getAssetPrice(asset)) / totalPortfolioValue 
    : 0.5;
  
  // Combine factors with weights
  const riskScore = (
    actionRisk * 0.3 +
    assetVolatility * 0.4 +
    positionSizeRisk * 0.3
  );
  
  // Normalize to 0-1 range
  return Math.min(1, Math.max(0, riskScore));
}

/**
 * Calculates the total portfolio value
 * @param {Object} portfolio - User's portfolio
 * @returns {number} Total portfolio value in USD
 */
function calculatePortfolioValue(portfolio) {
  let totalValue = 0;
  
  if (!portfolio || !portfolio.balances) {
    return 0;
  }
  
  for (const [asset, amount] of Object.entries(portfolio.balances)) {
    totalValue += amount * getAssetPrice(asset);
  }
  
  return totalValue;
}

/**
 * Gets the current price of an asset (mock implementation)
 * @param {string} asset - The asset symbol
 * @returns {number} Current price in USD
 */
function getAssetPrice(asset) {
  // Mock prices for demonstration
  const prices = {
    BTC: 35000,
    ETH: 2000,
    SOL: 80,
    USDC: 1,
    USDT: 1,
    BNB: 300,
    ADA: 0.5,
    MATIC: 0.8
  };
  
  return prices[asset] || 1;
}

/**
 * Makes a weighted random choice from an array
 * @param {Array} items - Array of items to choose from
 * @param {Array} weights - Array of weights corresponding to items
 * @returns {*} Randomly selected item
 */
function weightedRandomChoice(items, weights) {
  if (!items || !weights || items.length !== weights.length || items.length === 0) {
    return null;
  }
  
  // Calculate sum of weights
  const totalWeight = weights.reduce((sum, weight) => sum + weight, 0);
  
  // Generate random value between 0 and total weight
  const randomValue = Math.random() * totalWeight;
  
  // Find the item that corresponds to the random value
  let weightSum = 0;
  for (let i = 0; i < items.length; i++) {
    weightSum += weights[i];
    if (randomValue <= weightSum) {
      return items[i];
    }
  }
  
  // Fallback (should rarely happen)
  return items[0];
}

/**
 * Evaluates agent performance based on trading history
 * @param {Array} tradingHistory - Array of past trading decisions and outcomes
 * @returns {Object} Performance metrics
 */
function evaluateAgentPerformance(tradingHistory) {
  // In a real implementation, this would analyze actual trading outcomes
  // For now, we'll generate mock performance metrics
  
  const now = new Date();
  const dayStart = new Date(now);
  dayStart.setHours(0, 0, 0, 0);
  
  const weekStart = new Date(now);
  weekStart.setDate(now.getDate() - now.getDay());
  weekStart.setHours(0, 0, 0, 0);
  
  const monthStart = new Date(now);
  monthStart.setDate(1);
  monthStart.setHours(0, 0, 0, 0);
  
  // Generate random performance metrics
  // In reality, these would be calculated from actual trading results
  const dailyProfit = (Math.random() * 200) - 50; // Between -$50 and $150
  const weeklyProfit = dailyProfit * (2 + Math.random() * 3); // Roughly 2-5x daily
  const monthlyProfit = weeklyProfit * (2 + Math.random() * 2); // Roughly 2-4x weekly
  
  // Generate random number of active positions
  const activePositions = Math.floor(Math.random() * 5) + 1; // 1-5 positions
  
  return {
    dailyProfit,
    weeklyProfit,
    monthlyProfit,
    activePositions
  };
}

/**
 * Generates a risk profile based on user preferences
 * @param {string} tolerance - Risk tolerance level
 * @param {number} targetReturn - Target monthly return percentage
 * @param {number} dailyLimit - Daily trading limit in USD
 * @returns {Object} Risk profile configuration
 */
function generateRiskProfile(tolerance = 'moderate', targetReturn = 5, dailyLimit = 1000) {
  // Base settings by tolerance level
  const baseSettings = {
    conservative: {
      maxDailyLoss: 1, // 1% of portfolio
      maxPositionSize: 5, // 5% per position
      tradingFrequency: 'low', // 1-3 trades per day
      volatilityPreference: 'low',
      allowedAssets: ['BTC', 'ETH', 'USDC', 'USDT']
    },
    moderate: {
      maxDailyLoss: 3, // 3% of portfolio
      maxPositionSize: 10, // 10% per position
      tradingFrequency: 'medium', // 3-7 trades per day
      volatilityPreference: 'medium',
      allowedAssets: ['BTC', 'ETH', 'SOL', 'BNB', 'USDC', 'USDT']
    },
    aggressive: {
      maxDailyLoss: 7, // 7% of portfolio
      maxPositionSize: 20, // 20% per position
      tradingFrequency: 'high', // 7+ trades per day
      volatilityPreference: 'high',
      allowedAssets: ['BTC', 'ETH', 'SOL', 'BNB', 'ADA', 'MATIC', 'USDC', 'USDT']
    }
  };
  
  // Get base settings for the selected tolerance
  const settings = baseSettings[tolerance] || baseSettings.moderate;
  
  // Adjust settings based on target return
  // Higher target return means more aggressive settings
  const targetReturnFactor = targetReturn / 5; // 5% is the baseline
  
  settings.maxPositionSize = Math.min(30, Math.round(settings.maxPositionSize * targetReturnFactor));
  settings.maxDailyLoss = Math.min(10, settings.maxDailyLoss * targetReturnFactor);
  
  // Add user-specific settings
  settings.tolerance = tolerance;
  settings.targetReturn = targetReturn;
  settings.dailyLimit = dailyLimit;
  
  // Add restrictions based on risk tolerance
  settings.restrictions = [];
  if (tolerance === 'conservative') {
    settings.restrictions.push('no_leverage', 'no_defi_yield_farming');
  } else if (tolerance === 'moderate') {
    settings.restrictions.push('max_2x_leverage', 'limited_yield_farming');
  }
  
  return settings;
}

// Export functions
if (typeof module !== 'undefined' && module.exports) {
  module.exports = {
    generateTradingDecision,
    generateDecisionReasoning,
    calculateRiskScore,
    calculatePortfolioValue,
    getAssetPrice,
    evaluateAgentPerformance,
    generateRiskProfile
  };
} else {
  // For browser environment
  window.tradingAgent = {
    generateTradingDecision,
    generateDecisionReasoning,
    calculateRiskScore,
    calculatePortfolioValue,
    getAssetPrice,
    evaluateAgentPerformance,
    generateRiskProfile
  };
}
