/**
 * Agentik Wallet - UI Component Utilities
 * 
 * This file contains utility functions for creating and managing UI components.
 */

/**
 * Creates a toast notification element
 * @param {string} message - Notification message
 * @param {string} type - Notification type (success, error, warning, info)
 * @param {number} duration - Duration in milliseconds
 * @returns {HTMLElement} Toast element
 */
function createToast(message, type = 'info', duration = 3000) {
  // Create toast container if it doesn't exist
  let toastContainer = document.getElementById('cryptovoice-toast-container');
  if (!toastContainer) {
    toastContainer = document.createElement('div');
    toastContainer.id = 'cryptovoice-toast-container';
    toastContainer.style.position = 'fixed';
    toastContainer.style.bottom = '20px';
    toastContainer.style.left = '20px';
    toastContainer.style.zIndex = '10000';
    toastContainer.style.display = 'flex';
    toastContainer.style.flexDirection = 'column';
    toastContainer.style.gap = '10px';
    document.body.appendChild(toastContainer);
  }
  
  // Create toast element
  const toast = document.createElement('div');
  toast.className = `cryptovoice-toast cryptovoice-toast-${type}`;
  toast.innerHTML = `
    <div class="cryptovoice-toast-icon">
      ${getToastIcon(type)}
    </div>
    <div class="cryptovoice-toast-message">${message}</div>
    <div class="cryptovoice-toast-close">×</div>
  `;
  
  // Style toast
  toast.style.display = 'flex';
  toast.style.alignItems = 'center';
  toast.style.padding = '12px 16px';
  toast.style.borderRadius = '6px';
  toast.style.boxShadow = '0 4px 12px rgba(0, 0, 0, 0.15)';
  toast.style.marginBottom = '10px';
  toast.style.minWidth = '250px';
  toast.style.maxWidth = '350px';
  toast.style.animation = 'cryptovoice-toast-in 0.3s ease-out forwards';
  toast.style.cursor = 'default';
  
  // Set background color based on type
  switch (type) {
    case 'success':
      toast.style.backgroundColor = '#4CAF50';
      toast.style.color = 'white';
      break;
    case 'error':
      toast.style.backgroundColor = '#F44336';
      toast.style.color = 'white';
      break;
    case 'warning':
      toast.style.backgroundColor = '#FF9800';
      toast.style.color = 'white';
      break;
    case 'info':
    default:
      toast.style.backgroundColor = '#2196F3';
      toast.style.color = 'white';
      break;
  }
  
  // Style toast message
  const messageElement = toast.querySelector('.cryptovoice-toast-message');
  if (messageElement) {
    messageElement.style.flex = '1';
    messageElement.style.marginLeft = '10px';
    messageElement.style.marginRight = '10px';
  }
  
  // Style close button
  const closeButton = toast.querySelector('.cryptovoice-toast-close');
  if (closeButton) {
    closeButton.style.fontSize = '20px';
    closeButton.style.fontWeight = 'bold';
    closeButton.style.cursor = 'pointer';
    closeButton.style.opacity = '0.7';
    closeButton.style.transition = 'opacity 0.2s';
    
    // Add hover effect
    closeButton.addEventListener('mouseover', () => {
      closeButton.style.opacity = '1';
    });
    
    closeButton.addEventListener('mouseout', () => {
      closeButton.style.opacity = '0.7';
    });
    
    // Add click handler
    closeButton.addEventListener('click', () => {
      removeToast(toast);
    });
  }
  
  // Add to container
  toastContainer.appendChild(toast);
  
  // Auto-remove after duration
  if (duration > 0) {
    setTimeout(() => {
      removeToast(toast);
    }, duration);
  }
  
  return toast;
}

/**
 * Gets the icon for a toast notification
 * @param {string} type - Notification type
 * @returns {string} Icon HTML
 */
function getToastIcon(type) {
  switch (type) {
    case 'success':
      return '<svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"></path><polyline points="22 4 12 14.01 9 11.01"></polyline></svg>';
    case 'error':
      return '<svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"></circle><line x1="15" y1="9" x2="9" y2="15"></line><line x1="9" y1="9" x2="15" y2="15"></line></svg>';
    case 'warning':
      return '<svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M10.29 3.86L1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z"></path><line x1="12" y1="9" x2="12" y2="13"></line><line x1="12" y1="17" x2="12.01" y2="17"></line></svg>';
    case 'info':
    default:
      return '<svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"></circle><line x1="12" y1="16" x2="12" y2="12"></line><line x1="12" y1="8" x2="12.01" y2="8"></line></svg>';
  }
}

/**
 * Removes a toast notification
 * @param {HTMLElement} toast - Toast element to remove
 */
function removeToast(toast) {
  if (!toast) return;
  
  // Add exit animation
  toast.style.animation = 'cryptovoice-toast-out 0.3s ease-out forwards';
  
  // Remove after animation
  setTimeout(() => {
    if (toast.parentNode) {
      toast.parentNode.removeChild(toast);
    }
    
    // Remove container if empty
    const toastContainer = document.getElementById('cryptovoice-toast-container');
    if (toastContainer && toastContainer.children.length === 0) {
      document.body.removeChild(toastContainer);
    }
  }, 300);
}

/**
 * Adds CSS animations for toasts
 */
function addToastAnimations() {
  // Check if animations already exist
  if (document.getElementById('cryptovoice-toast-animations')) {
    return;
  }
  
  // Create style element
  const style = document.createElement('style');
  style.id = 'cryptovoice-toast-animations';
  style.textContent = `
    @keyframes cryptovoice-toast-in {
      from {
        transform: translateX(-100%);
        opacity: 0;
      }
      to {
        transform: translateX(0);
        opacity: 1;
      }
    }
    
    @keyframes cryptovoice-toast-out {
      from {
        transform: translateX(0);
        opacity: 1;
      }
      to {
        transform: translateX(-100%);
        opacity: 0;
      }
    }
  `;
  
  // Add to document
  document.head.appendChild(style);
}

/**
 * Creates a modal dialog
 * @param {Object} options - Modal options
 * @returns {Object} Modal object with show and hide methods
 */
function createModal(options = {}) {
  // Default options
  const defaults = {
    title: 'Agentik Wallet',
    content: '',
    width: '400px',
    height: 'auto',
    closable: true,
    onClose: null,
    buttons: []
  };
  
  // Merge options
  const settings = { ...defaults, ...options };
  
  // Create modal elements
  const overlay = document.createElement('div');
  overlay.className = 'cryptovoice-modal-overlay';
  
  const modalContainer = document.createElement('div');
  modalContainer.className = 'cryptovoice-modal-container';
  
  const modal = document.createElement('div');
  modal.className = 'cryptovoice-modal';
  
  const modalHeader = document.createElement('div');
  modalHeader.className = 'cryptovoice-modal-header';
  
  const modalTitle = document.createElement('div');
  modalTitle.className = 'cryptovoice-modal-title';
  modalTitle.textContent = settings.title;
  
  const modalClose = document.createElement('div');
  modalClose.className = 'cryptovoice-modal-close';
  modalClose.innerHTML = '&times;';
  
  const modalBody = document.createElement('div');
  modalBody.className = 'cryptovoice-modal-body';
  
  const modalFooter = document.createElement('div');
  modalFooter.className = 'cryptovoice-modal-footer';
  
  // Set content
  if (typeof settings.content === 'string') {
    modalBody.innerHTML = settings.content;
  } else if (settings.content instanceof HTMLElement) {
    modalBody.appendChild(settings.content);
  }
  
  // Add buttons
  if (settings.buttons && settings.buttons.length > 0) {
    settings.buttons.forEach(button => {
      const btn = document.createElement('button');
      btn.className = `cryptovoice-modal-button ${button.className || ''}`;
      btn.textContent = button.text || 'Button';
      
      // Add click handler
      if (button.onClick) {
        btn.addEventListener('click', button.onClick);
      }
      
      // Add to footer
      modalFooter.appendChild(btn);
    });
  }
  
  // Assemble modal
  modalHeader.appendChild(modalTitle);
  if (settings.closable) {
    modalHeader.appendChild(modalClose);
  }
  
  modal.appendChild(modalHeader);
  modal.appendChild(modalBody);
  
  if (settings.buttons && settings.buttons.length > 0) {
    modal.appendChild(modalFooter);
  }
  
  modalContainer.appendChild(modal);
  overlay.appendChild(modalContainer);
  
  // Style overlay
  overlay.style.position = 'fixed';
  overlay.style.top = '0';
  overlay.style.left = '0';
  overlay.style.width = '100%';
  overlay.style.height = '100%';
  overlay.style.backgroundColor = 'rgba(0, 0, 0, 0.5)';
  overlay.style.display = 'flex';
  overlay.style.justifyContent = 'center';
  overlay.style.alignItems = 'center';
  overlay.style.zIndex = '10000';
  overlay.style.opacity = '0';
  overlay.style.transition = 'opacity 0.3s ease';
  
  // Style modal container
  modalContainer.style.display = 'flex';
  modalContainer.style.justifyContent = 'center';
  modalContainer.style.alignItems = 'center';
  modalContainer.style.width = '100%';
  modalContainer.style.height = '100%';
  modalContainer.style.padding = '20px';
  
  // Style modal
  modal.style.backgroundColor = 'white';
  modal.style.borderRadius = '8px';
  modal.style.boxShadow = '0 4px 16px rgba(0, 0, 0, 0.2)';
  modal.style.width = settings.width;
  modal.style.maxWidth = '90%';
  modal.style.height = settings.height;
  modal.style.maxHeight = '90vh';
  modal.style.display = 'flex';
  modal.style.flexDirection = 'column';
  modal.style.transform = 'scale(0.8)';
  modal.style.transition = 'transform 0.3s ease';
  
  // Style header
  modalHeader.style.display = 'flex';
  modalHeader.style.justifyContent = 'space-between';
  modalHeader.style.alignItems = 'center';
  modalHeader.style.padding = '16px';
  modalHeader.style.borderBottom = '1px solid #eee';
  
  // Style title
  modalTitle.style.fontWeight = 'bold';
  modalTitle.style.fontSize = '18px';
  
  // Style close button
  if (settings.closable) {
    modalClose.style.fontSize = '24px';
    modalClose.style.fontWeight = 'bold';
    modalClose.style.cursor = 'pointer';
    modalClose.style.opacity = '0.7';
    modalClose.style.transition = 'opacity 0.2s';
    
    // Add hover effect
    modalClose.addEventListener('mouseover', () => {
      modalClose.style.opacity = '1';
    });
    
    modalClose.addEventListener('mouseout', () => {
      modalClose.style.opacity = '0.7';
    });
    
    // Add click handler
    modalClose.addEventListener('click', () => {
      hideModal();
      if (settings.onClose) {
        settings.onClose();
      }
    });
  }
  
  // Style body
  modalBody.style.padding = '16px';
  modalBody.style.overflowY = 'auto';
  modalBody.style.flex = '1';
  
  // Style footer
  if (settings.buttons && settings.buttons.length > 0) {
    modalFooter.style.display = 'flex';
    modalFooter.style.justifyContent = 'flex-end';
    modalFooter.style.padding = '16px';
    modalFooter.style.borderTop = '1px solid #eee';
    modalFooter.style.gap = '8px';
  }
  
  // Style buttons
  const buttons = modalFooter.querySelectorAll('.cryptovoice-modal-button');
  buttons.forEach(button => {
    button.style.padding = '8px 16px';
    button.style.borderRadius = '4px';
    button.style.border = 'none';
    button.style.cursor = 'pointer';
    button.style.fontWeight = 'bold';
    button.style.transition = 'background-color 0.2s';
    
    // Default button style
    if (!button.classList.contains('primary') && !button.classList.contains('danger')) {
      button.style.backgroundColor = '#f0f0f0';
      button.style.color = '#333';
      
      // Add hover effect
      button.addEventListener('mouseover', () => {
        button.style.backgroundColor = '#e0e0e0';
      });
      
      button.addEventListener('mouseout', () => {
        button.style.backgroundColor = '#f0f0f0';
      });
    }
    
    // Primary button style
    if (button.classList.contains('primary')) {
      button.style.backgroundColor = '#6200EA';
      button.style.color = 'white';
      
      // Add hover effect
      button.addEventListener('mouseover', () => {
        button.style.backgroundColor = '#7C4DFF';
      });
      
      button.addEventListener('mouseout', () => {
        button.style.backgroundColor = '#6200EA';
      });
    }
    
    // Danger button style
    if (button.classList.contains('danger')) {
      button.style.backgroundColor = '#F44336';
      button.style.color = 'white';
      
      // Add hover effect
      button.addEventListener('mouseover', () => {
        button.style.backgroundColor = '#FF5252';
      });
      
      button.addEventListener('mouseout', () => {
        button.style.backgroundColor = '#F44336';
      });
    }
  });
  
  // Add click outside to close
  if (settings.closable) {
    overlay.addEventListener('click', (event) => {
      if (event.target === overlay || event.target === modalContainer) {
        hideModal();
        if (settings.onClose) {
          settings.onClose();
        }
      }
    });
  }
  
  // Show modal function
  function showModal() {
    // Add to document
    document.body.appendChild(overlay);
    
    // Trigger reflow
    overlay.offsetHeight;
    
    // Show with animation
    overlay.style.opacity = '1';
    modal.style.transform = 'scale(1)';
    
    // Prevent body scrolling
    document.body.style.overflow = 'hidden';
    
    return modalApi;
  }
  
  // Hide modal function
  function hideModal() {
    // Hide with animation
    overlay.style.opacity = '0';
    modal.style.transform = 'scale(0.8)';
    
    // Remove after animation
    setTimeout(() => {
      if (overlay.parentNode) {
        overlay.parentNode.removeChild(overlay);
      }
      
      // Restore body scrolling
      document.body.style.overflow = '';
    }, 300);
    
    return modalApi;
  }
  
  // Update content function
  function updateContent(content) {
    // Clear current content
    while (modalBody.firstChild) {
      modalBody.removeChild(modalBody.firstChild);
    }
    
    // Set new content
    if (typeof content === 'string') {
      modalBody.innerHTML = content;
    } else if (content instanceof HTMLElement) {
      modalBody.appendChild(content);
    }
    
    return modalApi;
  }
  
  // Update title function
  function updateTitle(title) {
    modalTitle.textContent = title;
    return modalApi;
  }
  
  // Modal API
  const modalApi = {
    show: showModal,
    hide: hideModal,
    updateContent,
    updateTitle,
    overlay,
    modal,
    modalBody
  };
  
  return modalApi;
}

/**
 * Creates a loading spinner
 * @param {Object} options - Spinner options
 * @returns {HTMLElement} Spinner element
 */
function createSpinner(options = {}) {
  // Default options
  const defaults = {
    size: '40px',
    color: '#6200EA',
    thickness: '4px',
    message: '',
    overlay: false
  };
  
  // Merge options
  const settings = { ...defaults, ...options };
  
  // Create container
  const container = document.createElement('div');
  container.className = 'cryptovoice-spinner-container';
  
  // Create spinner
  const spinner = document.createElement('div');
  spinner.className = 'cryptovoice-spinner';
  
  // Create message
  let message = null;
  if (settings.message) {
    message = document.createElement('div');
    message.className = 'cryptovoice-spinner-message';
    message.textContent = settings.message;
  }
  
  // Style container
  if (settings.overlay) {
    container.style.position = 'fixed';
    container.style.top = '0';
    container.style.left = '0';
    container.style.width = '100%';
    container.style.height = '100%';
    container.style.backgroundColor = 'rgba(0, 0, 0, 0.5)';
    container.style.display = 'flex';
    container.style.flexDirection = 'column';
    container.style.justifyContent = 'center';
    container.style.alignItems = 'center';
    container.style.zIndex = '10000';
  } else {
    container.style.display = 'flex';
    container.style.flexDirection = 'column';
    container.style.justifyContent = 'center';
    container.style.alignItems = 'center';
  }
  
  // Style spinner
  spinner.style.width = settings.size;
  spinner.style.height = settings.size;
  spinner.style.border = `${settings.thickness} solid rgba(0, 0, 0, 0.1)`;
  spinner.style.borderTopColor = settings.color;
  spinner.style.borderRadius = '50%';
  spinner.style.animation = 'cryptovoice-spinner-rotate 1s linear infinite';
  
  // Style message
  if (message) {
    message.style.marginTop = '10px';
    message.style.color = settings.overlay ? 'white' : '#333';
    message.style.fontWeight = 'bold';
  }
  
  // Add spinner animation
  addSpinnerAnimation();
  
  // Assemble spinner
  container.appendChild(spinner);
  if (message) {
    container.appendChild(message);
  }
  
  return container;
}

/**
 * Adds CSS animations for spinner
 */
function addSpinnerAnimation() {
  // Check if animation already exists
  if (document.getElementById('cryptovoice-spinner-animation')) {
    return;
  }
  
  // Create style element
  const style = document.createElement('style');
  style.id = 'cryptovoice-spinner-animation';
  style.textContent = `
    @keyframes cryptovoice-spinner-rotate {
      0% {
        transform: rotate(0deg);
      }
      100% {
        transform: rotate(360deg);
      }
    }
  `;
  
  // Add to document
  document.head.appendChild(style);
}

/**
 * Creates a voice recording indicator
 * @param {Object} options - Indicator options
 * @returns {Object} Indicator object with show and hide methods
 */
function createVoiceIndicator(options = {}) {
  // Default options
  const defaults = {
    size: '60px',
    color: '#6200EA',
    pulseColor: 'rgba(98, 0, 234, 0.4)',
    message: 'Listening...',
    position: 'bottom-right'
  };
  
  // Merge options
  const settings = { ...defaults, ...options };
  
  // Create container
  const container = document.createElement('div');
  container.className = 'cryptovoice-voice-indicator';
  
  // Create indicator
  const indicator = document.createElement('div');
  indicator.className = 'cryptovoice-voice-indicator-circle';
  
  // Create pulse
  const pulse = document.createElement('div');
  pulse.className = 'cryptovoice-voice-indicator-pulse';
  
  // Create message
  const message = document.createElement('div');
  message.className = 'cryptovoice-voice-indicator-message';
  message.textContent = settings.message;
  
  // Style container
  container.style.position = 'fixed';
  container.style.display = 'flex';
  container.style.flexDirection = 'column';
  container.style.alignItems = 'center';
  container.style.zIndex = '10000';
  container.style.opacity = '0';
  container.style.transition = 'opacity 0.3s ease';
  
  // Set position
  switch (settings.position) {
    case 'top-left':
      container.style.top = '20px';
      container.style.left = '20px';
      break;
    case 'top-right':
      container.style.top = '20px';
      container.style.right = '20px';
      break;
    case 'bottom-left':
      container.style.bottom = '20px';
      container.style.left = '20px';
      break;
    case 'bottom-right':
    default:
      container.style.bottom = '20px';
      container.style.right = '20px';
      break;
  }
  
  // Style indicator
  indicator.style.width = settings.size;
  indicator.style.height = settings.size;
  indicator.style.borderRadius = '50%';
  indicator.style.backgroundColor = settings.color;
  indicator.style.display = 'flex';
  indicator.style.justifyContent = 'center';
  indicator.style.alignItems = 'center';
  indicator.style.position = 'relative';
  
  // Add microphone icon
  indicator.innerHTML = `
    <svg xmlns="http://www.w3.org/2000/svg" width="${parseInt(settings.size) / 2}" height="${parseInt(settings.size) / 2}" viewBox="0 0 24 24" fill="none" stroke="white" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
      <path d="M12 1a3 3 0 0 0-3 3v8a3 3 0 0 0 6 0V4a3 3 0 0 0-3-3z"></path>
      <path d="M19 10v2a7 7 0 0 1-14 0v-2"></path>
      <line x1="12" y1="19" x2="12" y2="23"></line>
      <line x1="8" y1="23" x2="16" y2="23"></line>
    </svg>
  `;
  
  // Style pulse
  pulse.style.position = 'absolute';
  pulse.style.top = '0';
  pulse.style.left = '0';
  pulse.style.width = '100%';
  pulse.style.height = '100%';
  pulse.style.borderRadius = '50%';
  pulse.style.backgroundColor = settings.pulseColor;
  pulse.style.animation = 'cryptovoice-voice-pulse 1.5s ease-out infinite';
  
  // Style message
  message.style.marginTop = '10px';
  message.style.color = '#333';
  message.style.fontWeight = 'bold';
  
  // Add pulse animation
  addVoiceIndicatorAnimation();
  
  // Assemble indicator
  indicator.appendChild(pulse);
  container.appendChild(indicator);
  container.appendChild(message);
  
  // Show indicator function
  function showIndicator() {
    // Add to document if not already added
    if (!container.parentNode) {
      document.body.appendChild(container);
    }
    
    // Show with animation
    setTimeout(() => {
      container.style.opacity = '1';
    }, 10);
    
    return indicatorApi;
  }
  
  // Hide indicator function
  function hideIndicator() {
    // Hide with animation
    container.style.opacity = '0';
    
    // Remove after animation
    setTimeout(() => {
      if (container.parentNode) {
        container.parentNode.removeChild(container);
      }
    }, 300);
    
    return indicatorApi;
  }
  
  // Update message function
  function updateMessage(newMessage) {
    message.textContent = newMessage;
    return indicatorApi;
  }
  
  // Indicator API
  const indicatorApi = {
    show: showIndicator,
    hide: hideIndicator,
    updateMessage,
    container
  };
  
  return indicatorApi;
}

/**
 * Adds CSS animations for voice indicator
 */
function addVoiceIndicatorAnimation() {
  // Check if animation already exists
  if (document.getElementById('cryptovoice-voice-indicator-animation')) {
    return;
  }
  
  // Create style element
  const style = document.createElement('style');
  style.id = 'cryptovoice-voice-indicator-animation';
  style.textContent = `
    @keyframes cryptovoice-voice-pulse {
      0% {
        transform: scale(1);
        opacity: 1;
      }
      100% {
        transform: scale(1.5);
        opacity: 0;
      }
    }
  `;
  
  // Add to document
  document.head.appendChild(style);
}

// Export functions
if (typeof module !== 'undefined' && module.exports) {
  module.exports = {
    createToast,
    removeToast,
    addToastAnimations,
    createModal,
    createSpinner,
    createVoiceIndicator
  };
} else {
  // For browser environment
  window.uiComponentUtils = {
    createToast,
    removeToast,
    addToastAnimations,
    createModal,
    createSpinner,
    createVoiceIndicator
  };
}
