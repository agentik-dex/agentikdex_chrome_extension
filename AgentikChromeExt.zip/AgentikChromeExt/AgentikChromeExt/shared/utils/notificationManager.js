/**
 * CryptoVoice - Notification Manager Utilities
 * 
 * This file contains utility functions for managing notifications across
 * the extension's components.
 */

/**
 * Notification types
 * @enum {string}
 */
const NotificationTypes = {
  // Transaction notifications
  TRANSACTION_SENT: 'transaction_sent',
  TRANSACTION_CONFIRMED: 'transaction_confirmed',
  TRANSACTION_FAILED: 'transaction_failed',
  
  // Wallet notifications
  WALLET_CONNECTED: 'wallet_connected',
  WALLET_DISCONNECTED: 'wallet_disconnected',
  BALANCE_UPDATED: 'balance_updated',
  TOKEN_RECEIVED: 'token_received',
  
  // Trading agent notifications
  AGENT_DECISION: 'agent_decision',
  AGENT_TRADE_EXECUTED: 'agent_trade_executed',
  AGENT_TRADE_FAILED: 'agent_trade_failed',
  
  // Price notifications
  PRICE_ALERT: 'price_alert',
  PRICE_CHANGE: 'price_change',
  
  // Security notifications
  SECURITY_WARNING: 'security_warning',
  SUSPICIOUS_ACTIVITY: 'suspicious_activity',
  
  // Voice notifications
  VOICE_COMMAND_RECOGNIZED: 'voice_command_recognized',
  VOICE_AUTH_SUCCESS: 'voice_auth_success',
  VOICE_AUTH_FAILED: 'voice_auth_failed',
  
  // DeFi notifications
  DEFI_PLATFORM_DETECTED: 'defi_platform_detected',
  DEFI_INTERACTION_COMPLETED: 'defi_interaction_completed',
  
  // System notifications
  SYSTEM_UPDATE: 'system_update',
  ERROR: 'error'
};

/**
 * Notification priorities
 * @enum {number}
 */
const NotificationPriorities = {
  LOW: 0,
  NORMAL: 1,
  HIGH: 2
};

/**
 * Default notification settings
 * @type {Object}
 */
const DefaultNotificationSettings = {
  // Whether notifications are enabled
  enabled: true,
  
  // Whether to show Chrome notifications
  showChromeNotifications: true,
  
  // Whether to show in-app notifications
  showInAppNotifications: true,
  
  // Whether to play sounds
  playSounds: true,
  
  // Whether to show badge text
  showBadgeText: true,
  
  // Notification timeout in milliseconds (5 seconds)
  timeout: 5000,
  
  // Per-type settings
  typeSettings: {
    [NotificationTypes.TRANSACTION_SENT]: {
      enabled: true,
      priority: NotificationPriorities.NORMAL,
      sound: 'transaction.mp3'
    },
    [NotificationTypes.TRANSACTION_CONFIRMED]: {
      enabled: true,
      priority: NotificationPriorities.NORMAL,
      sound: 'success.mp3'
    },
    [NotificationTypes.TRANSACTION_FAILED]: {
      enabled: true,
      priority: NotificationPriorities.HIGH,
      sound: 'error.mp3'
    },
    [NotificationTypes.WALLET_CONNECTED]: {
      enabled: true,
      priority: NotificationPriorities.LOW,
      sound: 'connect.mp3'
    },
    [NotificationTypes.WALLET_DISCONNECTED]: {
      enabled: true,
      priority: NotificationPriorities.LOW,
      sound: 'disconnect.mp3'
    },
    [NotificationTypes.BALANCE_UPDATED]: {
      enabled: false,
      priority: NotificationPriorities.LOW,
      sound: null
    },
    [NotificationTypes.TOKEN_RECEIVED]: {
      enabled: true,
      priority: NotificationPriorities.NORMAL,
      sound: 'receive.mp3'
    },
    [NotificationTypes.AGENT_DECISION]: {
      enabled: true,
      priority: NotificationPriorities.NORMAL,
      sound: 'agent.mp3'
    },
    [NotificationTypes.AGENT_TRADE_EXECUTED]: {
      enabled: true,
      priority: NotificationPriorities.NORMAL,
      sound: 'success.mp3'
    },
    [NotificationTypes.AGENT_TRADE_FAILED]: {
      enabled: true,
      priority: NotificationPriorities.HIGH,
      sound: 'error.mp3'
    },
    [NotificationTypes.PRICE_ALERT]: {
      enabled: true,
      priority: NotificationPriorities.HIGH,
      sound: 'alert.mp3'
    },
    [NotificationTypes.PRICE_CHANGE]: {
      enabled: false,
      priority: NotificationPriorities.LOW,
      sound: null
    },
    [NotificationTypes.SECURITY_WARNING]: {
      enabled: true,
      priority: NotificationPriorities.HIGH,
      sound: 'warning.mp3'
    },
    [NotificationTypes.SUSPICIOUS_ACTIVITY]: {
      enabled: true,
      priority: NotificationPriorities.HIGH,
      sound: 'warning.mp3'
    },
    [NotificationTypes.VOICE_COMMAND_RECOGNIZED]: {
      enabled: false,
      priority: NotificationPriorities.LOW,
      sound: null
    },
    [NotificationTypes.VOICE_AUTH_SUCCESS]: {
      enabled: false,
      priority: NotificationPriorities.LOW,
      sound: 'success.mp3'
    },
    [NotificationTypes.VOICE_AUTH_FAILED]: {
      enabled: true,
      priority: NotificationPriorities.NORMAL,
      sound: 'error.mp3'
    },
    [NotificationTypes.DEFI_PLATFORM_DETECTED]: {
      enabled: true,
      priority: NotificationPriorities.LOW,
      sound: null
    },
    [NotificationTypes.DEFI_INTERACTION_COMPLETED]: {
      enabled: true,
      priority: NotificationPriorities.NORMAL,
      sound: 'success.mp3'
    },
    [NotificationTypes.SYSTEM_UPDATE]: {
      enabled: true,
      priority: NotificationPriorities.NORMAL,
      sound: null
    },
    [NotificationTypes.ERROR]: {
      enabled: true,
      priority: NotificationPriorities.HIGH,
      sound: 'error.mp3'
    }
  }
};

/**
 * Gets notification settings
 * @returns {Promise<Object>} Notification settings
 */
async function getNotificationSettings() {
  try {
    // Try to get settings from config manager if available
    if (typeof window.configManagerUtils !== 'undefined' && 
        typeof window.configManagerUtils.getConfigSection === 'function') {
      const notificationSettings = await window.configManagerUtils.getConfigSection('notifications');
      if (notificationSettings) {
        return mergeSettings(DefaultNotificationSettings, notificationSettings);
      }
    }
    
    // Fallback to Chrome storage
    return await new Promise((resolve) => {
      chrome.storage.local.get('cryptovoice_notification_settings', (result) => {
        const settings = result.cryptovoice_notification_settings;
        resolve(settings ? mergeSettings(DefaultNotificationSettings, settings) : { ...DefaultNotificationSettings });
      });
    });
  } catch (error) {
    console.error('Error getting notification settings:', error);
    return { ...DefaultNotificationSettings };
  }
}

/**
 * Updates notification settings
 * @param {Object} settings - New notification settings
 * @returns {Promise<boolean>} Success status
 */
async function updateNotificationSettings(settings) {
  try {
    // Get current settings
    const currentSettings = await getNotificationSettings();
    
    // Merge with new settings
    const mergedSettings = mergeSettings(currentSettings, settings);
    
    // Try to update settings in config manager if available
    if (typeof window.configManagerUtils !== 'undefined' && 
        typeof window.configManagerUtils.updateConfigSection === 'function') {
      await window.configManagerUtils.updateConfigSection('notifications', mergedSettings);
    }
    
    // Also update in Chrome storage
    await new Promise((resolve, reject) => {
      chrome.storage.local.set({ 'cryptovoice_notification_settings': mergedSettings }, () => {
        if (chrome.runtime.lastError) {
          reject(chrome.runtime.lastError);
        } else {
          resolve();
        }
      });
    });
    
    return true;
  } catch (error) {
    console.error('Error updating notification settings:', error);
    return false;
  }
}

/**
 * Merges notification settings
 * @param {Object} baseSettings - Base settings
 * @param {Object} newSettings - New settings
 * @returns {Object} Merged settings
 */
function mergeSettings(baseSettings, newSettings) {
  // Create a deep copy of the base settings
  const mergedSettings = JSON.parse(JSON.stringify(baseSettings));
  
  // Merge top-level settings
  for (const [key, value] of Object.entries(newSettings)) {
    if (key !== 'typeSettings') {
      mergedSettings[key] = value;
    }
  }
  
  // Merge type settings
  if (newSettings.typeSettings) {
    for (const [type, settings] of Object.entries(newSettings.typeSettings)) {
      if (mergedSettings.typeSettings[type]) {
        mergedSettings.typeSettings[type] = {
          ...mergedSettings.typeSettings[type],
          ...settings
        };
      } else {
        mergedSettings.typeSettings[type] = { ...settings };
      }
    }
  }
  
  return mergedSettings;
}

/**
 * Resets notification settings to defaults
 * @returns {Promise<boolean>} Success status
 */
async function resetNotificationSettings() {
  try {
    // Try to reset settings in config manager if available
    if (typeof window.configManagerUtils !== 'undefined' && 
        typeof window.configManagerUtils.updateConfigSection === 'function') {
      await window.configManagerUtils.updateConfigSection('notifications', { ...DefaultNotificationSettings });
    }
    
    // Also reset in Chrome storage
    await new Promise((resolve, reject) => {
      chrome.storage.local.set({ 'cryptovoice_notification_settings': { ...DefaultNotificationSettings } }, () => {
        if (chrome.runtime.lastError) {
          reject(chrome.runtime.lastError);
        } else {
          resolve();
        }
      });
    });
    
    return true;
  } catch (error) {
    console.error('Error resetting notification settings:', error);
    return false;
  }
}

/**
 * Shows a notification
 * @param {string} type - Notification type from NotificationTypes enum
 * @param {string} title - Notification title
 * @param {string} message - Notification message
 * @param {Object} options - Additional options
 * @returns {Promise<boolean>} Success status
 */
async function showNotification(type, title, message, options = {}) {
  try {
    // Get notification settings
    const settings = await getNotificationSettings();
    
    // Skip if notifications are disabled
    if (!settings.enabled) {
      return false;
    }
    
    // Get type-specific settings
    const typeSettings = settings.typeSettings[type] || {
      enabled: true,
      priority: NotificationPriorities.NORMAL,
      sound: null
    };
    
    // Skip if this type is disabled
    if (!typeSettings.enabled) {
      return false;
    }
    
    // Create notification object
    const notification = {
      id: generateNotificationId(),
      type,
      title,
      message,
      timestamp: Date.now(),
      priority: options.priority || typeSettings.priority,
      data: options.data || {},
      read: false
    };
    
    // Store notification
    await storeNotification(notification);
    
    // Show Chrome notification if enabled
    if (settings.showChromeNotifications) {
      await showChromeNotification(notification);
    }
    
    // Show in-app notification if enabled
    if (settings.showInAppNotifications) {
      await showInAppNotification(notification);
    }
    
    // Play sound if enabled
    if (settings.playSounds && typeSettings.sound) {
      await playNotificationSound(typeSettings.sound);
    }
    
    // Update badge if enabled
    if (settings.showBadgeText) {
      await updateBadgeText();
    }
    
    // Notify about new notification
    notifyNewNotification(notification);
    
    return true;
  } catch (error) {
    console.error('Error showing notification:', error);
    return false;
  }
}

/**
 * Generates a unique notification ID
 * @returns {string} Notification ID
 */
function generateNotificationId() {
  return 'notif_' + Math.random().toString(36).substring(2, 15) + 
         Math.random().toString(36).substring(2, 15) + 
         '_' + Date.now();
}

/**
 * Stores a notification
 * @param {Object} notification - Notification object
 * @returns {Promise<boolean>} Success status
 */
async function storeNotification(notification) {
  try {
    // Get existing notifications
    const notifications = await getStoredNotifications();
    
    // Add new notification
    notifications.unshift(notification);
    
    // Trim notifications if too many (keep last 50)
    const trimmedNotifications = notifications.slice(0, 50);
    
    // Save notifications
    await new Promise((resolve, reject) => {
      chrome.storage.local.set({ 'cryptovoice_notifications': trimmedNotifications }, () => {
        if (chrome.runtime.lastError) {
          reject(chrome.runtime.lastError);
        } else {
          resolve();
        }
      });
    });
    
    return true;
  } catch (error) {
    console.error('Error storing notification:', error);
    return false;
  }
}

/**
 * Gets stored notifications
 * @returns {Promise<Array>} Array of stored notifications
 */
async function getStoredNotifications() {
  try {
    return await new Promise((resolve, reject) => {
      chrome.storage.local.get('cryptovoice_notifications', (result) => {
        if (chrome.runtime.lastError) {
          reject(chrome.runtime.lastError);
        } else {
          resolve(result.cryptovoice_notifications || []);
        }
      });
    });
  } catch (error) {
    console.error('Error getting stored notifications:', error);
    return [];
  }
}

/**
 * Shows a Chrome notification
 * @param {Object} notification - Notification object
 * @returns {Promise<boolean>} Success status
 */
async function showChromeNotification(notification) {
  try {
    // Check if Chrome notifications API is available
    if (typeof chrome.notifications === 'undefined') {
      return false;
    }
    
    // Create notification options
    const options = {
      type: 'basic',
      iconUrl: '../assets/icons/icon48.png',
      title: notification.title,
      message: notification.message,
      priority: notification.priority
    };
    
    // Show notification
    await new Promise((resolve) => {
      chrome.notifications.create(notification.id, options, () => {
        resolve();
      });
    });
    
    return true;
  } catch (error) {
    console.error('Error showing Chrome notification:', error);
    return false;
  }
}

/**
 * Shows an in-app notification
 * @param {Object} notification - Notification object
 * @returns {Promise<boolean>} Success status
 */
async function showInAppNotification(notification) {
  try {
    // Check if UI components are available
    if (typeof window.uiComponentUtils !== 'undefined' && 
        typeof window.uiComponentUtils.createToast === 'function') {
      // Map notification priority to toast type
      let toastType = 'info';
      
      if (notification.priority === NotificationPriorities.HIGH) {
        toastType = 'error';
      } else if (notification.type === NotificationTypes.SECURITY_WARNING || 
                notification.type === NotificationTypes.SUSPICIOUS_ACTIVITY) {
        toastType = 'warning';
      } else if (notification.type === NotificationTypes.TRANSACTION_CONFIRMED || 
                notification.type === NotificationTypes.AGENT_TRADE_EXECUTED) {
        toastType = 'success';
      }
      
      // Create toast notification
      window.uiComponentUtils.createToast(
        notification.message,
        toastType,
        5000,
        notification.title
      );
      
      return true;
    }
    
    return false;
  } catch (error) {
    console.error('Error showing in-app notification:', error);
    return false;
  }
}

/**
 * Plays a notification sound
 * @param {string} sound - Sound file name
 * @returns {Promise<boolean>} Success status
 */
async function playNotificationSound(sound) {
  try {
    // Create audio element
    const audio = new Audio(chrome.runtime.getURL(`assets/sounds/${sound}`));
    
    // Play sound
    await audio.play();
    
    return true;
  } catch (error) {
    console.error('Error playing notification sound:', error);
    return false;
  }
}

/**
 * Updates the extension badge text
 * @returns {Promise<boolean>} Success status
 */
async function updateBadgeText() {
  try {
    // Check if badge API is available
    if (typeof chrome.action === 'undefined' || typeof chrome.action.setBadgeText === 'undefined') {
      return false;
    }
    
    // Get unread notifications count
    const notifications = await getStoredNotifications();
    const unreadCount = notifications.filter(notification => !notification.read).length;
    
    // Set badge text
    await new Promise((resolve) => {
      chrome.action.setBadgeText({ 
        text: unreadCount > 0 ? unreadCount.toString() : '' 
      }, resolve);
    });
    
    // Set badge background color
    await new Promise((resolve) => {
      chrome.action.setBadgeBackgroundColor({ color: '#FF5722' }, resolve);
    });
    
    return true;
  } catch (error) {
    console.error('Error updating badge text:', error);
    return false;
  }
}

/**
 * Marks a notification as read
 * @param {string} id - Notification ID
 * @returns {Promise<boolean>} Success status
 */
async function markNotificationAsRead(id) {
  try {
    // Get stored notifications
    const notifications = await getStoredNotifications();
    
    // Find and update notification
    const updated = notifications.map(notification => {
      if (notification.id === id) {
        return { ...notification, read: true };
      }
      return notification;
    });
    
    // Save updated notifications
    await new Promise((resolve, reject) => {
      chrome.storage.local.set({ 'cryptovoice_notifications': updated }, () => {
        if (chrome.runtime.lastError) {
          reject(chrome.runtime.lastError);
        } else {
          resolve();
        }
      });
    });
    
    // Update badge
    await updateBadgeText();
    
    return true;
  } catch (error) {
    console.error('Error marking notification as read:', error);
    return false;
  }
}

/**
 * Marks all notifications as read
 * @returns {Promise<boolean>} Success status
 */
async function markAllNotificationsAsRead() {
  try {
    // Get stored notifications
    const notifications = await getStoredNotifications();
    
    // Mark all as read
    const updated = notifications.map(notification => {
      return { ...notification, read: true };
    });
    
    // Save updated notifications
    await new Promise((resolve, reject) => {
      chrome.storage.local.set({ 'cryptovoice_notifications': updated }, () => {
        if (chrome.runtime.lastError) {
          reject(chrome.runtime.lastError);
        } else {
          resolve();
        }
      });
    });
    
    // Update badge
    await updateBadgeText();
    
    return true;
  } catch (error) {
    console.error('Error marking all notifications as read:', error);
    return false;
  }
}

/**
 * Clears all notifications
 * @returns {Promise<boolean>} Success status
 */
async function clearAllNotifications() {
  try {
    // Clear stored notifications
    await new Promise((resolve, reject) => {
      chrome.storage.local.set({ 'cryptovoice_notifications': [] }, () => {
        if (chrome.runtime.lastError) {
          reject(chrome.runtime.lastError);
        } else {
          resolve();
        }
      });
    });
    
    // Update badge
    await updateBadgeText();
    
    return true;
  } catch (error) {
    console.error('Error clearing all notifications:', error);
    return false;
  }
}

/**
 * Notifies about a new notification
 * @param {Object} notification - Notification object
 */
function notifyNewNotification(notification) {
  // Dispatch event for in-page components
  const event = new CustomEvent('cryptovoice:newNotification', {
    detail: { notification }
  });
  
  window.dispatchEvent(event);
}

/**
 * Listens for new notifications
 * @param {Function} callback - Callback function
 * @returns {Function} Function to remove the listener
 */
function onNewNotification(callback) {
  // Create event listener
  const handleEvent = (event) => {
    callback(event.detail.notification);
  };
  
  // Add event listener
  window.addEventListener('cryptovoice:newNotification', handleEvent);
  
  // Return function to remove listener
  return () => {
    window.removeEventListener('cryptovoice:newNotification', handleEvent);
  };
}

/**
 * Gets notifications filtered by type
 * @param {string} type - Notification type from NotificationTypes enum
 * @returns {Promise<Array>} Filtered notifications
 */
async function getNotificationsByType(type) {
  try {
    // Get all notifications
    const notifications = await getStoredNotifications();
    
    // Filter by type
    return notifications.filter(notification => notification.type === type);
  } catch (error) {
    console.error('Error getting notifications by type:', error);
    return [];
  }
}

/**
 * Gets unread notifications
 * @returns {Promise<Array>} Unread notifications
 */
async function getUnreadNotifications() {
  try {
    // Get all notifications
    const notifications = await getStoredNotifications();
    
    // Filter unread
    return notifications.filter(notification => !notification.read);
  } catch (error) {
    console.error('Error getting unread notifications:', error);
    return [];
  }
}

// Export functions and constants
if (typeof module !== 'undefined' && module.exports) {
  module.exports = {
    NotificationTypes,
    NotificationPriorities,
    DefaultNotificationSettings,
    getNotificationSettings,
    updateNotificationSettings,
    resetNotificationSettings,
    showNotification,
    getStoredNotifications,
    markNotificationAsRead,
    markAllNotificationsAsRead,
    clearAllNotifications,
    getNotificationsByType,
    getUnreadNotifications,
    onNewNotification,
    updateBadgeText
  };
} else {
  // For browser environment
  window.notificationManagerUtils = {
    NotificationTypes,
    NotificationPriorities,
    DefaultNotificationSettings,
    getNotificationSettings,
    updateNotificationSettings,
    resetNotificationSettings,
    showNotification,
    getStoredNotifications,
    markNotificationAsRead,
    markAllNotificationsAsRead,
    clearAllNotifications,
    getNotificationsByType,
    getUnreadNotifications,
    onNewNotification,
    updateBadgeText
  };
}
