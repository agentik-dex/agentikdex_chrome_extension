/**
 * CryptoVoice - State Manager Utilities
 * 
 * This file contains utility functions for managing application state
 * across different components of the extension.
 */

/**
 * State namespaces
 * @enum {string}
 */
const StateNamespaces = {
  // Wallet state
  WALLET: 'wallet',
  
  // Voice state
  VOICE: 'voice',
  
  // Trading agent state
  AGENT: 'agent',
  
  // UI state
  UI: 'ui',
  
  // DeFi platform state
  DEFI: 'defi',
  
  // Session state
  SESSION: 'session'
};

/**
 * Default initial state
 * @type {Object}
 */
const DefaultState = {
  [StateNamespaces.WALLET]: {
    connected: false,
    address: null,
    network: null,
    balances: {},
    tokens: [],
    transactions: [],
    pendingTransactions: []
  },
  
  [StateNamespaces.VOICE]: {
    listening: false,
    processing: false,
    authenticated: false,
    lastCommand: null,
    commandHistory: [],
    voiceProfileEnrolled: false
  },
  
  [StateNamespaces.AGENT]: {
    enabled: false,
    riskProfile: 'moderate',
    decisions: [],
    pendingDecisions: [],
    performance: {
      totalTrades: 0,
      successfulTrades: 0,
      failedTrades: 0,
      profitLoss: 0,
      profitLossPercentage: 0
    },
    lastUpdated: null
  },
  
  [StateNamespaces.UI]: {
    currentView: 'home',
    sidebarOpen: false,
    modalOpen: null,
    notifications: [],
    theme: 'light',
    loading: false
  },
  
  [StateNamespaces.DEFI]: {
    activePlatform: null,
    detectedPlatforms: [],
    formData: null,
    buttonVisible: false
  },
  
  [StateNamespaces.SESSION]: {
    initialized: false,
    lastActive: Date.now(),
    loggedIn: false,
    syncStatus: null,
    errors: []
  }
};

/**
 * State subscribers
 * @type {Object}
 */
const subscribers = {
  global: [],
  namespaced: {}
};

/**
 * Current state
 * @type {Object}
 */
let currentState = JSON.parse(JSON.stringify(DefaultState));

/**
 * Gets the current state
 * @param {string} namespace - State namespace (optional)
 * @returns {Object} Current state
 */
function getState(namespace = null) {
  if (namespace) {
    return JSON.parse(JSON.stringify(currentState[namespace] || {}));
  }
  return JSON.parse(JSON.stringify(currentState));
}

/**
 * Updates the state
 * @param {string} namespace - State namespace
 * @param {Object} update - State update
 * @returns {Object} Updated state
 */
function updateState(namespace, update) {
  // Validate namespace
  if (!StateNamespaces[namespace]) {
    console.error(`Invalid state namespace: ${namespace}`);
    return currentState[namespace] || {};
  }
  
  // Create namespace if it doesn't exist
  if (!currentState[namespace]) {
    currentState[namespace] = {};
  }
  
  // Update state
  const oldState = JSON.parse(JSON.stringify(currentState[namespace]));
  currentState[namespace] = {
    ...currentState[namespace],
    ...update
  };
  
  // Notify subscribers
  notifySubscribers(namespace, oldState, currentState[namespace]);
  
  // Return updated state
  return JSON.parse(JSON.stringify(currentState[namespace]));
}

/**
 * Resets the state
 * @param {string} namespace - State namespace (optional)
 * @returns {Object} Reset state
 */
function resetState(namespace = null) {
  if (namespace) {
    // Reset specific namespace
    const oldState = JSON.parse(JSON.stringify(currentState[namespace] || {}));
    currentState[namespace] = JSON.parse(JSON.stringify(DefaultState[namespace] || {}));
    
    // Notify subscribers
    notifySubscribers(namespace, oldState, currentState[namespace]);
    
    return JSON.parse(JSON.stringify(currentState[namespace]));
  } else {
    // Reset all state
    const oldState = JSON.parse(JSON.stringify(currentState));
    currentState = JSON.parse(JSON.stringify(DefaultState));
    
    // Notify all subscribers
    for (const ns of Object.keys(oldState)) {
      notifySubscribers(ns, oldState[ns], currentState[ns] || {});
    }
    
    return JSON.parse(JSON.stringify(currentState));
  }
}

/**
 * Subscribes to state changes
 * @param {Function} callback - Callback function
 * @param {string} namespace - State namespace (optional)
 * @returns {Function} Unsubscribe function
 */
function subscribe(callback, namespace = null) {
  if (namespace) {
    // Subscribe to namespace
    if (!subscribers.namespaced[namespace]) {
      subscribers.namespaced[namespace] = [];
    }
    
    subscribers.namespaced[namespace].push(callback);
    
    // Return unsubscribe function
    return () => {
      subscribers.namespaced[namespace] = subscribers.namespaced[namespace].filter(cb => cb !== callback);
    };
  } else {
    // Subscribe to all changes
    subscribers.global.push(callback);
    
    // Return unsubscribe function
    return () => {
      subscribers.global = subscribers.global.filter(cb => cb !== callback);
    };
  }
}

/**
 * Notifies subscribers about state changes
 * @param {string} namespace - State namespace
 * @param {Object} oldState - Old state
 * @param {Object} newState - New state
 */
function notifySubscribers(namespace, oldState, newState) {
  // Notify namespace subscribers
  if (subscribers.namespaced[namespace]) {
    subscribers.namespaced[namespace].forEach(callback => {
      try {
        callback(newState, oldState, namespace);
      } catch (error) {
        console.error('Error in state subscriber:', error);
      }
    });
  }
  
  // Notify global subscribers
  subscribers.global.forEach(callback => {
    try {
      callback(
        { [namespace]: newState },
        { [namespace]: oldState },
        namespace
      );
    } catch (error) {
      console.error('Error in global state subscriber:', error);
    }
  });
  
  // Dispatch event for components
  dispatchStateChangeEvent(namespace, oldState, newState);
}

/**
 * Dispatches a state change event
 * @param {string} namespace - State namespace
 * @param {Object} oldState - Old state
 * @param {Object} newState - New state
 */
function dispatchStateChangeEvent(namespace, oldState, newState) {
  const event = new CustomEvent('cryptovoice:stateChange', {
    detail: {
      namespace,
      oldState,
      newState
    }
  });
  
  window.dispatchEvent(event);
}

/**
 * Loads state from storage
 * @returns {Promise<Object>} Loaded state
 */
async function loadState() {
  try {
    // Check if sync manager is available
    if (typeof window.syncManagerUtils !== 'undefined' && 
        typeof window.syncManagerUtils.getData === 'function') {
      // Load state for each namespace
      for (const namespace of Object.keys(StateNamespaces)) {
        const ns = StateNamespaces[namespace];
        const data = await window.syncManagerUtils.getData(`state_${ns}`);
        
        if (data) {
          currentState[ns] = {
            ...DefaultState[ns],
            ...data
          };
        }
      }
    } else {
      // Fallback to Chrome storage
      await new Promise((resolve) => {
        chrome.storage.local.get('cryptovoice_state', (result) => {
          if (result.cryptovoice_state) {
            // Merge with default state
            for (const namespace of Object.keys(result.cryptovoice_state)) {
              if (currentState[namespace]) {
                currentState[namespace] = {
                  ...currentState[namespace],
                  ...result.cryptovoice_state[namespace]
                };
              } else {
                currentState[namespace] = result.cryptovoice_state[namespace];
              }
            }
          }
          resolve();
        });
      });
    }
    
    // Update session state
    updateState(StateNamespaces.SESSION, {
      initialized: true,
      lastActive: Date.now()
    });
    
    return getState();
  } catch (error) {
    console.error('Error loading state:', error);
    return getState();
  }
}

/**
 * Saves state to storage
 * @param {string} namespace - State namespace (optional)
 * @returns {Promise<boolean>} Success status
 */
async function saveState(namespace = null) {
  try {
    // Check if sync manager is available
    if (typeof window.syncManagerUtils !== 'undefined' && 
        typeof window.syncManagerUtils.saveData === 'function') {
      if (namespace) {
        // Save specific namespace
        await window.syncManagerUtils.saveData(`state_${namespace}`, currentState[namespace]);
      } else {
        // Save all namespaces
        for (const ns of Object.keys(currentState)) {
          await window.syncManagerUtils.saveData(`state_${ns}`, currentState[ns]);
        }
      }
    } else {
      // Fallback to Chrome storage
      await new Promise((resolve, reject) => {
        chrome.storage.local.set({ 'cryptovoice_state': currentState }, () => {
          if (chrome.runtime.lastError) {
            reject(chrome.runtime.lastError);
          } else {
            resolve();
          }
        });
      });
    }
    
    return true;
  } catch (error) {
    console.error('Error saving state:', error);
    return false;
  }
}

/**
 * Initializes the state manager
 * @returns {Promise<Object>} Initialized state
 */
async function initStateManager() {
  try {
    // Load state from storage
    await loadState();
    
    // Set up auto-save
    setupAutoSave();
    
    // Set up session tracking
    setupSessionTracking();
    
    return getState();
  } catch (error) {
    console.error('Error initializing state manager:', error);
    return getState();
  }
}

/**
 * Sets up automatic state saving
 */
function setupAutoSave() {
  // Save state every 30 seconds
  setInterval(async () => {
    await saveState();
  }, 30000);
  
  // Save state before unloading
  window.addEventListener('beforeunload', async () => {
    await saveState();
  });
}

/**
 * Sets up session tracking
 */
function setupSessionTracking() {
  // Update last active time on user interaction
  const updateLastActive = () => {
    updateState(StateNamespaces.SESSION, {
      lastActive: Date.now()
    });
  };
  
  window.addEventListener('click', updateLastActive);
  window.addEventListener('keydown', updateLastActive);
  window.addEventListener('mousemove', updateLastActive);
  window.addEventListener('touchstart', updateLastActive);
  
  // Check for session timeout every minute
  setInterval(() => {
    const sessionState = getState(StateNamespaces.SESSION);
    const now = Date.now();
    const inactiveTime = now - sessionState.lastActive;
    
    // If inactive for more than 30 minutes, reset session
    if (inactiveTime > 30 * 60 * 1000) {
      // Get config manager if available
      if (typeof window.configManagerUtils !== 'undefined' && 
          typeof window.configManagerUtils.getConfigValue === 'function') {
        window.configManagerUtils.getConfigValue('advanced', 'autoLogoutTimeout')
          .then(timeout => {
            if (timeout && inactiveTime > timeout) {
              // Reset session state
              updateState(StateNamespaces.SESSION, {
                loggedIn: false
              });
              
              // Show notification if notification manager is available
              if (typeof window.notificationManagerUtils !== 'undefined' && 
                  typeof window.notificationManagerUtils.showNotification === 'function') {
                window.notificationManagerUtils.showNotification(
                  window.notificationManagerUtils.NotificationTypes.SYSTEM_UPDATE,
                  'Session Timeout',
                  'You have been logged out due to inactivity.'
                );
              }
            }
          })
          .catch(console.error);
      }
    }
  }, 60000);
}

// Initialize state manager when the module is loaded
if (typeof window !== 'undefined') {
  initStateManager().catch(console.error);
}

// Export functions and constants
if (typeof module !== 'undefined' && module.exports) {
  module.exports = {
    StateNamespaces,
    DefaultState,
    getState,
    updateState,
    resetState,
    subscribe,
    loadState,
    saveState,
    initStateManager
  };
} else {
  // For browser environment
  window.stateManagerUtils = {
    StateNamespaces,
    DefaultState,
    getState,
    updateState,
    resetState,
    subscribe,
    loadState,
    saveState,
    initStateManager
  };
}
