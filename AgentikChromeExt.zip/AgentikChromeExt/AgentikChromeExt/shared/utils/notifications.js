/**
 * CryptoVoice - Notification Utilities
 * 
 * This file contains utility functions for notifications and user feedback.
 */

/**
 * Shows a Chrome notification
 * @param {string} title - Notification title
 * @param {string} message - Notification message
 * @param {string} [type='basic'] - Notification type
 * @param {string} [iconUrl='../assets/icons/icon128.png'] - Icon URL
 * @returns {Promise<string>} Promise that resolves with notification ID
 */
function showNotification(title, message, type = 'basic', iconUrl = '../assets/icons/icon128.png') {
  return new Promise((resolve, reject) => {
    try {
      const notificationOptions = {
        type,
        title,
        message,
        iconUrl
      };
      
      chrome.notifications.create(notificationOptions, (notificationId) => {
        if (chrome.runtime.lastError) {
          reject(chrome.runtime.lastError);
        } else {
          resolve(notificationId);
        }
      });
    } catch (error) {
      reject(error);
    }
  });
}

/**
 * Shows a transaction notification
 * @param {Object} transaction - Transaction details
 * @returns {Promise<string>} Promise that resolves with notification ID
 */
function showTransactionNotification(transaction) {
  if (!transaction) return Promise.reject('Invalid transaction');
  
  let title, message;
  
  switch (transaction.type.toLowerCase()) {
    case 'send':
      title = 'Transaction Sent';
      message = `Sent ${transaction.amount} ${transaction.token} to ${formatAddress(transaction.recipient)}`;
      break;
    case 'receive':
      title = 'Funds Received';
      message = `Received ${transaction.amount} ${transaction.token} from ${formatAddress(transaction.sender)}`;
      break;
    case 'swap':
      title = 'Token Swap Complete';
      message = `Swapped ${transaction.fromAmount} ${transaction.fromToken} to ${transaction.toAmount} ${transaction.toToken}`;
      break;
    default:
      title = 'Transaction Complete';
      message = `${transaction.type} transaction completed successfully`;
  }
  
  return showNotification(title, message);
}

/**
 * Shows an agent notification
 * @param {Object} agentAction - Agent action details
 * @returns {Promise<string>} Promise that resolves with notification ID
 */
function showAgentNotification(agentAction) {
  if (!agentAction) return Promise.reject('Invalid agent action');
  
  let title, message;
  
  switch (agentAction.action) {
    case 'buy':
      title = 'Agent: Buy Order';
      message = `Your trading agent bought ${agentAction.amount} ${agentAction.asset}`;
      break;
    case 'sell':
      title = 'Agent: Sell Order';
      message = `Your trading agent sold ${agentAction.amount} ${agentAction.asset}`;
      break;
    case 'swap':
      title = 'Agent: Token Swap';
      message = `Your trading agent swapped ${agentAction.fromAmount} ${agentAction.fromToken} to ${agentAction.toToken}`;
      break;
    case 'status':
      title = 'Agent Status Update';
      message = `${agentAction.message}`;
      break;
    default:
      title = 'Agent Activity';
      message = `Your trading agent performed an action: ${agentAction.action}`;
  }
  
  return showNotification(title, message);
}

/**
 * Shows an error notification
 * @param {string} errorMessage - Error message
 * @param {string} [context='Operation'] - Context where error occurred
 * @returns {Promise<string>} Promise that resolves with notification ID
 */
function showErrorNotification(errorMessage, context = 'Operation') {
  const title = `${context} Failed`;
  const message = errorMessage || 'An unknown error occurred';
  
  return showNotification(title, message);
}

/**
 * Shows an in-app notification in the popup
 * @param {string} message - Notification message
 * @param {string} [type='info'] - Notification type (info, success, warning, error)
 * @param {number} [duration=3000] - Duration in milliseconds
 */
function showInAppNotification(message, type = 'info', duration = 3000) {
  // This function is meant to be called from the popup
  // It creates and shows a notification element in the popup UI
  
  if (typeof document === 'undefined') {
    console.warn('showInAppNotification called outside of browser context');
    return;
  }
  
  // Create notification element if it doesn't exist
  let notificationContainer = document.getElementById('notification-container');
  if (!notificationContainer) {
    notificationContainer = document.createElement('div');
    notificationContainer.id = 'notification-container';
    notificationContainer.style.position = 'fixed';
    notificationContainer.style.bottom = '20px';
    notificationContainer.style.left = '50%';
    notificationContainer.style.transform = 'translateX(-50%)';
    notificationContainer.style.zIndex = '1000';
    document.body.appendChild(notificationContainer);
  }
  
  // Create notification element
  const notification = document.createElement('div');
  notification.className = `notification notification-${type}`;
  notification.textContent = message;
  
  // Style the notification
  notification.style.padding = '10px 20px';
  notification.style.marginBottom = '10px';
  notification.style.borderRadius = '4px';
  notification.style.boxShadow = '0 2px 5px rgba(0, 0, 0, 0.2)';
  notification.style.opacity = '0';
  notification.style.transition = 'opacity 0.3s ease-in-out';
  
  // Set background color based on type
  switch (type) {
    case 'success':
      notification.style.backgroundColor = '#4CAF50';
      notification.style.color = 'white';
      break;
    case 'warning':
      notification.style.backgroundColor = '#FF9800';
      notification.style.color = 'white';
      break;
    case 'error':
      notification.style.backgroundColor = '#F44336';
      notification.style.color = 'white';
      break;
    default: // info
      notification.style.backgroundColor = '#2196F3';
      notification.style.color = 'white';
  }
  
  // Add to container
  notificationContainer.appendChild(notification);
  
  // Trigger animation
  setTimeout(() => {
    notification.style.opacity = '1';
  }, 10);
  
  // Remove after duration
  setTimeout(() => {
    notification.style.opacity = '0';
    setTimeout(() => {
      notification.remove();
    }, 300);
  }, duration);
}

/**
 * Speaks a message using text-to-speech
 * @param {string} message - Message to speak
 * @param {Object} [options] - TTS options
 * @param {string} [options.lang='en-US'] - Language
 * @param {number} [options.rate=1.0] - Speech rate
 * @param {number} [options.pitch=1.0] - Speech pitch
 * @param {number} [options.volume=1.0] - Speech volume
 */
function speakMessage(message, options = {}) {
  if (!message) return;
  
  // Default options
  const defaultOptions = {
    lang: 'en-US',
    rate: 1.0,
    pitch: 1.0,
    volume: 1.0
  };
  
  // Merge options
  const ttsOptions = { ...defaultOptions, ...options };
  
  // Use Web Speech API if available
  if ('speechSynthesis' in window) {
    // Cancel any ongoing speech
    window.speechSynthesis.cancel();
    
    // Create utterance
    const utterance = new SpeechSynthesisUtterance(message);
    
    // Set options
    utterance.lang = ttsOptions.lang;
    utterance.rate = ttsOptions.rate;
    utterance.pitch = ttsOptions.pitch;
    utterance.volume = ttsOptions.volume;
    
    // Speak
    window.speechSynthesis.speak(utterance);
  } else {
    console.warn('Text-to-speech not supported in this browser');
  }
}

/**
 * Formats an address for display
 * @param {string} address - Full address
 * @param {number} [prefixLength=6] - Length of prefix to show
 * @param {number} [suffixLength=4] - Length of suffix to show
 * @returns {string} Formatted address
 */
function formatAddress(address, prefixLength = 6, suffixLength = 4) {
  if (!address || address.length < (prefixLength + suffixLength + 3)) {
    return address || '';
  }
  
  const prefix = address.substring(0, prefixLength);
  const suffix = address.substring(address.length - suffixLength);
  
  return `${prefix}...${suffix}`;
}

/**
 * Vibrates the device (if supported)
 * @param {number|number[]} pattern - Vibration pattern in milliseconds
 */
function vibrate(pattern) {
  if ('vibrate' in navigator) {
    navigator.vibrate(pattern);
  }
}

/**
 * Plays a notification sound
 * @param {string} [type='notification'] - Sound type
 */
function playSound(type = 'notification') {
  // Sound URLs
  const sounds = {
    notification: '../assets/sounds/notification.mp3',
    success: '../assets/sounds/success.mp3',
    error: '../assets/sounds/error.mp3',
    transaction: '../assets/sounds/transaction.mp3'
  };
  
  const soundUrl = sounds[type] || sounds.notification;
  
  // Create audio element
  const audio = new Audio(soundUrl);
  
  // Play sound
  audio.play().catch(error => {
    console.warn('Could not play notification sound:', error);
  });
}

// Export functions
if (typeof module !== 'undefined' && module.exports) {
  module.exports = {
    showNotification,
    showTransactionNotification,
    showAgentNotification,
    showErrorNotification,
    showInAppNotification,
    speakMessage,
    formatAddress,
    vibrate,
    playSound
  };
} else {
  // For browser environment
  window.notificationUtils = {
    showNotification,
    showTransactionNotification,
    showAgentNotification,
    showErrorNotification,
    showInAppNotification,
    speakMessage,
    formatAddress,
    vibrate,
    playSound
  };
}
