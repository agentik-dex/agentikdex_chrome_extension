/**
 * Agentik Wallet - Error Handler Utilities
 * 
 * This file contains utility functions for handling and logging errors.
 */

/**
 * Error categories for classification
 * @enum {string}
 */
const ErrorCategories = {
  // Voice-related errors
  VOICE_RECOGNITION: 'voice_recognition',
  VOICE_PROCESSING: 'voice_processing',
  VOICE_AUTHENTICATION: 'voice_authentication',
  
  // Wallet-related errors
  WALLET_CONNECTION: 'wallet_connection',
  WALLET_TRANSACTION: 'wallet_transaction',
  WALLET_SIGNING: 'wallet_signing',
  
  // Blockchain-related errors
  BLOCKCHAIN_REQUEST: 'blockchain_request',
  BLOCKCHAIN_RESPONSE: 'blockchain_response',
  
  // Trading agent errors
  AGENT_DECISION: 'agent_decision',
  AGENT_EXECUTION: 'agent_execution',
  
  // Storage errors
  STORAGE_READ: 'storage_read',
  STORAGE_WRITE: 'storage_write',
  
  // UI errors
  UI_RENDER: 'ui_render',
  UI_INTERACTION: 'ui_interaction',
  
  // DeFi platform errors
  DEFI_PLATFORM_DETECTION: 'defi_platform_detection',
  DEFI_PLATFORM_INTERACTION: 'defi_platform_interaction',
  
  // Security errors
  SECURITY_VALIDATION: 'security_validation',
  SECURITY_ENCRYPTION: 'security_encryption',
  
  // Network errors
  NETWORK_REQUEST: 'network_request',
  NETWORK_RESPONSE: 'network_response',
  
  // Extension errors
  EXTENSION_INITIALIZATION: 'extension_initialization',
  EXTENSION_MESSAGING: 'extension_messaging',
  
  // Unknown errors
  UNKNOWN: 'unknown'
};

/**
 * Error severity levels
 * @enum {string}
 */
const ErrorSeverity = {
  DEBUG: 'debug',
  INFO: 'info',
  WARNING: 'warning',
  ERROR: 'error',
  CRITICAL: 'critical'
};

/**
 * Maximum number of errors to store in local storage
 * @type {number}
 */
const MAX_STORED_ERRORS = 100;

/**
 * Logs an error with the specified details
 * @param {Error|string} error - Error object or message
 * @param {string} category - Error category from ErrorCategories enum
 * @param {string} severity - Error severity from ErrorSeverity enum
 * @param {Object} context - Additional context for the error
 * @returns {Promise<string>} Error ID
 */
async function logError(error, category = ErrorCategories.UNKNOWN, severity = ErrorSeverity.ERROR, context = {}) {
  try {
    // Create error object
    const errorObj = {
      id: generateErrorId(),
      message: error instanceof Error ? error.message : String(error),
      stack: error instanceof Error ? error.stack : null,
      category,
      severity,
      context,
      timestamp: new Date().toISOString(),
      userAgent: navigator.userAgent,
      extensionVersion: chrome.runtime.getManifest().version
    };
    
    // Log to console in development mode
    if (process.env.NODE_ENV === 'development') {
      console.error('Agentik Wallet Error:', errorObj);
    }
    
    // Store error in local storage
    await storeError(errorObj);
    
    // If critical, show notification
    if (severity === ErrorSeverity.CRITICAL) {
      showErrorNotification(errorObj);
    }
    
    // If analytics is available, track error event
    if (typeof window.analyticsUtils !== 'undefined' && window.analyticsUtils.trackEvent) {
      window.analyticsUtils.trackEvent(window.analyticsUtils.EventTypes.ERROR_OCCURRED, {
        errorId: errorObj.id,
        category: errorObj.category,
        severity: errorObj.severity,
        message: errorObj.message
      });
    }
    
    return errorObj.id;
  } catch (err) {
    // Fallback to console if error handling fails
    console.error('Error in error handler:', err);
    console.error('Original error:', error);
    return 'error_handler_failed';
  }
}

/**
 * Generates a unique error ID
 * @returns {string} Error ID
 */
function generateErrorId() {
  return 'err_' + Math.random().toString(36).substring(2, 15) + 
         Math.random().toString(36).substring(2, 15) + 
         '_' + Date.now();
}

/**
 * Stores an error in local storage
 * @param {Object} errorObj - Error object to store
 * @returns {Promise<boolean>} Success status
 */
async function storeError(errorObj) {
  try {
    // Get existing errors
    const errors = await getStoredErrors();
    
    // Add new error
    errors.unshift(errorObj);
    
    // Trim errors if too many
    const trimmedErrors = errors.slice(0, MAX_STORED_ERRORS);
    
    // Save errors
    await new Promise((resolve, reject) => {
      chrome.storage.local.set({ 'cryptovoice_errors': trimmedErrors }, () => {
        if (chrome.runtime.lastError) {
          reject(chrome.runtime.lastError);
        } else {
          resolve();
        }
      });
    });
    
    return true;
  } catch (error) {
    console.error('Error storing error:', error);
    return false;
  }
}

/**
 * Gets stored errors from local storage
 * @returns {Promise<Array>} Array of stored errors
 */
async function getStoredErrors() {
  try {
    return await new Promise((resolve, reject) => {
      chrome.storage.local.get('cryptovoice_errors', (result) => {
        if (chrome.runtime.lastError) {
          reject(chrome.runtime.lastError);
        } else {
          resolve(result.cryptovoice_errors || []);
        }
      });
    });
  } catch (error) {
    console.error('Error getting stored errors:', error);
    return [];
  }
}

/**
 * Clears all stored errors
 * @returns {Promise<boolean>} Success status
 */
async function clearStoredErrors() {
  try {
    await new Promise((resolve, reject) => {
      chrome.storage.local.remove('cryptovoice_errors', () => {
        if (chrome.runtime.lastError) {
          reject(chrome.runtime.lastError);
        } else {
          resolve();
        }
      });
    });
    
    return true;
  } catch (error) {
    console.error('Error clearing stored errors:', error);
    return false;
  }
}

/**
 * Shows an error notification
 * @param {Object} errorObj - Error object
 */
function showErrorNotification(errorObj) {
  try {
    // Check if notifications API is available
    if (typeof chrome.notifications !== 'undefined') {
      // Create notification
      chrome.notifications.create({
        type: 'basic',
        iconUrl: '../assets/icons/icon48.png',
        title: 'Agentik Wallet Error',
        message: `${errorObj.severity.toUpperCase()}: ${errorObj.message}`,
        priority: 2
      });
    }
    
    // Check if UI components are available
    if (typeof window.uiComponentUtils !== 'undefined' && window.uiComponentUtils.createToast) {
      // Create toast notification
      window.uiComponentUtils.createToast(
        errorObj.message,
        'error',
        5000
      );
    }
  } catch (error) {
    console.error('Error showing error notification:', error);
  }
}

/**
 * Gets errors filtered by category and/or severity
 * @param {string} category - Error category to filter by
 * @param {string} severity - Error severity to filter by
 * @returns {Promise<Array>} Filtered errors
 */
async function getFilteredErrors(category = null, severity = null) {
  try {
    // Get all errors
    const errors = await getStoredErrors();
    
    // Filter errors
    return errors.filter(error => {
      // Filter by category if specified
      if (category && error.category !== category) {
        return false;
      }
      
      // Filter by severity if specified
      if (severity && error.severity !== severity) {
        return false;
      }
      
      return true;
    });
  } catch (error) {
    console.error('Error getting filtered errors:', error);
    return [];
  }
}

/**
 * Gets error statistics
 * @returns {Promise<Object>} Error statistics
 */
async function getErrorStatistics() {
  try {
    // Get all errors
    const errors = await getStoredErrors();
    
    // Initialize statistics
    const statistics = {
      totalErrors: errors.length,
      bySeverity: {},
      byCategory: {},
      recentErrors: errors.slice(0, 5)
    };
    
    // Count errors by severity
    for (const severity of Object.values(ErrorSeverity)) {
      statistics.bySeverity[severity] = errors.filter(error => error.severity === severity).length;
    }
    
    // Count errors by category
    for (const category of Object.values(ErrorCategories)) {
      statistics.byCategory[category] = errors.filter(error => error.category === category).length;
    }
    
    return statistics;
  } catch (error) {
    console.error('Error getting error statistics:', error);
    return {
      totalErrors: 0,
      bySeverity: {},
      byCategory: {},
      recentErrors: []
    };
  }
}

/**
 * Creates an error handler function for async functions
 * @param {string} category - Error category
 * @param {string} severity - Error severity
 * @param {Function} fallbackFn - Fallback function to call on error
 * @returns {Function} Error handler function
 */
function createAsyncErrorHandler(category, severity, fallbackFn = null) {
  return async function(fn, ...args) {
    try {
      return await fn(...args);
    } catch (error) {
      // Log the error
      await logError(error, category, severity, { args });
      
      // Call fallback if provided
      if (fallbackFn) {
        return fallbackFn(error, ...args);
      }
      
      // Re-throw the error
      throw error;
    }
  };
}

/**
 * Wraps a function with error handling
 * @param {Function} fn - Function to wrap
 * @param {string} category - Error category
 * @param {string} severity - Error severity
 * @param {Function} fallbackFn - Fallback function to call on error
 * @returns {Function} Wrapped function
 */
function withErrorHandling(fn, category, severity, fallbackFn = null) {
  return function(...args) {
    try {
      const result = fn(...args);
      
      // Handle promises
      if (result instanceof Promise) {
        return result.catch(error => {
          // Log the error
          logError(error, category, severity, { args });
          
          // Call fallback if provided
          if (fallbackFn) {
            return fallbackFn(error, ...args);
          }
          
          // Re-throw the error
          throw error;
        });
      }
      
      return result;
    } catch (error) {
      // Log the error
      logError(error, category, severity, { args });
      
      // Call fallback if provided
      if (fallbackFn) {
        return fallbackFn(error, ...args);
      }
      
      // Re-throw the error
      throw error;
    }
  };
}

/**
 * Creates a global error handler for uncaught exceptions
 */
function setupGlobalErrorHandler() {
  // Handle uncaught exceptions
  window.addEventListener('error', (event) => {
    logError(
      event.error || event.message,
      ErrorCategories.UNKNOWN,
      ErrorSeverity.ERROR,
      {
        filename: event.filename,
        lineno: event.lineno,
        colno: event.colno
      }
    );
  });
  
  // Handle unhandled promise rejections
  window.addEventListener('unhandledrejection', (event) => {
    logError(
      event.reason,
      ErrorCategories.UNKNOWN,
      ErrorSeverity.ERROR,
      {
        type: 'unhandledrejection'
      }
    );
  });
}

// Export functions and constants
if (typeof module !== 'undefined' && module.exports) {
  module.exports = {
    ErrorCategories,
    ErrorSeverity,
    logError,
    getStoredErrors,
    clearStoredErrors,
    getFilteredErrors,
    getErrorStatistics,
    createAsyncErrorHandler,
    withErrorHandling,
    setupGlobalErrorHandler
  };
} else {
  // For browser environment
  window.errorHandlerUtils = {
    ErrorCategories,
    ErrorSeverity,
    logError,
    getStoredErrors,
    clearStoredErrors,
    getFilteredErrors,
    getErrorStatistics,
    createAsyncErrorHandler,
    withErrorHandling,
    setupGlobalErrorHandler
  };
}
