/**
 * CryptoVoice - Data Synchronization Manager Utilities
 * 
 * This file contains utility functions for managing data synchronization
 * between local storage, Chrome sync storage, and optional cloud storage.
 */

/**
 * Sync data types
 * @enum {string}
 */
const SyncDataTypes = {
  // User preferences and settings
  CONFIG: 'config',
  PERMISSIONS: 'permissions',
  SECURITY_SETTINGS: 'security_settings',
  TRANSACTION_LIMITS: 'transaction_limits',
  UI_PREFERENCES: 'ui_preferences',
  
  // User data
  WALLET_STATE: 'wallet_state',
  TRANSACTION_HISTORY: 'transaction_history',
  VOICE_PROFILES: 'voice_profiles',
  AGENT_STATE: 'agent_state',
  AGENT_DECISIONS: 'agent_decisions',
  ANALYTICS_DATA: 'analytics_data',
  
  // Extension state
  LAST_SYNC_TIME: 'last_sync_time',
  SYNC_STATUS: 'sync_status'
};

/**
 * Storage types
 * @enum {string}
 */
const StorageTypes = {
  LOCAL: 'local',
  SYNC: 'sync',
  CLOUD: 'cloud'
};

/**
 * Default sync configuration
 * @type {Object}
 */
const DefaultSyncConfig = {
  // Whether sync is enabled
  enabled: true,
  
  // Automatic sync interval in milliseconds (15 minutes)
  syncInterval: 15 * 60 * 1000,
  
  // Whether to sync on startup
  syncOnStartup: true,
  
  // Whether to sync before closing
  syncBeforeClosing: true,
  
  // Storage types to use for each data type
  dataTypeStorage: {
    [SyncDataTypes.CONFIG]: [StorageTypes.LOCAL, StorageTypes.SYNC],
    [SyncDataTypes.PERMISSIONS]: [StorageTypes.LOCAL, StorageTypes.SYNC],
    [SyncDataTypes.SECURITY_SETTINGS]: [StorageTypes.LOCAL, StorageTypes.SYNC],
    [SyncDataTypes.TRANSACTION_LIMITS]: [StorageTypes.LOCAL, StorageTypes.SYNC],
    [SyncDataTypes.UI_PREFERENCES]: [StorageTypes.LOCAL, StorageTypes.SYNC],
    [SyncDataTypes.WALLET_STATE]: [StorageTypes.LOCAL], // Sensitive data, local only by default
    [SyncDataTypes.TRANSACTION_HISTORY]: [StorageTypes.LOCAL, StorageTypes.SYNC],
    [SyncDataTypes.VOICE_PROFILES]: [StorageTypes.LOCAL], // Sensitive data, local only by default
    [SyncDataTypes.AGENT_STATE]: [StorageTypes.LOCAL, StorageTypes.SYNC],
    [SyncDataTypes.AGENT_DECISIONS]: [StorageTypes.LOCAL, StorageTypes.SYNC],
    [SyncDataTypes.ANALYTICS_DATA]: [StorageTypes.LOCAL, StorageTypes.SYNC],
    [SyncDataTypes.LAST_SYNC_TIME]: [StorageTypes.LOCAL, StorageTypes.SYNC],
    [SyncDataTypes.SYNC_STATUS]: [StorageTypes.LOCAL, StorageTypes.SYNC]
  },
  
  // Conflict resolution strategy
  conflictResolution: 'newest', // 'newest', 'local', 'remote'
  
  // Whether to encrypt sensitive data before syncing
  encryptSensitiveData: true,
  
  // Cloud storage provider (if used)
  cloudProvider: null,
  
  // Cloud storage credentials (if used)
  cloudCredentials: null
};

/**
 * Gets the sync configuration
 * @returns {Promise<Object>} Sync configuration
 */
async function getSyncConfig() {
  try {
    return await new Promise((resolve) => {
      chrome.storage.local.get('cryptovoice_sync_config', (result) => {
        resolve(result.cryptovoice_sync_config || { ...DefaultSyncConfig });
      });
    });
  } catch (error) {
    console.error('Error getting sync config:', error);
    return { ...DefaultSyncConfig };
  }
}

/**
 * Updates the sync configuration
 * @param {Object} config - New sync configuration
 * @returns {Promise<boolean>} Success status
 */
async function updateSyncConfig(config) {
  try {
    // Get current config
    const currentConfig = await getSyncConfig();
    
    // Merge with new config
    const mergedConfig = { ...currentConfig, ...config };
    
    // Save config
    await new Promise((resolve, reject) => {
      chrome.storage.local.set({ 'cryptovoice_sync_config': mergedConfig }, () => {
        if (chrome.runtime.lastError) {
          reject(chrome.runtime.lastError);
        } else {
          resolve();
        }
      });
    });
    
    return true;
  } catch (error) {
    console.error('Error updating sync config:', error);
    return false;
  }
}

/**
 * Resets the sync configuration to defaults
 * @returns {Promise<boolean>} Success status
 */
async function resetSyncConfig() {
  try {
    await new Promise((resolve, reject) => {
      chrome.storage.local.set({ 'cryptovoice_sync_config': { ...DefaultSyncConfig } }, () => {
        if (chrome.runtime.lastError) {
          reject(chrome.runtime.lastError);
        } else {
          resolve();
        }
      });
    });
    
    return true;
  } catch (error) {
    console.error('Error resetting sync config:', error);
    return false;
  }
}

/**
 * Gets the storage key for a data type
 * @param {string} dataType - Data type from SyncDataTypes enum
 * @returns {string} Storage key
 */
function getStorageKey(dataType) {
  return `cryptovoice_${dataType}`;
}

/**
 * Gets data from storage
 * @param {string} dataType - Data type from SyncDataTypes enum
 * @param {string} storageType - Storage type from StorageTypes enum
 * @returns {Promise<any>} Data from storage
 */
async function getFromStorage(dataType, storageType) {
  try {
    const key = getStorageKey(dataType);
    
    // Get from appropriate storage
    if (storageType === StorageTypes.LOCAL) {
      return await new Promise((resolve) => {
        chrome.storage.local.get(key, (result) => {
          resolve(result[key]);
        });
      });
    } else if (storageType === StorageTypes.SYNC) {
      return await new Promise((resolve) => {
        chrome.storage.sync.get(key, (result) => {
          resolve(result[key]);
        });
      });
    } else if (storageType === StorageTypes.CLOUD) {
      // Cloud storage implementation would go here
      // This is a placeholder for future implementation
      return null;
    }
    
    return null;
  } catch (error) {
    console.error(`Error getting ${dataType} from ${storageType} storage:`, error);
    return null;
  }
}

/**
 * Saves data to storage
 * @param {string} dataType - Data type from SyncDataTypes enum
 * @param {string} storageType - Storage type from StorageTypes enum
 * @param {any} data - Data to save
 * @returns {Promise<boolean>} Success status
 */
async function saveToStorage(dataType, storageType, data) {
  try {
    const key = getStorageKey(dataType);
    const item = { [key]: data };
    
    // Save to appropriate storage
    if (storageType === StorageTypes.LOCAL) {
      await new Promise((resolve, reject) => {
        chrome.storage.local.set(item, () => {
          if (chrome.runtime.lastError) {
            reject(chrome.runtime.lastError);
          } else {
            resolve();
          }
        });
      });
    } else if (storageType === StorageTypes.SYNC) {
      await new Promise((resolve, reject) => {
        chrome.storage.sync.set(item, () => {
          if (chrome.runtime.lastError) {
            reject(chrome.runtime.lastError);
          } else {
            resolve();
          }
        });
      });
    } else if (storageType === StorageTypes.CLOUD) {
      // Cloud storage implementation would go here
      // This is a placeholder for future implementation
      return false;
    }
    
    return true;
  } catch (error) {
    console.error(`Error saving ${dataType} to ${storageType} storage:`, error);
    return false;
  }
}

/**
 * Removes data from storage
 * @param {string} dataType - Data type from SyncDataTypes enum
 * @param {string} storageType - Storage type from StorageTypes enum
 * @returns {Promise<boolean>} Success status
 */
async function removeFromStorage(dataType, storageType) {
  try {
    const key = getStorageKey(dataType);
    
    // Remove from appropriate storage
    if (storageType === StorageTypes.LOCAL) {
      await new Promise((resolve, reject) => {
        chrome.storage.local.remove(key, () => {
          if (chrome.runtime.lastError) {
            reject(chrome.runtime.lastError);
          } else {
            resolve();
          }
        });
      });
    } else if (storageType === StorageTypes.SYNC) {
      await new Promise((resolve, reject) => {
        chrome.storage.sync.remove(key, () => {
          if (chrome.runtime.lastError) {
            reject(chrome.runtime.lastError);
          } else {
            resolve();
          }
        });
      });
    } else if (storageType === StorageTypes.CLOUD) {
      // Cloud storage implementation would go here
      // This is a placeholder for future implementation
      return false;
    }
    
    return true;
  } catch (error) {
    console.error(`Error removing ${dataType} from ${storageType} storage:`, error);
    return false;
  }
}

/**
 * Gets data for a specific type
 * @param {string} dataType - Data type from SyncDataTypes enum
 * @returns {Promise<any>} Data
 */
async function getData(dataType) {
  try {
    // Get sync config
    const syncConfig = await getSyncConfig();
    
    // Get storage types for this data type
    const storageTypes = syncConfig.dataTypeStorage[dataType] || [StorageTypes.LOCAL];
    
    // Try to get data from each storage type
    let data = null;
    let dataTimestamp = 0;
    
    for (const storageType of storageTypes) {
      const storageData = await getFromStorage(dataType, storageType);
      
      if (storageData && storageData.data !== undefined) {
        // Check if this data is newer
        if (syncConfig.conflictResolution === 'newest') {
          if (storageData.timestamp > dataTimestamp) {
            data = storageData.data;
            dataTimestamp = storageData.timestamp;
          }
        } else if (syncConfig.conflictResolution === 'local' && storageType === StorageTypes.LOCAL) {
          // Prefer local data
          data = storageData.data;
          break;
        } else if (syncConfig.conflictResolution === 'remote' && storageType !== StorageTypes.LOCAL) {
          // Prefer remote data
          data = storageData.data;
          dataTimestamp = storageData.timestamp;
        }
      }
    }
    
    return data;
  } catch (error) {
    console.error(`Error getting data for ${dataType}:`, error);
    return null;
  }
}

/**
 * Saves data for a specific type
 * @param {string} dataType - Data type from SyncDataTypes enum
 * @param {any} data - Data to save
 * @returns {Promise<boolean>} Success status
 */
async function saveData(dataType, data) {
  try {
    // Get sync config
    const syncConfig = await getSyncConfig();
    
    // Skip if sync is disabled
    if (!syncConfig.enabled) {
      // Still save to local storage
      await saveToStorage(dataType, StorageTypes.LOCAL, {
        data,
        timestamp: Date.now()
      });
      
      return true;
    }
    
    // Get storage types for this data type
    const storageTypes = syncConfig.dataTypeStorage[dataType] || [StorageTypes.LOCAL];
    
    // Check if this is sensitive data that needs encryption
    let processedData = data;
    if (syncConfig.encryptSensitiveData && 
        (dataType === SyncDataTypes.WALLET_STATE || 
         dataType === SyncDataTypes.VOICE_PROFILES)) {
      // In a real implementation, this would encrypt the data
      // For now, we'll just mark it as encrypted
      processedData = {
        encrypted: true,
        data: data
      };
    }
    
    // Create data object with timestamp
    const dataObject = {
      data: processedData,
      timestamp: Date.now()
    };
    
    // Save to each storage type
    const results = await Promise.all(
      storageTypes.map(storageType => 
        saveToStorage(dataType, storageType, dataObject)
      )
    );
    
    // Update last sync time
    await updateLastSyncTime(dataType);
    
    // Check if all saves were successful
    return results.every(result => result);
  } catch (error) {
    console.error(`Error saving data for ${dataType}:`, error);
    return false;
  }
}

/**
 * Removes data for a specific type
 * @param {string} dataType - Data type from SyncDataTypes enum
 * @returns {Promise<boolean>} Success status
 */
async function removeData(dataType) {
  try {
    // Get sync config
    const syncConfig = await getSyncConfig();
    
    // Get storage types for this data type
    const storageTypes = syncConfig.dataTypeStorage[dataType] || [StorageTypes.LOCAL];
    
    // Remove from each storage type
    const results = await Promise.all(
      storageTypes.map(storageType => 
        removeFromStorage(dataType, storageType)
      )
    );
    
    // Check if all removes were successful
    return results.every(result => result);
  } catch (error) {
    console.error(`Error removing data for ${dataType}:`, error);
    return false;
  }
}

/**
 * Updates the last sync time for a data type
 * @param {string} dataType - Data type from SyncDataTypes enum
 * @returns {Promise<boolean>} Success status
 */
async function updateLastSyncTime(dataType) {
  try {
    // Get current sync times
    const syncTimes = await getData(SyncDataTypes.LAST_SYNC_TIME) || {};
    
    // Update sync time for this data type
    syncTimes[dataType] = Date.now();
    
    // Save sync times
    await saveData(SyncDataTypes.LAST_SYNC_TIME, syncTimes);
    
    return true;
  } catch (error) {
    console.error(`Error updating last sync time for ${dataType}:`, error);
    return false;
  }
}

/**
 * Gets the last sync time for a data type
 * @param {string} dataType - Data type from SyncDataTypes enum
 * @returns {Promise<number>} Last sync time (timestamp)
 */
async function getLastSyncTime(dataType) {
  try {
    // Get sync times
    const syncTimes = await getData(SyncDataTypes.LAST_SYNC_TIME) || {};
    
    // Return sync time for this data type
    return syncTimes[dataType] || 0;
  } catch (error) {
    console.error(`Error getting last sync time for ${dataType}:`, error);
    return 0;
  }
}

/**
 * Syncs all data
 * @returns {Promise<Object>} Sync results
 */
async function syncAll() {
  try {
    // Get sync config
    const syncConfig = await getSyncConfig();
    
    // Skip if sync is disabled
    if (!syncConfig.enabled) {
      return {
        success: false,
        message: 'Sync is disabled',
        results: {}
      };
    }
    
    // Get all data types
    const dataTypes = Object.values(SyncDataTypes);
    
    // Sync each data type
    const results = {};
    
    for (const dataType of dataTypes) {
      try {
        // Skip sync status and last sync time
        if (dataType === SyncDataTypes.SYNC_STATUS || 
            dataType === SyncDataTypes.LAST_SYNC_TIME) {
          continue;
        }
        
        // Get storage types for this data type
        const storageTypes = syncConfig.dataTypeStorage[dataType] || [StorageTypes.LOCAL];
        
        // Skip if only local storage is used
        if (storageTypes.length === 1 && storageTypes[0] === StorageTypes.LOCAL) {
          results[dataType] = {
            success: true,
            message: 'Skipped (local only)'
          };
          continue;
        }
        
        // Get data from each storage type
        const storageData = {};
        
        for (const storageType of storageTypes) {
          storageData[storageType] = await getFromStorage(dataType, storageType);
        }
        
        // Determine which data to use based on conflict resolution strategy
        let dataToUse = null;
        let dataTimestamp = 0;
        let sourceStorage = null;
        
        if (syncConfig.conflictResolution === 'newest') {
          // Use newest data
          for (const [storageType, data] of Object.entries(storageData)) {
            if (data && data.timestamp > dataTimestamp) {
              dataToUse = data.data;
              dataTimestamp = data.timestamp;
              sourceStorage = storageType;
            }
          }
        } else if (syncConfig.conflictResolution === 'local') {
          // Prefer local data
          dataToUse = storageData[StorageTypes.LOCAL]?.data;
          dataTimestamp = storageData[StorageTypes.LOCAL]?.timestamp || 0;
          sourceStorage = StorageTypes.LOCAL;
        } else if (syncConfig.conflictResolution === 'remote') {
          // Prefer remote data
          for (const [storageType, data] of Object.entries(storageData)) {
            if (storageType !== StorageTypes.LOCAL && data) {
              dataToUse = data.data;
              dataTimestamp = data.timestamp;
              sourceStorage = storageType;
              break;
            }
          }
          
          // Fallback to local if no remote data
          if (!dataToUse) {
            dataToUse = storageData[StorageTypes.LOCAL]?.data;
            dataTimestamp = storageData[StorageTypes.LOCAL]?.timestamp || 0;
            sourceStorage = StorageTypes.LOCAL;
          }
        }
        
        // If no data was found, skip
        if (!dataToUse) {
          results[dataType] = {
            success: true,
            message: 'No data to sync'
          };
          continue;
        }
        
        // Create data object with timestamp
        const dataObject = {
          data: dataToUse,
          timestamp: dataTimestamp
        };
        
        // Save to each storage type
        const saveResults = await Promise.all(
          storageTypes.map(storageType => 
            saveToStorage(dataType, storageType, dataObject)
          )
        );
        
        // Update last sync time
        await updateLastSyncTime(dataType);
        
        // Check if all saves were successful
        results[dataType] = {
          success: saveResults.every(result => result),
          message: saveResults.every(result => result) 
            ? `Synced from ${sourceStorage}`
            : 'Sync failed for some storage types'
        };
      } catch (error) {
        results[dataType] = {
          success: false,
          message: error.message
        };
      }
    }
    
    // Update sync status
    await saveData(SyncDataTypes.SYNC_STATUS, {
      lastSync: Date.now(),
      results
    });
    
    return {
      success: Object.values(results).every(result => result.success),
      message: 'Sync completed',
      results
    };
  } catch (error) {
    console.error('Error syncing all data:', error);
    
    // Update sync status
    await saveData(SyncDataTypes.SYNC_STATUS, {
      lastSync: Date.now(),
      error: error.message
    });
    
    return {
      success: false,
      message: error.message,
      results: {}
    };
  }
}

/**
 * Gets the sync status
 * @returns {Promise<Object>} Sync status
 */
async function getSyncStatus() {
  try {
    return await getData(SyncDataTypes.SYNC_STATUS) || {
      lastSync: 0,
      results: {}
    };
  } catch (error) {
    console.error('Error getting sync status:', error);
    return {
      lastSync: 0,
      error: error.message
    };
  }
}

/**
 * Starts automatic sync
 * @returns {Promise<boolean>} Success status
 */
async function startAutoSync() {
  try {
    // Get sync config
    const syncConfig = await getSyncConfig();
    
    // Skip if sync is disabled
    if (!syncConfig.enabled) {
      return false;
    }
    
    // Stop any existing auto sync
    stopAutoSync();
    
    // Start sync interval
    autoSyncInterval = setInterval(async () => {
      await syncAll();
    }, syncConfig.syncInterval);
    
    return true;
  } catch (error) {
    console.error('Error starting auto sync:', error);
    return false;
  }
}

/**
 * Stops automatic sync
 */
function stopAutoSync() {
  if (autoSyncInterval) {
    clearInterval(autoSyncInterval);
    autoSyncInterval = null;
  }
}

/**
 * Auto sync interval
 * @type {number}
 */
let autoSyncInterval = null;

/**
 * Initializes the sync manager
 * @returns {Promise<boolean>} Success status
 */
async function initSyncManager() {
  try {
    // Get sync config
    const syncConfig = await getSyncConfig();
    
    // Skip if sync is disabled
    if (!syncConfig.enabled) {
      return false;
    }
    
    // Sync on startup if enabled
    if (syncConfig.syncOnStartup) {
      await syncAll();
    }
    
    // Start auto sync
    await startAutoSync();
    
    // Set up sync before closing if enabled
    if (syncConfig.syncBeforeClosing) {
      window.addEventListener('beforeunload', async () => {
        await syncAll();
      });
    }
    
    return true;
  } catch (error) {
    console.error('Error initializing sync manager:', error);
    return false;
  }
}

// Initialize sync manager when the module is loaded
if (typeof window !== 'undefined') {
  initSyncManager().catch(console.error);
}

// Export functions and constants
if (typeof module !== 'undefined' && module.exports) {
  module.exports = {
    SyncDataTypes,
    StorageTypes,
    DefaultSyncConfig,
    getSyncConfig,
    updateSyncConfig,
    resetSyncConfig,
    getData,
    saveData,
    removeData,
    getLastSyncTime,
    syncAll,
    getSyncStatus,
    startAutoSync,
    stopAutoSync,
    initSyncManager
  };
} else {
  // For browser environment
  window.syncManagerUtils = {
    SyncDataTypes,
    StorageTypes,
    DefaultSyncConfig,
    getSyncConfig,
    updateSyncConfig,
    resetSyncConfig,
    getData,
    saveData,
    removeData,
    getLastSyncTime,
    syncAll,
    getSyncStatus,
    startAutoSync,
    stopAutoSync,
    initSyncManager
  };
}
