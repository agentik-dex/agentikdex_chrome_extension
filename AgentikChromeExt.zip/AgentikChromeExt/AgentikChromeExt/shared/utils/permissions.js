/**
 * CryptoVoice - Permissions and Security Settings Utilities
 * 
 * This file contains utility functions for managing permissions and security settings.
 */

/**
 * Permission types for different operations
 * @enum {string}
 */
const PermissionTypes = {
  // Voice command permissions
  VOICE_COMMANDS: 'voice_commands',
  VOICE_AUTHENTICATION: 'voice_authentication',
  
  // Wallet permissions
  WALLET_CONNECTION: 'wallet_connection',
  VIEW_BALANCES: 'view_balances',
  VIEW_TRANSACTIONS: 'view_transactions',
  
  // Transaction permissions
  SEND_TRANSACTION: 'send_transaction',
  SWAP_TOKENS: 'swap_tokens',
  APPROVE_TOKEN: 'approve_token',
  
  // Agent permissions
  AGENT_ENABLE: 'agent_enable',
  AGENT_VIEW_DECISIONS: 'agent_view_decisions',
  AGENT_EXECUTE_TRADES: 'agent_execute_trades',
  
  // DeFi platform permissions
  DEFI_PLATFORM_INTEGRATION: 'defi_platform_integration',
  FORM_AUTOFILL: 'form_autofill',
  
  // Data permissions
  COLLECT_ANALYTICS: 'collect_analytics',
  REMOTE_ANALYTICS: 'remote_analytics'
};

/**
 * Default permission settings
 * @type {Object}
 */
const DefaultPermissions = {
  [PermissionTypes.VOICE_COMMANDS]: true,
  [PermissionTypes.VOICE_AUTHENTICATION]: true,
  [PermissionTypes.WALLET_CONNECTION]: true,
  [PermissionTypes.VIEW_BALANCES]: true,
  [PermissionTypes.VIEW_TRANSACTIONS]: true,
  [PermissionTypes.SEND_TRANSACTION]: false, // Requires explicit approval
  [PermissionTypes.SWAP_TOKENS]: false, // Requires explicit approval
  [PermissionTypes.APPROVE_TOKEN]: false, // Requires explicit approval
  [PermissionTypes.AGENT_ENABLE]: false, // Requires explicit approval
  [PermissionTypes.AGENT_VIEW_DECISIONS]: true,
  [PermissionTypes.AGENT_EXECUTE_TRADES]: false, // Requires explicit approval
  [PermissionTypes.DEFI_PLATFORM_INTEGRATION]: true,
  [PermissionTypes.FORM_AUTOFILL]: false, // Requires explicit approval
  [PermissionTypes.COLLECT_ANALYTICS]: true,
  [PermissionTypes.REMOTE_ANALYTICS]: false // Opt-in only
};

/**
 * Transaction limits configuration
 * @type {Object}
 */
const DefaultTransactionLimits = {
  // Maximum amount per transaction in USD
  maxTransactionAmount: 1000,
  
  // Maximum daily transaction volume in USD
  maxDailyVolume: 5000,
  
  // Maximum number of transactions per day
  maxDailyTransactions: 10,
  
  // Minimum time between transactions in milliseconds (5 minutes)
  minTimeBetweenTransactions: 5 * 60 * 1000,
  
  // Whether to require additional confirmation for large transactions
  requireConfirmationForLargeTransactions: true,
  
  // Threshold for large transactions in USD
  largeTransactionThreshold: 500,
  
  // Whether to require voice authentication for all transactions
  requireVoiceAuthForTransactions: true,
  
  // Tokens that require additional confirmation
  tokensRequiringAdditionalConfirmation: []
};

/**
 * Security settings configuration
 * @type {Object}
 */
const DefaultSecuritySettings = {
  // Whether to encrypt wallet state
  encryptWalletState: true,
  
  // Whether to require voice authentication on startup
  requireVoiceAuthOnStartup: false,
  
  // Timeout for automatic logout in milliseconds (30 minutes)
  autoLogoutTimeout: 30 * 60 * 1000,
  
  // Whether to clear sensitive data on logout
  clearDataOnLogout: true,
  
  // Whether to show transaction confirmations
  showTransactionConfirmations: true,
  
  // Whether to show security warnings
  showSecurityWarnings: true,
  
  // Whether to block known phishing sites
  blockPhishingSites: true,
  
  // Whether to validate contract addresses
  validateContractAddresses: true,
  
  // Whether to validate transaction destinations
  validateTransactionDestinations: true
};

/**
 * Gets the current permissions
 * @returns {Promise<Object>} Current permissions
 */
async function getPermissions() {
  try {
    return await new Promise((resolve) => {
      chrome.storage.local.get('cryptovoice_permissions', (result) => {
        resolve(result.cryptovoice_permissions || { ...DefaultPermissions });
      });
    });
  } catch (error) {
    console.error('Error getting permissions:', error);
    return { ...DefaultPermissions };
  }
}

/**
 * Sets a specific permission
 * @param {string} permissionType - Permission type from PermissionTypes enum
 * @param {boolean} value - Permission value
 * @returns {Promise<boolean>} Success status
 */
async function setPermission(permissionType, value) {
  try {
    // Get current permissions
    const permissions = await getPermissions();
    
    // Update permission
    permissions[permissionType] = value;
    
    // Save permissions
    await new Promise((resolve, reject) => {
      chrome.storage.local.set({ 'cryptovoice_permissions': permissions }, () => {
        if (chrome.runtime.lastError) {
          reject(chrome.runtime.lastError);
        } else {
          resolve();
        }
      });
    });
    
    return true;
  } catch (error) {
    console.error('Error setting permission:', error);
    return false;
  }
}

/**
 * Checks if a permission is granted
 * @param {string} permissionType - Permission type from PermissionTypes enum
 * @returns {Promise<boolean>} Whether the permission is granted
 */
async function hasPermission(permissionType) {
  try {
    const permissions = await getPermissions();
    return !!permissions[permissionType];
  } catch (error) {
    console.error('Error checking permission:', error);
    return false;
  }
}

/**
 * Resets permissions to defaults
 * @returns {Promise<boolean>} Success status
 */
async function resetPermissionsToDefault() {
  try {
    await new Promise((resolve, reject) => {
      chrome.storage.local.set({ 'cryptovoice_permissions': { ...DefaultPermissions } }, () => {
        if (chrome.runtime.lastError) {
          reject(chrome.runtime.lastError);
        } else {
          resolve();
        }
      });
    });
    
    return true;
  } catch (error) {
    console.error('Error resetting permissions:', error);
    return false;
  }
}

/**
 * Gets the current transaction limits
 * @returns {Promise<Object>} Current transaction limits
 */
async function getTransactionLimits() {
  try {
    return await new Promise((resolve) => {
      chrome.storage.local.get('cryptovoice_transaction_limits', (result) => {
        resolve(result.cryptovoice_transaction_limits || { ...DefaultTransactionLimits });
      });
    });
  } catch (error) {
    console.error('Error getting transaction limits:', error);
    return { ...DefaultTransactionLimits };
  }
}

/**
 * Updates transaction limits
 * @param {Object} limits - New transaction limits
 * @returns {Promise<boolean>} Success status
 */
async function updateTransactionLimits(limits) {
  try {
    // Get current limits
    const currentLimits = await getTransactionLimits();
    
    // Merge with new limits
    const updatedLimits = { ...currentLimits, ...limits };
    
    // Save limits
    await new Promise((resolve, reject) => {
      chrome.storage.local.set({ 'cryptovoice_transaction_limits': updatedLimits }, () => {
        if (chrome.runtime.lastError) {
          reject(chrome.runtime.lastError);
        } else {
          resolve();
        }
      });
    });
    
    return true;
  } catch (error) {
    console.error('Error updating transaction limits:', error);
    return false;
  }
}

/**
 * Resets transaction limits to defaults
 * @returns {Promise<boolean>} Success status
 */
async function resetTransactionLimitsToDefault() {
  try {
    await new Promise((resolve, reject) => {
      chrome.storage.local.set({ 'cryptovoice_transaction_limits': { ...DefaultTransactionLimits } }, () => {
        if (chrome.runtime.lastError) {
          reject(chrome.runtime.lastError);
        } else {
          resolve();
        }
      });
    });
    
    return true;
  } catch (error) {
    console.error('Error resetting transaction limits:', error);
    return false;
  }
}

/**
 * Gets the current security settings
 * @returns {Promise<Object>} Current security settings
 */
async function getSecuritySettings() {
  try {
    return await new Promise((resolve) => {
      chrome.storage.local.get('cryptovoice_security_settings', (result) => {
        resolve(result.cryptovoice_security_settings || { ...DefaultSecuritySettings });
      });
    });
  } catch (error) {
    console.error('Error getting security settings:', error);
    return { ...DefaultSecuritySettings };
  }
}

/**
 * Updates security settings
 * @param {Object} settings - New security settings
 * @returns {Promise<boolean>} Success status
 */
async function updateSecuritySettings(settings) {
  try {
    // Get current settings
    const currentSettings = await getSecuritySettings();
    
    // Merge with new settings
    const updatedSettings = { ...currentSettings, ...settings };
    
    // Save settings
    await new Promise((resolve, reject) => {
      chrome.storage.local.set({ 'cryptovoice_security_settings': updatedSettings }, () => {
        if (chrome.runtime.lastError) {
          reject(chrome.runtime.lastError);
        } else {
          resolve();
        }
      });
    });
    
    return true;
  } catch (error) {
    console.error('Error updating security settings:', error);
    return false;
  }
}

/**
 * Resets security settings to defaults
 * @returns {Promise<boolean>} Success status
 */
async function resetSecuritySettingsToDefault() {
  try {
    await new Promise((resolve, reject) => {
      chrome.storage.local.set({ 'cryptovoice_security_settings': { ...DefaultSecuritySettings } }, () => {
        if (chrome.runtime.lastError) {
          reject(chrome.runtime.lastError);
        } else {
          resolve();
        }
      });
    });
    
    return true;
  } catch (error) {
    console.error('Error resetting security settings:', error);
    return false;
  }
}

/**
 * Checks if a transaction is within limits
 * @param {Object} transaction - Transaction to check
 * @param {Object} transactionHistory - Transaction history
 * @returns {Promise<Object>} Validation result
 */
async function validateTransactionAgainstLimits(transaction, transactionHistory) {
  try {
    // Get transaction limits
    const limits = await getTransactionLimits();
    
    // Initialize result
    const result = {
      valid: true,
      reasons: []
    };
    
    // Check transaction amount
    if (transaction.amountUSD > limits.maxTransactionAmount) {
      result.valid = false;
      result.reasons.push(`Transaction amount exceeds the maximum limit of $${limits.maxTransactionAmount}`);
    }
    
    // Check if this is a large transaction requiring confirmation
    if (limits.requireConfirmationForLargeTransactions && 
        transaction.amountUSD >= limits.largeTransactionThreshold) {
      result.requiresAdditionalConfirmation = true;
    }
    
    // Check if token requires additional confirmation
    if (limits.tokensRequiringAdditionalConfirmation.includes(transaction.token)) {
      result.requiresAdditionalConfirmation = true;
    }
    
    // Check daily volume
    if (transactionHistory && transactionHistory.length > 0) {
      // Filter transactions from today
      const today = new Date();
      today.setHours(0, 0, 0, 0);
      
      const todayTransactions = transactionHistory.filter(tx => {
        const txDate = new Date(tx.timestamp);
        return txDate >= today;
      });
      
      // Calculate daily volume
      const dailyVolume = todayTransactions.reduce((sum, tx) => sum + (tx.amountUSD || 0), 0);
      
      // Check if this transaction would exceed daily volume
      if (dailyVolume + transaction.amountUSD > limits.maxDailyVolume) {
        result.valid = false;
        result.reasons.push(`Transaction would exceed the daily volume limit of $${limits.maxDailyVolume}`);
      }
      
      // Check number of daily transactions
      if (todayTransactions.length >= limits.maxDailyTransactions) {
        result.valid = false;
        result.reasons.push(`Maximum number of daily transactions (${limits.maxDailyTransactions}) reached`);
      }
      
      // Check time between transactions
      if (todayTransactions.length > 0) {
        const lastTransaction = todayTransactions[todayTransactions.length - 1];
        const lastTxTime = new Date(lastTransaction.timestamp).getTime();
        const currentTime = new Date().getTime();
        
        if (currentTime - lastTxTime < limits.minTimeBetweenTransactions) {
          result.valid = false;
          result.reasons.push(`Minimum time between transactions (${limits.minTimeBetweenTransactions / 60000} minutes) not reached`);
        }
      }
    }
    
    // Check if voice authentication is required
    if (limits.requireVoiceAuthForTransactions) {
      result.requiresVoiceAuthentication = true;
    }
    
    return result;
  } catch (error) {
    console.error('Error validating transaction against limits:', error);
    return {
      valid: false,
      reasons: ['Error validating transaction: ' + error.message]
    };
  }
}

/**
 * Validates a transaction destination address
 * @param {string} address - Destination address
 * @param {string} network - Blockchain network
 * @returns {Promise<Object>} Validation result
 */
async function validateTransactionDestination(address, network) {
  try {
    // Get security settings
    const settings = await getSecuritySettings();
    
    // Initialize result
    const result = {
      valid: true,
      reasons: []
    };
    
    // Skip validation if disabled
    if (!settings.validateTransactionDestinations) {
      return result;
    }
    
    // In a real implementation, this would check against known scam addresses,
    // validate address format, etc.
    
    // For now, we'll just do basic format validation
    if (!address) {
      result.valid = false;
      result.reasons.push('Address is empty');
      return result;
    }
    
    // Basic Ethereum address validation
    if (network === 'ethereum' || network === 'polygon' || network === 'bsc') {
      if (!address.match(/^0x[a-fA-F0-9]{40}$/)) {
        result.valid = false;
        result.reasons.push('Invalid Ethereum address format');
      }
    }
    
    // Basic Solana address validation
    if (network === 'solana') {
      if (!address.match(/^[1-9A-HJ-NP-Za-km-z]{32,44}$/)) {
        result.valid = false;
        result.reasons.push('Invalid Solana address format');
      }
    }
    
    return result;
  } catch (error) {
    console.error('Error validating transaction destination:', error);
    return {
      valid: false,
      reasons: ['Error validating destination: ' + error.message]
    };
  }
}

/**
 * Validates a contract address
 * @param {string} address - Contract address
 * @param {string} network - Blockchain network
 * @returns {Promise<Object>} Validation result
 */
async function validateContractAddress(address, network) {
  try {
    // Get security settings
    const settings = await getSecuritySettings();
    
    // Initialize result
    const result = {
      valid: true,
      reasons: []
    };
    
    // Skip validation if disabled
    if (!settings.validateContractAddresses) {
      return result;
    }
    
    // In a real implementation, this would check against known contract addresses,
    // verify contract code, etc.
    
    // For now, we'll just do basic format validation
    if (!address) {
      result.valid = false;
      result.reasons.push('Contract address is empty');
      return result;
    }
    
    // Basic Ethereum contract address validation
    if (network === 'ethereum' || network === 'polygon' || network === 'bsc') {
      if (!address.match(/^0x[a-fA-F0-9]{40}$/)) {
        result.valid = false;
        result.reasons.push('Invalid Ethereum contract address format');
      }
    }
    
    // Basic Solana contract address validation
    if (network === 'solana') {
      if (!address.match(/^[1-9A-HJ-NP-Za-km-z]{32,44}$/)) {
        result.valid = false;
        result.reasons.push('Invalid Solana contract address format');
      }
    }
    
    return result;
  } catch (error) {
    console.error('Error validating contract address:', error);
    return {
      valid: false,
      reasons: ['Error validating contract: ' + error.message]
    };
  }
}

/**
 * Checks if a URL is a known phishing site
 * @param {string} url - URL to check
 * @returns {Promise<Object>} Check result
 */
async function checkPhishingSite(url) {
  try {
    // Get security settings
    const settings = await getSecuritySettings();
    
    // Initialize result
    const result = {
      isPhishing: false,
      reasons: []
    };
    
    // Skip check if disabled
    if (!settings.blockPhishingSites) {
      return result;
    }
    
    // In a real implementation, this would check against phishing databases,
    // use heuristics, etc.
    
    // For now, we'll just check against a small hardcoded list
    const knownPhishingDomains = [
      'metamask.io.phishing.com',
      'phantom-wallet.com',
      'uniswapp.org',
      'pancakeswapp.finance',
      'walletconnect.tech'
    ];
    
    // Extract domain from URL
    let domain = '';
    try {
      domain = new URL(url).hostname;
    } catch (error) {
      // Invalid URL
      return result;
    }
    
    // Check against known phishing domains
    if (knownPhishingDomains.includes(domain)) {
      result.isPhishing = true;
      result.reasons.push(`Domain "${domain}" is a known phishing site`);
    }
    
    // Check for suspicious patterns
    const suspiciousPatterns = [
      /metamask.*\.io(?!\.metamask\.io)/i,
      /phantom.*wallet/i,
      /wallet.*connect/i,
      /uniswap[^.]*\./i,
      /pancake[^.]*swap/i
    ];
    
    for (const pattern of suspiciousPatterns) {
      if (pattern.test(domain)) {
        result.suspicious = true;
        result.reasons.push(`Domain "${domain}" matches suspicious pattern`);
      }
    }
    
    return result;
  } catch (error) {
    console.error('Error checking phishing site:', error);
    return {
      isPhishing: false,
      suspicious: true,
      reasons: ['Error checking site: ' + error.message]
    };
  }
}

// Export functions and constants
if (typeof module !== 'undefined' && module.exports) {
  module.exports = {
    PermissionTypes,
    DefaultPermissions,
    DefaultTransactionLimits,
    DefaultSecuritySettings,
    getPermissions,
    setPermission,
    hasPermission,
    resetPermissionsToDefault,
    getTransactionLimits,
    updateTransactionLimits,
    resetTransactionLimitsToDefault,
    getSecuritySettings,
    updateSecuritySettings,
    resetSecuritySettingsToDefault,
    validateTransactionAgainstLimits,
    validateTransactionDestination,
    validateContractAddress,
    checkPhishingSite
  };
} else {
  // For browser environment
  window.permissionsUtils = {
    PermissionTypes,
    DefaultPermissions,
    DefaultTransactionLimits,
    DefaultSecuritySettings,
    getPermissions,
    setPermission,
    hasPermission,
    resetPermissionsToDefault,
    getTransactionLimits,
    updateTransactionLimits,
    resetTransactionLimitsToDefault,
    getSecuritySettings,
    updateSecuritySettings,
    resetSecuritySettingsToDefault,
    validateTransactionAgainstLimits,
    validateTransactionDestination,
    validateContractAddress,
    checkPhishingSite
  };
}
