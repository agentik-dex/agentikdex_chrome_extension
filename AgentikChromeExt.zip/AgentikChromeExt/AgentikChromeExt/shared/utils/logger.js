/**
 * CryptoVoice - Logger Utilities
 * 
 * This file contains utility functions for logging operations
 * throughout the extension with different log levels and targets.
 */

/**
 * Log levels
 * @enum {number}
 */
const LogLevels = {
  TRACE: 0,
  DEBUG: 1,
  INFO: 2,
  WARN: 3,
  ERROR: 4,
  FATAL: 5,
  NONE: 6
};

/**
 * Log level names
 * @type {Object}
 */
const LogLevelNames = {
  [LogLevels.TRACE]: 'TRACE',
  [LogLevels.DEBUG]: 'DEBUG',
  [LogLevels.INFO]: 'INFO',
  [LogLevels.WARN]: 'WARN',
  [LogLevels.ERROR]: 'ERROR',
  [LogLevels.FATAL]: 'FATAL',
  [LogLevels.NONE]: 'NONE'
};

/**
 * Log categories
 * @enum {string}
 */
const LogCategories = {
  VOICE: 'voice',
  WALLET: 'wallet',
  AGENT: 'agent',
  STORAGE: 'storage',
  UI: 'ui',
  DEFI: 'defi',
  SECURITY: 'security',
  NETWORK: 'network',
  EXTENSION: 'extension',
  GENERAL: 'general'
};

/**
 * Default logger configuration
 * @type {Object}
 */
const DefaultLoggerConfig = {
  // Default log level
  level: process.env.NODE_ENV === 'development' ? LogLevels.DEBUG : LogLevels.INFO,
  
  // Maximum number of logs to keep in memory
  maxLogsInMemory: 1000,
  
  // Whether to log to console
  logToConsole: process.env.NODE_ENV === 'development',
  
  // Whether to log to storage
  logToStorage: true,
  
  // Whether to include timestamps
  includeTimestamps: true,
  
  // Whether to include log level
  includeLogLevel: true,
  
  // Whether to include category
  includeCategory: true,
  
  // Whether to include source location
  includeSourceLocation: process.env.NODE_ENV === 'development',
  
  // Per-category settings
  categorySettings: {
    [LogCategories.VOICE]: { level: LogLevels.INFO },
    [LogCategories.WALLET]: { level: LogLevels.INFO },
    [LogCategories.AGENT]: { level: LogLevels.INFO },
    [LogCategories.STORAGE]: { level: LogLevels.INFO },
    [LogCategories.UI]: { level: LogLevels.INFO },
    [LogCategories.DEFI]: { level: LogLevels.INFO },
    [LogCategories.SECURITY]: { level: LogLevels.INFO },
    [LogCategories.NETWORK]: { level: LogLevels.INFO },
    [LogCategories.EXTENSION]: { level: LogLevels.INFO },
    [LogCategories.GENERAL]: { level: LogLevels.INFO }
  }
};

/**
 * In-memory log storage
 * @type {Array}
 */
let logs = [];

/**
 * Current logger configuration
 * @type {Object}
 */
let loggerConfig = { ...DefaultLoggerConfig };

/**
 * Formats a log message
 * @param {number} level - Log level
 * @param {string} category - Log category
 * @param {string} message - Log message
 * @param {Object} data - Additional log data
 * @param {string} source - Source location
 * @returns {Object} Formatted log entry
 */
function formatLogEntry(level, category, message, data, source) {
  const timestamp = new Date().toISOString();
  
  // Create log entry
  const logEntry = {
    timestamp,
    level,
    levelName: LogLevelNames[level],
    category,
    message,
    data
  };
  
  // Add source location if enabled
  if (loggerConfig.includeSourceLocation && source) {
    logEntry.source = source;
  }
  
  return logEntry;
}

/**
 * Formats a log entry for console output
 * @param {Object} logEntry - Log entry
 * @returns {string} Formatted log message
 */
function formatConsoleMessage(logEntry) {
  const parts = [];
  
  // Add timestamp if enabled
  if (loggerConfig.includeTimestamps) {
    parts.push(`[${logEntry.timestamp}]`);
  }
  
  // Add log level if enabled
  if (loggerConfig.includeLogLevel) {
    parts.push(`[${logEntry.levelName}]`);
  }
  
  // Add category if enabled
  if (loggerConfig.includeCategory) {
    parts.push(`[${logEntry.category}]`);
  }
  
  // Add message
  parts.push(logEntry.message);
  
  // Add source location if available
  if (logEntry.source) {
    parts.push(`(${logEntry.source})`);
  }
  
  return parts.join(' ');
}

/**
 * Gets the source location
 * @returns {string} Source location
 */
function getSourceLocation() {
  try {
    const err = new Error();
    const stack = err.stack.split('\n');
    
    // Find the caller in the stack trace
    // Skip the first 3 lines (Error, getSourceLocation, log)
    const callerLine = stack[3] || '';
    
    // Extract source location
    const match = callerLine.match(/at\s+(.*)\s+\((.*):(\d+):(\d+)\)/) || 
                 callerLine.match(/at\s+(.*):(\d+):(\d+)/);
    
    if (match) {
      const [, fnName, fileName, line, column] = match;
      return `${fileName.split('/').pop()}:${line}`;
    }
    
    return '';
  } catch (error) {
    return '';
  }
}

/**
 * Checks if a log should be processed based on level and category
 * @param {number} level - Log level
 * @param {string} category - Log category
 * @returns {boolean} Whether the log should be processed
 */
function shouldLog(level, category) {
  // Get category settings
  const categorySettings = loggerConfig.categorySettings[category] || {};
  
  // Get category log level or default
  const categoryLevel = categorySettings.level !== undefined ? categorySettings.level : loggerConfig.level;
  
  // Check if log level is high enough
  return level >= categoryLevel;
}

/**
 * Logs a message
 * @param {number} level - Log level
 * @param {string} category - Log category
 * @param {string} message - Log message
 * @param {Object} data - Additional log data
 */
function log(level, category, message, data = {}) {
  // Skip if log level is not high enough
  if (!shouldLog(level, category)) {
    return;
  }
  
  // Get source location if enabled
  const source = loggerConfig.includeSourceLocation ? getSourceLocation() : '';
  
  // Format log entry
  const logEntry = formatLogEntry(level, category, message, data, source);
  
  // Log to console if enabled
  if (loggerConfig.logToConsole) {
    const consoleMessage = formatConsoleMessage(logEntry);
    
    // Use appropriate console method based on log level
    switch (level) {
      case LogLevels.TRACE:
      case LogLevels.DEBUG:
        console.debug(consoleMessage, data);
        break;
      case LogLevels.INFO:
        console.info(consoleMessage, data);
        break;
      case LogLevels.WARN:
        console.warn(consoleMessage, data);
        break;
      case LogLevels.ERROR:
      case LogLevels.FATAL:
        console.error(consoleMessage, data);
        break;
    }
  }
  
  // Add to in-memory logs
  logs.push(logEntry);
  
  // Trim logs if too many
  if (logs.length > loggerConfig.maxLogsInMemory) {
    logs = logs.slice(-loggerConfig.maxLogsInMemory);
  }
  
  // Log to storage if enabled
  if (loggerConfig.logToStorage) {
    storeLog(logEntry);
  }
}

/**
 * Stores a log entry in storage
 * @param {Object} logEntry - Log entry
 */
function storeLog(logEntry) {
  try {
    // Skip if not in extension context
    if (typeof chrome === 'undefined' || !chrome.storage || !chrome.storage.local) {
      return;
    }
    
    // Get stored logs
    chrome.storage.local.get('cryptovoice_logs', (result) => {
      // Get existing logs or initialize empty array
      const storedLogs = result.cryptovoice_logs || [];
      
      // Add new log
      storedLogs.push(logEntry);
      
      // Trim logs if too many
      const trimmedLogs = storedLogs.slice(-loggerConfig.maxLogsInMemory);
      
      // Save logs
      chrome.storage.local.set({ 'cryptovoice_logs': trimmedLogs });
    });
  } catch (error) {
    // Log to console if storage fails
    console.error('Error storing log:', error);
  }
}

/**
 * Gets logs from storage
 * @returns {Promise<Array>} Logs
 */
async function getStoredLogs() {
  try {
    // Skip if not in extension context
    if (typeof chrome === 'undefined' || !chrome.storage || !chrome.storage.local) {
      return [];
    }
    
    // Get stored logs
    return await new Promise((resolve) => {
      chrome.storage.local.get('cryptovoice_logs', (result) => {
        resolve(result.cryptovoice_logs || []);
      });
    });
  } catch (error) {
    console.error('Error getting stored logs:', error);
    return [];
  }
}

/**
 * Clears logs from storage
 * @returns {Promise<boolean>} Success status
 */
async function clearStoredLogs() {
  try {
    // Skip if not in extension context
    if (typeof chrome === 'undefined' || !chrome.storage || !chrome.storage.local) {
      return false;
    }
    
    // Clear stored logs
    await new Promise((resolve) => {
      chrome.storage.local.remove('cryptovoice_logs', resolve);
    });
    
    return true;
  } catch (error) {
    console.error('Error clearing stored logs:', error);
    return false;
  }
}

/**
 * Gets in-memory logs
 * @returns {Array} Logs
 */
function getInMemoryLogs() {
  return [...logs];
}

/**
 * Clears in-memory logs
 */
function clearInMemoryLogs() {
  logs = [];
}

/**
 * Gets logger configuration
 * @returns {Object} Logger configuration
 */
function getLoggerConfig() {
  return { ...loggerConfig };
}

/**
 * Updates logger configuration
 * @param {Object} config - New configuration
 * @returns {Object} Updated configuration
 */
function updateLoggerConfig(config) {
  // Merge with current config
  loggerConfig = {
    ...loggerConfig,
    ...config,
    categorySettings: {
      ...loggerConfig.categorySettings,
      ...(config.categorySettings || {})
    }
  };
  
  return { ...loggerConfig };
}

/**
 * Resets logger configuration to defaults
 * @returns {Object} Default configuration
 */
function resetLoggerConfig() {
  loggerConfig = { ...DefaultLoggerConfig };
  return { ...loggerConfig };
}

/**
 * Logs a trace message
 * @param {string} category - Log category
 * @param {string} message - Log message
 * @param {Object} data - Additional log data
 */
function trace(category, message, data = {}) {
  log(LogLevels.TRACE, category, message, data);
}

/**
 * Logs a debug message
 * @param {string} category - Log category
 * @param {string} message - Log message
 * @param {Object} data - Additional log data
 */
function debug(category, message, data = {}) {
  log(LogLevels.DEBUG, category, message, data);
}

/**
 * Logs an info message
 * @param {string} category - Log category
 * @param {string} message - Log message
 * @param {Object} data - Additional log data
 */
function info(category, message, data = {}) {
  log(LogLevels.INFO, category, message, data);
}

/**
 * Logs a warning message
 * @param {string} category - Log category
 * @param {string} message - Log message
 * @param {Object} data - Additional log data
 */
function warn(category, message, data = {}) {
  log(LogLevels.WARN, category, message, data);
}

/**
 * Logs an error message
 * @param {string} category - Log category
 * @param {string} message - Log message
 * @param {Object} data - Additional log data
 */
function error(category, message, data = {}) {
  log(LogLevels.ERROR, category, message, data);
}

/**
 * Logs a fatal message
 * @param {string} category - Log category
 * @param {string} message - Log message
 * @param {Object} data - Additional log data
 */
function fatal(category, message, data = {}) {
  log(LogLevels.FATAL, category, message, data);
}

/**
 * Creates a logger for a specific category
 * @param {string} category - Log category
 * @returns {Object} Category logger
 */
function createCategoryLogger(category) {
  return {
    trace: (message, data) => trace(category, message, data),
    debug: (message, data) => debug(category, message, data),
    info: (message, data) => info(category, message, data),
    warn: (message, data) => warn(category, message, data),
    error: (message, data) => error(category, message, data),
    fatal: (message, data) => fatal(category, message, data)
  };
}

/**
 * Exports logs to a file
 * @param {string} format - Export format (json or csv)
 * @returns {string} Exported logs
 */
function exportLogs(format = 'json') {
  try {
    // Get all logs
    const allLogs = [...logs];
    
    // Export based on format
    if (format === 'csv') {
      // Define CSV headers
      const headers = ['timestamp', 'level', 'levelName', 'category', 'message', 'source'];
      
      // Create CSV rows
      const rows = allLogs.map(log => {
        return [
          log.timestamp,
          log.level,
          log.levelName,
          log.category,
          `"${log.message.replace(/"/g, '""')}"`,
          log.source || ''
        ].join(',');
      });
      
      // Combine headers and rows
      return [headers.join(','), ...rows].join('\n');
    } else {
      // Export as JSON
      return JSON.stringify(allLogs, null, 2);
    }
  } catch (error) {
    console.error('Error exporting logs:', error);
    return '';
  }
}

/**
 * Filters logs by criteria
 * @param {Object} filters - Filter criteria
 * @returns {Array} Filtered logs
 */
function filterLogs(filters = {}) {
  try {
    // Get all logs
    const allLogs = [...logs];
    
    // Apply filters
    return allLogs.filter(log => {
      // Filter by level
      if (filters.level !== undefined && log.level < filters.level) {
        return false;
      }
      
      // Filter by category
      if (filters.category && log.category !== filters.category) {
        return false;
      }
      
      // Filter by start date
      if (filters.startDate) {
        const logDate = new Date(log.timestamp);
        const startDate = new Date(filters.startDate);
        
        if (logDate < startDate) {
          return false;
        }
      }
      
      // Filter by end date
      if (filters.endDate) {
        const logDate = new Date(log.timestamp);
        const endDate = new Date(filters.endDate);
        
        if (logDate > endDate) {
          return false;
        }
      }
      
      // Filter by search term
      if (filters.searchTerm) {
        const searchTerm = filters.searchTerm.toLowerCase();
        const messageMatches = log.message.toLowerCase().includes(searchTerm);
        const categoryMatches = log.category.toLowerCase().includes(searchTerm);
        const sourceMatches = log.source && log.source.toLowerCase().includes(searchTerm);
        
        if (!messageMatches && !categoryMatches && !sourceMatches) {
          return false;
        }
      }
      
      return true;
    });
  } catch (error) {
    console.error('Error filtering logs:', error);
    return [];
  }
}

// Export functions and constants
if (typeof module !== 'undefined' && module.exports) {
  module.exports = {
    LogLevels,
    LogLevelNames,
    LogCategories,
    DefaultLoggerConfig,
    log,
    trace,
    debug,
    info,
    warn,
    error,
    fatal,
    getInMemoryLogs,
    getStoredLogs,
    clearInMemoryLogs,
    clearStoredLogs,
    getLoggerConfig,
    updateLoggerConfig,
    resetLoggerConfig,
    createCategoryLogger,
    exportLogs,
    filterLogs
  };
} else {
  // For browser environment
  window.loggerUtils = {
    LogLevels,
    LogLevelNames,
    LogCategories,
    DefaultLoggerConfig,
    log,
    trace,
    debug,
    info,
    warn,
    error,
    fatal,
    getInMemoryLogs,
    getStoredLogs,
    clearInMemoryLogs,
    clearStoredLogs,
    getLoggerConfig,
    updateLoggerConfig,
    resetLoggerConfig,
    createCategoryLogger,
    exportLogs,
    filterLogs
  };
}
