/**
 * Agentik Wallet - DeFi Platform Utilities
 * 
 * This file contains utility functions for interacting with DeFi platforms.
 */

/**
 * Detects which DeFi platform is currently active based on the URL
 * @param {string} url - Current page URL
 * @returns {Object|null} Platform info or null if not supported
 */
function detectPlatform(url) {
  if (!url) return null;
  
  // Define platform detection patterns
  const platforms = [
    {
      id: 'uniswap',
      name: 'Uniswap',
      type: 'dex',
      patterns: ['uniswap.org', 'app.uniswap.org'],
      logo: '../assets/icons/uniswap.png'
    },
    {
      id: 'sushiswap',
      name: 'SushiSwap',
      type: 'dex',
      patterns: ['sushi.com', 'app.sushi.com'],
      logo: '../assets/icons/sushiswap.png'
    },
    {
      id: 'pancakeswap',
      name: 'PancakeSwap',
      type: 'dex',
      patterns: ['pancakeswap.finance', 'exchange.pancakeswap.finance'],
      logo: '../assets/icons/pancakeswap.png'
    },
    {
      id: 'raydium',
      name: 'Raydium',
      type: 'dex',
      patterns: ['raydium.io', 'app.raydium.io'],
      logo: '../assets/icons/raydium.png'
    },
    {
      id: 'aave',
      name: 'Aave',
      type: 'lending',
      patterns: ['aave.com', 'app.aave.com'],
      logo: '../assets/icons/aave.png'
    },
    {
      id: 'compound',
      name: 'Compound',
      type: 'lending',
      patterns: ['compound.finance', 'app.compound.finance'],
      logo: '../assets/icons/compound.png'
    }
  ];
  
  // Check if URL matches any platform
  for (const platform of platforms) {
    if (platform.patterns.some(pattern => url.includes(pattern))) {
      return platform;
    }
  }
  
  return null;
}

/**
 * Detects swap form elements on a DEX page
 * @param {Document} document - DOM document
 * @param {string} platformId - Platform ID
 * @returns {Object|null} Swap form elements or null if not found
 */
function detectSwapForm(document, platformId) {
  if (!document || !platformId) return null;
  
  // Define platform-specific selectors
  const selectors = {
    uniswap: {
      container: '[data-testid="swap-page"]',
      fromInput: 'input[id*="swap-currency-input"]',
      toInput: 'input[id*="swap-currency-output"]',
      fromToken: '[data-testid="swap-currency-input"] .token-symbol-container',
      toToken: '[data-testid="swap-currency-output"] .token-symbol-container',
      swapButton: 'button[data-testid="swap-button"]'
    },
    sushiswap: {
      container: '.swap-panel',
      fromInput: '.swap-panel-input input',
      toInput: '.swap-panel-output input',
      fromToken: '.swap-panel-input .token-symbol-container',
      toToken: '.swap-panel-output .token-symbol-container',
      swapButton: 'button.swap-button'
    },
    pancakeswap: {
      container: '.swap-container',
      fromInput: '.swap-container input[id*="swap-currency-input"]',
      toInput: '.swap-container input[id*="swap-currency-output"]',
      fromToken: '.swap-container .token-symbol-container',
      toToken: '.swap-container .token-symbol-container',
      swapButton: 'button.swap-button'
    },
    raydium: {
      container: '.swap-container',
      fromInput: '.swap-container input[id*="fromInput"]',
      toInput: '.swap-container input[id*="toInput"]',
      fromToken: '.swap-container .from-token',
      toToken: '.swap-container .to-token',
      swapButton: 'button.swap-button'
    }
  };
  
  // Get selectors for the current platform
  const platformSelectors = selectors[platformId];
  if (!platformSelectors) return null;
  
  // Try to find elements
  const container = document.querySelector(platformSelectors.container);
  if (!container) return null;
  
  const fromInput = document.querySelector(platformSelectors.fromInput);
  const toInput = document.querySelector(platformSelectors.toInput);
  const fromToken = document.querySelector(platformSelectors.fromToken);
  const toToken = document.querySelector(platformSelectors.toToken);
  const swapButton = document.querySelector(platformSelectors.swapButton);
  
  // Return found elements
  return {
    container,
    fromInput,
    toInput,
    fromToken: fromToken ? fromToken.textContent.trim() : null,
    toToken: toToken ? toToken.textContent.trim() : null,
    swapButton
  };
}

/**
 * Detects lending form elements on a lending platform page
 * @param {Document} document - DOM document
 * @param {string} platformId - Platform ID
 * @returns {Object|null} Lending form elements or null if not found
 */
function detectLendingForm(document, platformId) {
  if (!document || !platformId) return null;
  
  // Define platform-specific selectors
  const selectors = {
    aave: {
      supplyContainer: '.SupplyContent',
      borrowContainer: '.BorrowContent',
      supplyInput: '.SupplyContent input',
      borrowInput: '.BorrowContent input',
      supplyButton: '.SupplyContent button[type="submit"]',
      borrowButton: '.BorrowContent button[type="submit"]',
      assetSelector: '.AssetSelect'
    },
    compound: {
      supplyContainer: '.supply-container',
      borrowContainer: '.borrow-container',
      supplyInput: '.supply-container input',
      borrowInput: '.borrow-container input',
      supplyButton: '.supply-container button[type="submit"]',
      borrowButton: '.borrow-container button[type="submit"]',
      assetSelector: '.asset-selector'
    }
  };
  
  // Get selectors for the current platform
  const platformSelectors = selectors[platformId];
  if (!platformSelectors) return null;
  
  // Try to find elements
  const supplyContainer = document.querySelector(platformSelectors.supplyContainer);
  const borrowContainer = document.querySelector(platformSelectors.borrowContainer);
  
  // If neither container is found, return null
  if (!supplyContainer && !borrowContainer) return null;
  
  // Return found elements
  return {
    supplyContainer,
    borrowContainer,
    supplyInput: supplyContainer ? document.querySelector(platformSelectors.supplyInput) : null,
    borrowInput: borrowContainer ? document.querySelector(platformSelectors.borrowInput) : null,
    supplyButton: supplyContainer ? document.querySelector(platformSelectors.supplyButton) : null,
    borrowButton: borrowContainer ? document.querySelector(platformSelectors.borrowButton) : null,
    assetSelector: document.querySelector(platformSelectors.assetSelector)
  };
}

/**
 * Fills a swap form with the specified values
 * @param {Object} swapForm - Swap form elements
 * @param {Object} swapData - Swap data
 * @returns {boolean} Success status
 */
function fillSwapForm(swapForm, swapData) {
  if (!swapForm || !swapData) return false;
  
  try {
    // Check if we have the necessary elements
    if (!swapForm.fromInput || !swapForm.toInput) {
      return false;
    }
    
    // Fill the from input
    if (swapData.fromAmount && swapForm.fromInput) {
      // Clear existing value
      swapForm.fromInput.value = '';
      
      // Create and dispatch input event
      const inputEvent = new Event('input', { bubbles: true });
      swapForm.fromInput.value = swapData.fromAmount.toString();
      swapForm.fromInput.dispatchEvent(inputEvent);
    }
    
    // Note: In most DEXes, the to amount is calculated automatically
    // We don't need to fill it, but we can check if token selection is needed
    
    // Check if we need to select tokens
    // This is platform-specific and would require more complex logic
    // For now, we'll just return success if we filled the amount
    
    return true;
  } catch (error) {
    console.error('Error filling swap form:', error);
    return false;
  }
}

/**
 * Fills a lending form with the specified values
 * @param {Object} lendingForm - Lending form elements
 * @param {Object} lendingData - Lending data
 * @returns {boolean} Success status
 */
function fillLendingForm(lendingForm, lendingData) {
  if (!lendingForm || !lendingData) return false;
  
  try {
    // Determine if we're supplying or borrowing
    const isSupply = lendingData.action === 'supply';
    
    // Get the appropriate input and button
    const input = isSupply ? lendingForm.supplyInput : lendingForm.borrowInput;
    const button = isSupply ? lendingForm.supplyButton : lendingForm.borrowButton;
    
    // Check if we have the necessary elements
    if (!input || !button) {
      return false;
    }
    
    // Fill the input
    if (lendingData.amount && input) {
      // Clear existing value
      input.value = '';
      
      // Create and dispatch input event
      const inputEvent = new Event('input', { bubbles: true });
      input.value = lendingData.amount.toString();
      input.dispatchEvent(inputEvent);
    }
    
    // Note: Asset selection would be platform-specific
    // For now, we'll just return success if we filled the amount
    
    return true;
  } catch (error) {
    console.error('Error filling lending form:', error);
    return false;
  }
}

/**
 * Captures current form data from a swap form
 * @param {Object} swapForm - Swap form elements
 * @returns {Object|null} Captured swap data or null if not available
 */
function captureSwapFormData(swapForm) {
  if (!swapForm) return null;
  
  try {
    // Extract data from form elements
    const fromAmount = swapForm.fromInput ? parseFloat(swapForm.fromInput.value) || 0 : 0;
    const toAmount = swapForm.toInput ? parseFloat(swapForm.toInput.value) || 0 : 0;
    const fromToken = swapForm.fromToken || '';
    const toToken = swapForm.toToken || '';
    
    // Return captured data
    return {
      fromAmount,
      toAmount,
      fromToken,
      toToken,
      timestamp: new Date().toISOString()
    };
  } catch (error) {
    console.error('Error capturing swap form data:', error);
    return null;
  }
}

/**
 * Captures current form data from a lending form
 * @param {Object} lendingForm - Lending form elements
 * @returns {Object|null} Captured lending data or null if not available
 */
function captureLendingFormData(lendingForm) {
  if (!lendingForm) return null;
  
  try {
    // Determine if supply or borrow is active
    const isSupplyActive = lendingForm.supplyContainer && 
      !lendingForm.supplyContainer.classList.contains('hidden');
    
    // Extract data from form elements
    const amount = isSupplyActive 
      ? (lendingForm.supplyInput ? parseFloat(lendingForm.supplyInput.value) || 0 : 0)
      : (lendingForm.borrowInput ? parseFloat(lendingForm.borrowInput.value) || 0 : 0);
    
    // Asset would require more complex DOM traversal
    // For now, we'll just return the action and amount
    
    // Return captured data
    return {
      action: isSupplyActive ? 'supply' : 'borrow',
      amount,
      timestamp: new Date().toISOString()
    };
  } catch (error) {
    console.error('Error capturing lending form data:', error);
    return null;
  }
}

/**
 * Adds the Agentik Wallet control button to a DeFi platform page
 * @param {Document} document - DOM document
 * @param {string} platformId - Platform ID
 * @returns {HTMLElement|null} Created button or null if failed
 */
function addControlButton(document, platformId) {
  if (!document || !platformId) return null;
  
  try {
    // Check if button already exists
    if (document.querySelector('#cryptovoice-control')) {
      return document.querySelector('#cryptovoice-control');
    }
    
    // Create button element
    const button = document.createElement('button');
    button.id = 'cryptovoice-control';
    button.className = 'cryptovoice-control-button';
    button.innerHTML = `
      <img src="${chrome.runtime.getURL('assets/icons/icon48.png')}" alt="Agentik Wallet" />
      <span>Agentik Wallet</span>
    `;
    
    // Style the button
    button.style.position = 'fixed';
    button.style.bottom = '20px';
    button.style.right = '20px';
    button.style.zIndex = '9999';
    button.style.display = 'flex';
    button.style.alignItems = 'center';
    button.style.justifyContent = 'center';
    button.style.padding = '10px 15px';
    button.style.borderRadius = '20px';
    button.style.backgroundColor = '#6200EA';
    button.style.color = 'white';
    button.style.boxShadow = '0 4px 8px rgba(0, 0, 0, 0.2)';
    button.style.cursor = 'pointer';
    button.style.border = 'none';
    button.style.fontWeight = 'bold';
    button.style.transition = 'all 0.3s ease';
    
    // Style the button image
    const img = button.querySelector('img');
    if (img) {
      img.style.width = '24px';
      img.style.height = '24px';
      img.style.marginRight = '8px';
    }
    
    // Add hover effect
    button.addEventListener('mouseover', () => {
      button.style.backgroundColor = '#7C4DFF';
      button.style.transform = 'translateY(-2px)';
    });
    
    button.addEventListener('mouseout', () => {
      button.style.backgroundColor = '#6200EA';
      button.style.transform = 'translateY(0)';
    });
    
    // Add click handler
    button.addEventListener('click', () => {
      // Send message to background script
      chrome.runtime.sendMessage({
        action: 'openVoiceControl',
        platform: platformId
      });
    });
    
    // Add to document
    document.body.appendChild(button);
    
    return button;
  } catch (error) {
    console.error('Error adding control button:', error);
    return null;
  }
}

/**
 * Observes DOM mutations to detect form changes
 * @param {Document} document - DOM document
 * @param {string} platformId - Platform ID
 * @param {Function} callback - Callback function when forms are detected
 * @returns {MutationObserver|null} Created observer or null if failed
 */
function observeFormChanges(document, platformId, callback) {
  if (!document || !platformId || !callback) return null;
  
  try {
    // Create mutation observer
    const observer = new MutationObserver((mutations) => {
      // Check if we need to look for forms
      const swapForm = detectSwapForm(document, platformId);
      const lendingForm = detectLendingForm(document, platformId);
      
      // Call callback with detected forms
      callback({
        platformId,
        swapForm,
        lendingForm
      });
    });
    
    // Start observing
    observer.observe(document.body, {
      childList: true,
      subtree: true,
      attributes: true,
      attributeFilter: ['class', 'style']
    });
    
    return observer;
  } catch (error) {
    console.error('Error observing form changes:', error);
    return null;
  }
}

// Export functions
if (typeof module !== 'undefined' && module.exports) {
  module.exports = {
    detectPlatform,
    detectSwapForm,
    detectLendingForm,
    fillSwapForm,
    fillLendingForm,
    captureSwapFormData,
    captureLendingFormData,
    addControlButton,
    observeFormChanges
  };
} else {
  // For browser environment
  window.defiPlatformUtils = {
    detectPlatform,
    detectSwapForm,
    detectLendingForm,
    fillSwapForm,
    fillLendingForm,
    captureSwapFormData,
    captureLendingFormData,
    addControlButton,
    observeFormChanges
  };
}
