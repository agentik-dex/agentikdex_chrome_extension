/**
 * Agentik Wallet - Configuration Manager Utilities
 * 
 * This file contains utility functions for managing extension configuration.
 */

/**
 * Default configuration settings
 * @type {Object}
 */
const DefaultConfig = {
  // General settings
  general: {
    theme: 'light',
    language: 'en',
    notificationsEnabled: true,
    soundEffectsEnabled: true,
    autoStartVoiceRecognition: false,
    showBalancesInHeader: true,
    defaultCurrency: 'USD',
    dateFormat: 'MM/DD/YYYY',
    timeFormat: '12h',
    decimalPrecision: 4
  },
  
  // Voice settings
  voice: {
    wakeWord: 'hey cryptovoice',
    recognitionSensitivity: 0.7,
    voiceResponseEnabled: true,
    voiceResponseVolume: 0.8,
    voiceResponseSpeed: 1.0,
    voiceGender: 'female',
    continuousListening: false,
    listeningTimeout: 30000,
    commandConfirmation: true
  },
  
  // Wallet settings
  wallet: {
    defaultNetwork: 'ethereum',
    autoConnectLastWallet: true,
    showTestNetworks: false,
    gasSpeedPreference: 'medium',
    showGasDetails: true,
    confirmationsRequired: 1,
    showUnconfirmedTransactions: true,
    hideLowValueTokens: true,
    lowValueThreshold: 1.0
  },
  
  // Trading agent settings
  agent: {
    defaultRiskProfile: 'moderate',
    notifyOnDecisions: true,
    requireConfirmationForTrades: true,
    maxTradeAmount: 1000,
    tradingHoursOnly: true,
    tradingStartHour: 9,
    tradingEndHour: 17,
    enabledDays: [1, 2, 3, 4, 5], // Monday to Friday
    portfolioRebalancingEnabled: true,
    rebalancingFrequency: 'weekly'
  },
  
  // DeFi settings
  defi: {
    enabledPlatforms: ['uniswap', 'sushiswap', 'pancakeswap', 'aave', 'compound'],
    defaultSlippage: 0.5,
    showLiquidityDetails: true,
    autoDetectPlatforms: true,
    showPlatformButton: true
  },
  
  // UI settings
  ui: {
    compactMode: false,
    animationsEnabled: true,
    showAdvancedOptions: false,
    chartTimeframe: '1d',
    chartType: 'candle',
    showPortfolioChart: true,
    dashboardLayout: 'default',
    popupWidth: 400,
    popupHeight: 600
  },
  
  // Network settings
  network: {
    preferredRpcProviders: {
      ethereum: 'infura',
      polygon: 'alchemy',
      bsc: 'bscscan',
      solana: 'solana'
    },
    fallbackProviders: true,
    cacheTimeout: 60000,
    maxRetries: 3,
    retryDelay: 1000
  },
  
  // Advanced settings
  advanced: {
    developerMode: false,
    logLevel: 'error',
    clearCacheOnStartup: false,
    enableDebugCommands: false,
    backgroundServiceWorkerTimeout: 5000,
    useHardwareAcceleration: true,
    experimentalFeatures: false
  }
};

/**
 * Gets the entire configuration
 * @returns {Promise<Object>} Current configuration
 */
async function getConfig() {
  try {
    return await new Promise((resolve) => {
      chrome.storage.local.get('cryptovoice_config', (result) => {
        // Merge with default config to ensure all properties exist
        const storedConfig = result.cryptovoice_config || {};
        const mergedConfig = mergeConfigs(DefaultConfig, storedConfig);
        resolve(mergedConfig);
      });
    });
  } catch (error) {
    console.error('Error getting config:', error);
    return { ...DefaultConfig };
  }
}

/**
 * Gets a specific configuration section
 * @param {string} section - Configuration section name
 * @returns {Promise<Object>} Configuration section
 */
async function getConfigSection(section) {
  try {
    const config = await getConfig();
    return config[section] || {};
  } catch (error) {
    console.error(`Error getting config section ${section}:`, error);
    return DefaultConfig[section] || {};
  }
}

/**
 * Gets a specific configuration value
 * @param {string} section - Configuration section name
 * @param {string} key - Configuration key
 * @returns {Promise<any>} Configuration value
 */
async function getConfigValue(section, key) {
  try {
    const sectionConfig = await getConfigSection(section);
    return sectionConfig[key];
  } catch (error) {
    console.error(`Error getting config value ${section}.${key}:`, error);
    return DefaultConfig[section]?.[key];
  }
}

/**
 * Updates the entire configuration
 * @param {Object} newConfig - New configuration
 * @returns {Promise<boolean>} Success status
 */
async function updateConfig(newConfig) {
  try {
    // Merge with current config
    const currentConfig = await getConfig();
    const mergedConfig = mergeConfigs(currentConfig, newConfig);
    
    // Save config
    await new Promise((resolve, reject) => {
      chrome.storage.local.set({ 'cryptovoice_config': mergedConfig }, () => {
        if (chrome.runtime.lastError) {
          reject(chrome.runtime.lastError);
        } else {
          resolve();
        }
      });
    });
    
    // Notify about config change
    notifyConfigChanged(mergedConfig);
    
    return true;
  } catch (error) {
    console.error('Error updating config:', error);
    return false;
  }
}

/**
 * Updates a specific configuration section
 * @param {string} section - Configuration section name
 * @param {Object} sectionConfig - New section configuration
 * @returns {Promise<boolean>} Success status
 */
async function updateConfigSection(section, sectionConfig) {
  try {
    // Get current config
    const currentConfig = await getConfig();
    
    // Update section
    const updatedConfig = {
      ...currentConfig,
      [section]: {
        ...currentConfig[section],
        ...sectionConfig
      }
    };
    
    // Save config
    await new Promise((resolve, reject) => {
      chrome.storage.local.set({ 'cryptovoice_config': updatedConfig }, () => {
        if (chrome.runtime.lastError) {
          reject(chrome.runtime.lastError);
        } else {
          resolve();
        }
      });
    });
    
    // Notify about config change
    notifyConfigChanged(updatedConfig, section);
    
    return true;
  } catch (error) {
    console.error(`Error updating config section ${section}:`, error);
    return false;
  }
}

/**
 * Updates a specific configuration value
 * @param {string} section - Configuration section name
 * @param {string} key - Configuration key
 * @param {any} value - New value
 * @returns {Promise<boolean>} Success status
 */
async function updateConfigValue(section, key, value) {
  try {
    // Get current config
    const currentConfig = await getConfig();
    
    // Ensure section exists
    if (!currentConfig[section]) {
      currentConfig[section] = {};
    }
    
    // Update value
    const updatedConfig = {
      ...currentConfig,
      [section]: {
        ...currentConfig[section],
        [key]: value
      }
    };
    
    // Save config
    await new Promise((resolve, reject) => {
      chrome.storage.local.set({ 'cryptovoice_config': updatedConfig }, () => {
        if (chrome.runtime.lastError) {
          reject(chrome.runtime.lastError);
        } else {
          resolve();
        }
      });
    });
    
    // Notify about config change
    notifyConfigChanged(updatedConfig, section, key);
    
    return true;
  } catch (error) {
    console.error(`Error updating config value ${section}.${key}:`, error);
    return false;
  }
}

/**
 * Resets the entire configuration to defaults
 * @returns {Promise<boolean>} Success status
 */
async function resetConfigToDefault() {
  try {
    // Save default config
    await new Promise((resolve, reject) => {
      chrome.storage.local.set({ 'cryptovoice_config': { ...DefaultConfig } }, () => {
        if (chrome.runtime.lastError) {
          reject(chrome.runtime.lastError);
        } else {
          resolve();
        }
      });
    });
    
    // Notify about config change
    notifyConfigChanged({ ...DefaultConfig });
    
    return true;
  } catch (error) {
    console.error('Error resetting config to default:', error);
    return false;
  }
}

/**
 * Resets a specific configuration section to defaults
 * @param {string} section - Configuration section name
 * @returns {Promise<boolean>} Success status
 */
async function resetConfigSectionToDefault(section) {
  try {
    // Get current config
    const currentConfig = await getConfig();
    
    // Reset section
    const updatedConfig = {
      ...currentConfig,
      [section]: { ...DefaultConfig[section] }
    };
    
    // Save config
    await new Promise((resolve, reject) => {
      chrome.storage.local.set({ 'cryptovoice_config': updatedConfig }, () => {
        if (chrome.runtime.lastError) {
          reject(chrome.runtime.lastError);
        } else {
          resolve();
        }
      });
    });
    
    // Notify about config change
    notifyConfigChanged(updatedConfig, section);
    
    return true;
  } catch (error) {
    console.error(`Error resetting config section ${section} to default:`, error);
    return false;
  }
}

/**
 * Exports the configuration to a JSON string
 * @returns {Promise<string>} JSON string
 */
async function exportConfig() {
  try {
    const config = await getConfig();
    return JSON.stringify(config, null, 2);
  } catch (error) {
    console.error('Error exporting config:', error);
    return '';
  }
}

/**
 * Imports configuration from a JSON string
 * @param {string} jsonString - JSON string
 * @returns {Promise<boolean>} Success status
 */
async function importConfig(jsonString) {
  try {
    // Parse JSON
    const config = JSON.parse(jsonString);
    
    // Validate config
    if (!isValidConfig(config)) {
      throw new Error('Invalid configuration format');
    }
    
    // Update config
    await updateConfig(config);
    
    return true;
  } catch (error) {
    console.error('Error importing config:', error);
    return false;
  }
}

/**
 * Validates a configuration object
 * @param {Object} config - Configuration to validate
 * @returns {boolean} Whether the configuration is valid
 */
function isValidConfig(config) {
  // Check if config is an object
  if (!config || typeof config !== 'object') {
    return false;
  }
  
  // Check if required sections exist
  const requiredSections = ['general', 'voice', 'wallet', 'agent', 'defi', 'ui', 'network', 'advanced'];
  
  for (const section of requiredSections) {
    if (!config[section] || typeof config[section] !== 'object') {
      return false;
    }
  }
  
  return true;
}

/**
 * Merges two configuration objects
 * @param {Object} baseConfig - Base configuration
 * @param {Object} overrideConfig - Override configuration
 * @returns {Object} Merged configuration
 */
function mergeConfigs(baseConfig, overrideConfig) {
  // Create a deep copy of the base config
  const result = JSON.parse(JSON.stringify(baseConfig));
  
  // Merge override config
  for (const [section, sectionConfig] of Object.entries(overrideConfig)) {
    if (!result[section]) {
      result[section] = {};
    }
    
    if (typeof sectionConfig === 'object' && sectionConfig !== null) {
      for (const [key, value] of Object.entries(sectionConfig)) {
        result[section][key] = value;
      }
    }
  }
  
  return result;
}

/**
 * Notifies about configuration changes
 * @param {Object} config - Updated configuration
 * @param {string} section - Updated section (optional)
 * @param {string} key - Updated key (optional)
 */
function notifyConfigChanged(config, section = null, key = null) {
  // Send message to all extension components
  if (chrome.runtime && chrome.runtime.sendMessage) {
    chrome.runtime.sendMessage({
      action: 'configChanged',
      config,
      section,
      key
    });
  }
  
  // Dispatch event for in-page components
  const event = new CustomEvent('cryptovoice:configChanged', {
    detail: { config, section, key }
  });
  
  window.dispatchEvent(event);
}

/**
 * Listens for configuration changes
 * @param {Function} callback - Callback function
 * @returns {Function} Function to remove the listener
 */
function onConfigChanged(callback) {
  // Create event listener
  const handleEvent = (event) => {
    callback(event.detail.config, event.detail.section, event.detail.key);
  };
  
  // Add event listener
  window.addEventListener('cryptovoice:configChanged', handleEvent);
  
  // Return function to remove listener
  return () => {
    window.removeEventListener('cryptovoice:configChanged', handleEvent);
  };
}

/**
 * Gets the configuration schema
 * @returns {Object} Configuration schema
 */
function getConfigSchema() {
  return {
    general: {
      theme: {
        type: 'string',
        enum: ['light', 'dark', 'system'],
        description: 'UI theme'
      },
      language: {
        type: 'string',
        enum: ['en', 'es', 'fr', 'de', 'ja', 'zh', 'ko', 'ru'],
        description: 'Interface language'
      },
      notificationsEnabled: {
        type: 'boolean',
        description: 'Enable notifications'
      },
      soundEffectsEnabled: {
        type: 'boolean',
        description: 'Enable sound effects'
      },
      autoStartVoiceRecognition: {
        type: 'boolean',
        description: 'Automatically start voice recognition when popup opens'
      },
      showBalancesInHeader: {
        type: 'boolean',
        description: 'Show wallet balances in header'
      },
      defaultCurrency: {
        type: 'string',
        enum: ['USD', 'EUR', 'GBP', 'JPY', 'CNY', 'KRW'],
        description: 'Default currency for displaying values'
      },
      dateFormat: {
        type: 'string',
        enum: ['MM/DD/YYYY', 'DD/MM/YYYY', 'YYYY-MM-DD'],
        description: 'Date format'
      },
      timeFormat: {
        type: 'string',
        enum: ['12h', '24h'],
        description: 'Time format'
      },
      decimalPrecision: {
        type: 'number',
        minimum: 0,
        maximum: 8,
        description: 'Number of decimal places to show'
      }
    },
    voice: {
      wakeWord: {
        type: 'string',
        description: 'Wake word for voice commands'
      },
      recognitionSensitivity: {
        type: 'number',
        minimum: 0,
        maximum: 1,
        description: 'Voice recognition sensitivity'
      },
      voiceResponseEnabled: {
        type: 'boolean',
        description: 'Enable voice responses'
      },
      voiceResponseVolume: {
        type: 'number',
        minimum: 0,
        maximum: 1,
        description: 'Voice response volume'
      },
      voiceResponseSpeed: {
        type: 'number',
        minimum: 0.5,
        maximum: 2,
        description: 'Voice response speed'
      },
      voiceGender: {
        type: 'string',
        enum: ['male', 'female'],
        description: 'Voice gender for responses'
      },
      continuousListening: {
        type: 'boolean',
        description: 'Enable continuous listening mode'
      },
      listeningTimeout: {
        type: 'number',
        minimum: 5000,
        maximum: 60000,
        description: 'Timeout for listening in milliseconds'
      },
      commandConfirmation: {
        type: 'boolean',
        description: 'Confirm commands before execution'
      }
    },
    wallet: {
      defaultNetwork: {
        type: 'string',
        enum: ['ethereum', 'polygon', 'bsc', 'solana'],
        description: 'Default blockchain network'
      },
      autoConnectLastWallet: {
        type: 'boolean',
        description: 'Automatically connect to last used wallet'
      },
      showTestNetworks: {
        type: 'boolean',
        description: 'Show test networks in network selector'
      },
      gasSpeedPreference: {
        type: 'string',
        enum: ['slow', 'medium', 'fast'],
        description: 'Gas speed preference'
      },
      showGasDetails: {
        type: 'boolean',
        description: 'Show gas details in transaction confirmation'
      },
      confirmationsRequired: {
        type: 'number',
        minimum: 1,
        maximum: 12,
        description: 'Number of confirmations required for transaction completion'
      },
      showUnconfirmedTransactions: {
        type: 'boolean',
        description: 'Show unconfirmed transactions in history'
      },
      hideLowValueTokens: {
        type: 'boolean',
        description: 'Hide tokens with low value'
      },
      lowValueThreshold: {
        type: 'number',
        minimum: 0,
        description: 'Threshold for low value tokens in USD'
      }
    },
    agent: {
      defaultRiskProfile: {
        type: 'string',
        enum: ['conservative', 'moderate', 'aggressive'],
        description: 'Default risk profile for trading agent'
      },
      notifyOnDecisions: {
        type: 'boolean',
        description: 'Notify when agent makes decisions'
      },
      requireConfirmationForTrades: {
        type: 'boolean',
        description: 'Require confirmation before executing trades'
      },
      maxTradeAmount: {
        type: 'number',
        minimum: 0,
        description: 'Maximum trade amount in USD'
      },
      tradingHoursOnly: {
        type: 'boolean',
        description: 'Only trade during specified hours'
      },
      tradingStartHour: {
        type: 'number',
        minimum: 0,
        maximum: 23,
        description: 'Trading start hour (24h format)'
      },
      tradingEndHour: {
        type: 'number',
        minimum: 0,
        maximum: 23,
        description: 'Trading end hour (24h format)'
      },
      enabledDays: {
        type: 'array',
        items: {
          type: 'number',
          minimum: 0,
          maximum: 6
        },
        description: 'Enabled trading days (0 = Sunday, 6 = Saturday)'
      },
      portfolioRebalancingEnabled: {
        type: 'boolean',
        description: 'Enable portfolio rebalancing'
      },
      rebalancingFrequency: {
        type: 'string',
        enum: ['daily', 'weekly', 'monthly'],
        description: 'Portfolio rebalancing frequency'
      }
    },
    defi: {
      enabledPlatforms: {
        type: 'array',
        items: {
          type: 'string'
        },
        description: 'Enabled DeFi platforms'
      },
      defaultSlippage: {
        type: 'number',
        minimum: 0,
        maximum: 100,
        description: 'Default slippage tolerance in percentage'
      },
      showLiquidityDetails: {
        type: 'boolean',
        description: 'Show liquidity details in swap interface'
      },
      autoDetectPlatforms: {
        type: 'boolean',
        description: 'Automatically detect DeFi platforms on websites'
      },
      showPlatformButton: {
        type: 'boolean',
        description: 'Show Agentik Wallet button on DeFi platforms'
      }
    },
    ui: {
      compactMode: {
        type: 'boolean',
        description: 'Use compact UI mode'
      },
      animationsEnabled: {
        type: 'boolean',
        description: 'Enable UI animations'
      },
      showAdvancedOptions: {
        type: 'boolean',
        description: 'Show advanced options in UI'
      },
      chartTimeframe: {
        type: 'string',
        enum: ['1h', '1d', '1w', '1m', '1y'],
        description: 'Default chart timeframe'
      },
      chartType: {
        type: 'string',
        enum: ['line', 'candle', 'bar'],
        description: 'Default chart type'
      },
      showPortfolioChart: {
        type: 'boolean',
        description: 'Show portfolio chart in dashboard'
      },
      dashboardLayout: {
        type: 'string',
        enum: ['default', 'compact', 'expanded'],
        description: 'Dashboard layout'
      },
      popupWidth: {
        type: 'number',
        minimum: 300,
        maximum: 800,
        description: 'Popup width in pixels'
      },
      popupHeight: {
        type: 'number',
        minimum: 400,
        maximum: 800,
        description: 'Popup height in pixels'
      }
    },
    network: {
      preferredRpcProviders: {
        type: 'object',
        description: 'Preferred RPC providers for each network'
      },
      fallbackProviders: {
        type: 'boolean',
        description: 'Use fallback providers if preferred provider fails'
      },
      cacheTimeout: {
        type: 'number',
        minimum: 0,
        description: 'Cache timeout in milliseconds'
      },
      maxRetries: {
        type: 'number',
        minimum: 0,
        description: 'Maximum number of retries for failed requests'
      },
      retryDelay: {
        type: 'number',
        minimum: 0,
        description: 'Delay between retries in milliseconds'
      }
    },
    advanced: {
      developerMode: {
        type: 'boolean',
        description: 'Enable developer mode'
      },
      logLevel: {
        type: 'string',
        enum: ['debug', 'info', 'warning', 'error', 'none'],
        description: 'Log level'
      },
      clearCacheOnStartup: {
        type: 'boolean',
        description: 'Clear cache on startup'
      },
      enableDebugCommands: {
        type: 'boolean',
        description: 'Enable debug commands'
      },
      backgroundServiceWorkerTimeout: {
        type: 'number',
        minimum: 0,
        description: 'Background service worker timeout in milliseconds'
      },
      useHardwareAcceleration: {
        type: 'boolean',
        description: 'Use hardware acceleration when available'
      },
      experimentalFeatures: {
        type: 'boolean',
        description: 'Enable experimental features'
      }
    }
  };
}

// Export functions and constants
if (typeof module !== 'undefined' && module.exports) {
  module.exports = {
    DefaultConfig,
    getConfig,
    getConfigSection,
    getConfigValue,
    updateConfig,
    updateConfigSection,
    updateConfigValue,
    resetConfigToDefault,
    resetConfigSectionToDefault,
    exportConfig,
    importConfig,
    isValidConfig,
    mergeConfigs,
    onConfigChanged,
    getConfigSchema
  };
} else {
  // For browser environment
  window.configManagerUtils = {
    DefaultConfig,
    getConfig,
    getConfigSection,
    getConfigValue,
    updateConfig,
    updateConfigSection,
    updateConfigValue,
    resetConfigToDefault,
    resetConfigSectionToDefault,
    exportConfig,
    importConfig,
    isValidConfig,
    mergeConfigs,
    onConfigChanged,
    getConfigSchema
  };
}
