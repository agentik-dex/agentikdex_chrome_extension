/**
 * CryptoVoice - Feature Detection and Browser Compatibility Utilities
 * 
 * This file contains utility functions for detecting browser features
 * and ensuring compatibility across different browsers and environments.
 */

/**
 * Feature categories
 * @enum {string}
 */
const FeatureCategories = {
  AUDIO: 'audio',
  STORAGE: 'storage',
  EXTENSION: 'extension',
  WEB_API: 'web_api',
  CRYPTO: 'crypto',
  PERFORMANCE: 'performance'
};

/**
 * Required features for the extension to function properly
 * @type {Object}
 */
const RequiredFeatures = {
  [FeatureCategories.AUDIO]: [
    'getUserMedia',
    'AudioContext',
    'MediaRecorder'
  ],
  [FeatureCategories.STORAGE]: [
    'localStorage',
    'chrome.storage.local',
    'chrome.storage.sync'
  ],
  [FeatureCategories.EXTENSION]: [
    'chrome.runtime',
    'chrome.tabs',
    'chrome.notifications'
  ],
  [FeatureCategories.WEB_API]: [
    'fetch',
    'Promises',
    'WebSockets'
  ],
  [FeatureCategories.CRYPTO]: [
    'crypto.subtle',
    'randomUUID'
  ],
  [FeatureCategories.PERFORMANCE]: [
    'requestAnimationFrame',
    'performance.now'
  ]
};

/**
 * Optional features that enhance the extension but aren't required
 * @type {Object}
 */
const OptionalFeatures = {
  [FeatureCategories.AUDIO]: [
    'SpeechRecognition',
    'SpeechSynthesis'
  ],
  [FeatureCategories.STORAGE]: [
    'IndexedDB'
  ],
  [FeatureCategories.EXTENSION]: [
    'chrome.declarativeContent',
    'chrome.contextMenus',
    'chrome.devtools'
  ],
  [FeatureCategories.WEB_API]: [
    'WebWorkers',
    'ServiceWorker',
    'SharedWorker',
    'Intl'
  ],
  [FeatureCategories.CRYPTO]: [
    'crypto.randomUUID',
    'crypto.getRandomValues'
  ],
  [FeatureCategories.PERFORMANCE]: [
    'requestIdleCallback',
    'IntersectionObserver',
    'ResizeObserver'
  ]
};

/**
 * Browser detection results
 * @type {Object}
 */
let browserInfo = null;

/**
 * Feature detection results
 * @type {Object}
 */
let featureDetectionResults = null;

/**
 * Detects the current browser
 * @returns {Object} Browser information
 */
function detectBrowser() {
  // Return cached result if available
  if (browserInfo) {
    return { ...browserInfo };
  }
  
  const userAgent = navigator.userAgent;
  const browserData = {
    name: 'unknown',
    version: 'unknown',
    isChrome: false,
    isFirefox: false,
    isEdge: false,
    isSafari: false,
    isOpera: false,
    isMobile: false,
    isDesktop: true,
    isWindows: false,
    isMac: false,
    isLinux: false,
    isIOS: false,
    isAndroid: false
  };
  
  // Detect browser name and version
  if (userAgent.indexOf('Chrome') !== -1 && userAgent.indexOf('Edg') === -1) {
    browserData.name = 'Chrome';
    browserData.isChrome = true;
    const match = userAgent.match(/Chrome\/(\d+\.\d+)/);
    if (match) {
      browserData.version = match[1];
    }
  } else if (userAgent.indexOf('Firefox') !== -1) {
    browserData.name = 'Firefox';
    browserData.isFirefox = true;
    const match = userAgent.match(/Firefox\/(\d+\.\d+)/);
    if (match) {
      browserData.version = match[1];
    }
  } else if (userAgent.indexOf('Edg') !== -1) {
    browserData.name = 'Edge';
    browserData.isEdge = true;
    const match = userAgent.match(/Edg\/(\d+\.\d+)/);
    if (match) {
      browserData.version = match[1];
    }
  } else if (userAgent.indexOf('Safari') !== -1 && userAgent.indexOf('Chrome') === -1) {
    browserData.name = 'Safari';
    browserData.isSafari = true;
    const match = userAgent.match(/Version\/(\d+\.\d+)/);
    if (match) {
      browserData.version = match[1];
    }
  } else if (userAgent.indexOf('OPR') !== -1 || userAgent.indexOf('Opera') !== -1) {
    browserData.name = 'Opera';
    browserData.isOpera = true;
    const match = userAgent.match(/OPR\/(\d+\.\d+)/) || userAgent.match(/Opera\/(\d+\.\d+)/);
    if (match) {
      browserData.version = match[1];
    }
  }
  
  // Detect platform
  if (/Mobi|Android/i.test(userAgent)) {
    browserData.isMobile = true;
    browserData.isDesktop = false;
  }
  
  if (userAgent.indexOf('Windows') !== -1) {
    browserData.isWindows = true;
  } else if (userAgent.indexOf('Macintosh') !== -1) {
    browserData.isMac = true;
  } else if (userAgent.indexOf('Linux') !== -1) {
    browserData.isLinux = true;
  }
  
  if (userAgent.indexOf('iPhone') !== -1 || userAgent.indexOf('iPad') !== -1 || userAgent.indexOf('iPod') !== -1) {
    browserData.isIOS = true;
  } else if (userAgent.indexOf('Android') !== -1) {
    browserData.isAndroid = true;
  }
  
  // Cache result
  browserInfo = { ...browserData };
  
  return browserData;
}

/**
 * Checks if a feature is available
 * @param {string} feature - Feature to check
 * @returns {boolean} Whether the feature is available
 */
function isFeatureAvailable(feature) {
  // Check if feature detection has been run
  if (!featureDetectionResults) {
    detectFeatures();
  }
  
  // Check all categories for the feature
  for (const category of Object.values(FeatureCategories)) {
    if (featureDetectionResults[category] && 
        featureDetectionResults[category][feature] !== undefined) {
      return featureDetectionResults[category][feature];
    }
  }
  
  // Feature not found in detection results, perform direct check
  return checkFeature(feature);
}

/**
 * Checks if a specific feature is available
 * @param {string} feature - Feature to check
 * @returns {boolean} Whether the feature is available
 */
function checkFeature(feature) {
  try {
    switch (feature) {
      // Audio features
      case 'getUserMedia':
        return !!(navigator.mediaDevices && navigator.mediaDevices.getUserMedia);
      case 'AudioContext':
        return !!(window.AudioContext || window.webkitAudioContext);
      case 'MediaRecorder':
        return !!window.MediaRecorder;
      case 'SpeechRecognition':
        return !!(window.SpeechRecognition || window.webkitSpeechRecognition);
      case 'SpeechSynthesis':
        return !!window.speechSynthesis;
        
      // Storage features
      case 'localStorage':
        return !!window.localStorage;
      case 'chrome.storage.local':
        return !!(chrome && chrome.storage && chrome.storage.local);
      case 'chrome.storage.sync':
        return !!(chrome && chrome.storage && chrome.storage.sync);
      case 'IndexedDB':
        return !!window.indexedDB;
        
      // Extension features
      case 'chrome.runtime':
        return !!(chrome && chrome.runtime);
      case 'chrome.tabs':
        return !!(chrome && chrome.tabs);
      case 'chrome.notifications':
        return !!(chrome && chrome.notifications);
      case 'chrome.declarativeContent':
        return !!(chrome && chrome.declarativeContent);
      case 'chrome.contextMenus':
        return !!(chrome && chrome.contextMenus);
      case 'chrome.devtools':
        return !!(chrome && chrome.devtools);
        
      // Web API features
      case 'fetch':
        return !!window.fetch;
      case 'Promises':
        return !!window.Promise;
      case 'WebSockets':
        return !!window.WebSocket;
      case 'WebWorkers':
        return !!window.Worker;
      case 'ServiceWorker':
        return !!(navigator.serviceWorker);
      case 'SharedWorker':
        return !!window.SharedWorker;
      case 'Intl':
        return !!window.Intl;
        
      // Crypto features
      case 'crypto.subtle':
        return !!(window.crypto && window.crypto.subtle);
      case 'crypto.randomUUID':
        return !!(window.crypto && typeof window.crypto.randomUUID === 'function');
      case 'crypto.getRandomValues':
        return !!(window.crypto && typeof window.crypto.getRandomValues === 'function');
      case 'randomUUID':
        return typeof window.crypto?.randomUUID === 'function';
        
      // Performance features
      case 'requestAnimationFrame':
        return !!window.requestAnimationFrame;
      case 'performance.now':
        return !!(window.performance && typeof window.performance.now === 'function');
      case 'requestIdleCallback':
        return !!window.requestIdleCallback;
      case 'IntersectionObserver':
        return !!window.IntersectionObserver;
      case 'ResizeObserver':
        return !!window.ResizeObserver;
        
      default:
        return false;
    }
  } catch (error) {
    console.error(`Error checking feature ${feature}:`, error);
    return false;
  }
}

/**
 * Detects all features
 * @returns {Object} Feature detection results
 */
function detectFeatures() {
  // Return cached result if available
  if (featureDetectionResults) {
    return { ...featureDetectionResults };
  }
  
  const results = {};
  
  // Check all required features
  for (const [category, features] of Object.entries(RequiredFeatures)) {
    results[category] = results[category] || {};
    
    for (const feature of features) {
      results[category][feature] = checkFeature(feature);
    }
  }
  
  // Check all optional features
  for (const [category, features] of Object.entries(OptionalFeatures)) {
    results[category] = results[category] || {};
    
    for (const feature of features) {
      results[category][feature] = checkFeature(feature);
    }
  }
  
  // Cache result
  featureDetectionResults = { ...results };
  
  return results;
}

/**
 * Gets missing required features
 * @returns {Object} Missing required features by category
 */
function getMissingRequiredFeatures() {
  // Ensure feature detection has been run
  if (!featureDetectionResults) {
    detectFeatures();
  }
  
  const missingFeatures = {};
  
  // Check all required features
  for (const [category, features] of Object.entries(RequiredFeatures)) {
    const missing = features.filter(feature => !featureDetectionResults[category][feature]);
    
    if (missing.length > 0) {
      missingFeatures[category] = missing;
    }
  }
  
  return missingFeatures;
}

/**
 * Checks if the browser is compatible with the extension
 * @returns {Object} Compatibility check result
 */
function checkBrowserCompatibility() {
  const browser = detectBrowser();
  const missingFeatures = getMissingRequiredFeatures();
  
  const isCompatible = Object.keys(missingFeatures).length === 0;
  
  return {
    browser,
    isCompatible,
    missingFeatures,
    featureDetectionResults: { ...featureDetectionResults }
  };
}

/**
 * Provides fallbacks for missing features
 * @returns {Object} Fallback implementations
 */
function provideFallbacks() {
  const fallbacks = {};
  
  // AudioContext fallback
  if (!window.AudioContext && window.webkitAudioContext) {
    window.AudioContext = window.webkitAudioContext;
    fallbacks.AudioContext = 'Used webkitAudioContext';
  }
  
  // SpeechRecognition fallback
  if (!window.SpeechRecognition && window.webkitSpeechRecognition) {
    window.SpeechRecognition = window.webkitSpeechRecognition;
    fallbacks.SpeechRecognition = 'Used webkitSpeechRecognition';
  }
  
  // requestIdleCallback fallback
  if (!window.requestIdleCallback) {
    window.requestIdleCallback = function(callback, options) {
      const start = Date.now();
      return setTimeout(function() {
        callback({
          didTimeout: false,
          timeRemaining: function() {
            return Math.max(0, 50 - (Date.now() - start));
          }
        });
      }, options && options.timeout ? options.timeout : 1);
    };
    fallbacks.requestIdleCallback = 'Implemented using setTimeout';
  }
  
  // crypto.randomUUID fallback
  if (window.crypto && !window.crypto.randomUUID && window.crypto.getRandomValues) {
    window.crypto.randomUUID = function() {
      // Simple UUID v4 implementation
      const rnds = new Uint8Array(16);
      window.crypto.getRandomValues(rnds);
      rnds[6] = (rnds[6] & 0x0f) | 0x40; // Version 4
      rnds[8] = (rnds[8] & 0x3f) | 0x80; // Variant 10
      
      const hexBytes = [];
      for (let i = 0; i < 16; i++) {
        hexBytes.push(rnds[i].toString(16).padStart(2, '0'));
      }
      
      return [
        hexBytes.slice(0, 4).join(''),
        hexBytes.slice(4, 6).join(''),
        hexBytes.slice(6, 8).join(''),
        hexBytes.slice(8, 10).join(''),
        hexBytes.slice(10, 16).join('')
      ].join('-');
    };
    fallbacks['crypto.randomUUID'] = 'Implemented using crypto.getRandomValues';
  }
  
  return fallbacks;
}

/**
 * Gets the appropriate audio context for the current browser
 * @returns {AudioContext} Audio context
 */
function getAudioContext() {
  const AudioContextClass = window.AudioContext || window.webkitAudioContext;
  return new AudioContextClass();
}

/**
 * Gets the appropriate speech recognition for the current browser
 * @returns {SpeechRecognition} Speech recognition
 */
function getSpeechRecognition() {
  const SpeechRecognitionClass = window.SpeechRecognition || window.webkitSpeechRecognition;
  return SpeechRecognitionClass ? new SpeechRecognitionClass() : null;
}

/**
 * Checks if the browser supports a specific codec
 * @param {string} codec - Codec to check
 * @returns {Promise<boolean>} Whether the codec is supported
 */
async function isCodecSupported(codec) {
  try {
    // Get audio context
    const audioContext = getAudioContext();
    
    // Check if createMediaStreamSource is available
    if (!audioContext.createMediaStreamSource) {
      return false;
    }
    
    // Create media recorder with codec
    const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
    const options = { mimeType: codec };
    
    try {
      // Check if MediaRecorder supports the codec
      return MediaRecorder.isTypeSupported(codec);
    } catch (error) {
      return false;
    } finally {
      // Stop all tracks
      stream.getTracks().forEach(track => track.stop());
      
      // Close audio context
      if (audioContext.state !== 'closed') {
        await audioContext.close();
      }
    }
  } catch (error) {
    console.error(`Error checking codec support for ${codec}:`, error);
    return false;
  }
}

/**
 * Gets supported audio codecs
 * @returns {Promise<Object>} Supported codecs
 */
async function getSupportedAudioCodecs() {
  const codecs = {
    'audio/webm': await isCodecSupported('audio/webm'),
    'audio/webm;codecs=opus': await isCodecSupported('audio/webm;codecs=opus'),
    'audio/ogg': await isCodecSupported('audio/ogg'),
    'audio/ogg;codecs=opus': await isCodecSupported('audio/ogg;codecs=opus'),
    'audio/mp4': await isCodecSupported('audio/mp4'),
    'audio/mp3': await isCodecSupported('audio/mp3'),
    'audio/wav': await isCodecSupported('audio/wav')
  };
  
  return codecs;
}

/**
 * Gets the best supported audio codec
 * @returns {Promise<string>} Best supported codec
 */
async function getBestAudioCodec() {
  const codecs = await getSupportedAudioCodecs();
  
  // Preferred order
  const preferredCodecs = [
    'audio/webm;codecs=opus',
    'audio/ogg;codecs=opus',
    'audio/webm',
    'audio/ogg',
    'audio/mp4',
    'audio/mp3',
    'audio/wav'
  ];
  
  // Find first supported codec in preferred order
  for (const codec of preferredCodecs) {
    if (codecs[codec]) {
      return codec;
    }
  }
  
  // Fallback to any supported codec
  for (const [codec, supported] of Object.entries(codecs)) {
    if (supported) {
      return codec;
    }
  }
  
  return null;
}

/**
 * Checks if the browser is running in an extension context
 * @returns {boolean} Whether running in an extension context
 */
function isExtensionContext() {
  return !!(chrome && chrome.runtime && chrome.runtime.id);
}

/**
 * Checks if the browser is running in a content script context
 * @returns {boolean} Whether running in a content script context
 */
function isContentScriptContext() {
  return isExtensionContext() && !chrome.windows;
}

/**
 * Checks if the browser is running in a background script context
 * @returns {boolean} Whether running in a background script context
 */
function isBackgroundContext() {
  return isExtensionContext() && !!chrome.windows;
}

/**
 * Checks if the browser is running in a popup context
 * @returns {boolean} Whether running in a popup context
 */
function isPopupContext() {
  return isExtensionContext() && window.location.pathname.endsWith('popup.html');
}

/**
 * Initializes feature detection and provides fallbacks
 * @returns {Promise<Object>} Initialization result
 */
async function initFeatureDetection() {
  try {
    // Detect browser
    const browser = detectBrowser();
    
    // Detect features
    const features = detectFeatures();
    
    // Provide fallbacks
    const fallbacks = provideFallbacks();
    
    // Check compatibility
    const compatibility = checkBrowserCompatibility();
    
    // Get supported audio codecs
    const audioCodecs = await getSupportedAudioCodecs();
    
    return {
      browser,
      features,
      fallbacks,
      compatibility,
      audioCodecs
    };
  } catch (error) {
    console.error('Error initializing feature detection:', error);
    return {
      error: error.message
    };
  }
}

// Export functions and constants
if (typeof module !== 'undefined' && module.exports) {
  module.exports = {
    FeatureCategories,
    RequiredFeatures,
    OptionalFeatures,
    detectBrowser,
    isFeatureAvailable,
    detectFeatures,
    getMissingRequiredFeatures,
    checkBrowserCompatibility,
    provideFallbacks,
    getAudioContext,
    getSpeechRecognition,
    isCodecSupported,
    getSupportedAudioCodecs,
    getBestAudioCodec,
    isExtensionContext,
    isContentScriptContext,
    isBackgroundContext,
    isPopupContext,
    initFeatureDetection
  };
} else {
  // For browser environment
  window.featureDetectionUtils = {
    FeatureCategories,
    RequiredFeatures,
    OptionalFeatures,
    detectBrowser,
    isFeatureAvailable,
    detectFeatures,
    getMissingRequiredFeatures,
    checkBrowserCompatibility,
    provideFallbacks,
    getAudioContext,
    getSpeechRecognition,
    isCodecSupported,
    getSupportedAudioCodecs,
    getBestAudioCodec,
    isExtensionContext,
    isContentScriptContext,
    isBackgroundContext,
    isPopupContext,
    initFeatureDetection
  };
}
