/**
 * CryptoVoice - Type Definitions
 * 
 * This file contains TypeScript-like type definitions for the CryptoVoice extension.
 * Since Chrome extensions typically use JavaScript, these are provided as JSDoc comments.
 */

/**
 * @typedef {Object} WalletState
 * @property {boolean} connected - Whether the wallet is connected
 * @property {string|null} address - The wallet address
 * @property {string|null} network - The blockchain network (e.g., 'ethereum', 'solana')
 * @property {Object.<string, number>} balances - Token balances keyed by symbol
 * @property {Transaction[]} transactions - Array of transactions
 */

/**
 * @typedef {Object} Transaction
 * @property {string} type - Transaction type ('Send', 'Receive', 'Swap')
 * @property {string} token - Token symbol or symbols involved
 * @property {number} amount - Amount of tokens
 * @property {string} address - Recipient/sender address
 * @property {string} date - Transaction date
 * @property {string} status - Transaction status
 * @property {string} hash - Transaction hash
 */

/**
 * @typedef {Object} AgentState
 * @property {boolean} active - Whether the trading agent is active
 * @property {'conservative'|'moderate'|'aggressive'} riskProfile - Risk tolerance level
 * @property {number} dailyLimit - Daily trading limit in USD
 * @property {number} targetReturn - Target monthly return percentage
 * @property {string[]} allowedAssets - Array of allowed asset symbols
 * @property {AgentDecision|null} lastDecision - The last trading decision made
 * @property {AgentPerformance} performance - Performance metrics
 */

/**
 * @typedef {Object} AgentDecision
 * @property {'buy'|'sell'|'hold'|'swap'} action - The trading action
 * @property {string} asset - Asset symbol
 * @property {number} amount - Amount to trade
 * @property {string} reasoning - Reasoning behind the decision
 * @property {number} confidence - Confidence level (0-1)
 * @property {number} riskScore - Risk score (0-1)
 */

/**
 * @typedef {Object} AgentPerformance
 * @property {number} dailyProfit - Profit/loss for the day in USD
 * @property {number} weeklyProfit - Profit/loss for the week in USD
 * @property {number} monthlyProfit - Profit/loss for the month in USD
 * @property {number} activePositions - Number of active positions
 */

/**
 * @typedef {Object} RiskProfile
 * @property {'conservative'|'moderate'|'aggressive'} tolerance - Risk tolerance level
 * @property {number} maxDailyLoss - Maximum allowed daily loss in USD
 * @property {number} maxPositionSize - Maximum position size as percentage of portfolio
 * @property {string[]} allowedAssets - Array of allowed asset symbols
 * @property {string[]} restrictions - Array of trading restrictions
 */

/**
 * @typedef {Object} VoiceCommand
 * @property {string} raw - The raw voice command text
 * @property {string} intent - The detected intent
 * @property {Object.<string, any>} entities - Extracted entities
 * @property {number} confidence - Confidence level (0-1)
 */

/**
 * @typedef {Object} TokenInfo
 * @property {string} symbol - Token symbol
 * @property {string} name - Token name
 * @property {number} amount - Token amount
 * @property {number} value - Token value in USD
 * @property {string} [icon] - Path to token icon
 */

// Export as module (for environments that support it)
if (typeof module !== 'undefined' && module.exports) {
  module.exports = {
    // These exports don't actually contain anything since the types
    // are just JSDoc comments, but they're included for documentation
    WalletState: {},
    Transaction: {},
    AgentState: {},
    AgentDecision: {},
    AgentPerformance: {},
    RiskProfile: {},
    VoiceCommand: {},
    TokenInfo: {}
  };
}
