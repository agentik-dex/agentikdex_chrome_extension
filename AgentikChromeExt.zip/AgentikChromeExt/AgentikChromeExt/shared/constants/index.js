/**
 * CryptoVoice - Constants
 * 
 * This file contains constants used throughout the CryptoVoice extension.
 */

// Wake word for voice commands
const WAKE_WORD = "hey cryptovoice";

// API endpoints for blockchain and price data
const API_ENDPOINTS = {
  PRICE_DATA: "https://api.coingecko.com/api/v3",
  ETHEREUM: "https://api.etherscan.io/api",
  SOLANA: "https://api.solscan.io/api",
  POLYGON: "https://api.polygonscan.com/api",
  BINANCE: "https://api.bscscan.com/api",
  ARBITRUM: "https://api.arbiscan.io/api"
};

// Supported blockchain networks
const SUPPORTED_NETWORKS = [
  {
    id: "ethereum",
    name: "Ethereum",
    symbol: "ETH",
    icon: "../assets/icons/eth.png",
    explorer: "https://etherscan.io"
  },
  {
    id: "solana",
    name: "Solana",
    symbol: "SOL",
    icon: "../assets/icons/sol.png",
    explorer: "https://solscan.io"
  },
  {
    id: "polygon",
    name: "Polygon",
    symbol: "MATIC",
    icon: "../assets/icons/matic.png",
    explorer: "https://polygonscan.com"
  },
  {
    id: "binance",
    name: "Binance Smart Chain",
    symbol: "BNB",
    icon: "../assets/icons/bnb.png",
    explorer: "https://bscscan.com"
  },
  {
    id: "arbitrum",
    name: "Arbitrum",
    symbol: "ETH",
    icon: "../assets/icons/arbitrum.png",
    explorer: "https://arbiscan.io"
  }
];

// Supported DeFi protocols
const SUPPORTED_PROTOCOLS = [
  {
    id: "uniswap",
    name: "Uniswap",
    type: "dex",
    networks: ["ethereum", "polygon", "arbitrum"],
    url: "https://app.uniswap.org"
  },
  {
    id: "sushiswap",
    name: "SushiSwap",
    type: "dex",
    networks: ["ethereum", "polygon", "arbitrum", "binance"],
    url: "https://app.sushi.com"
  },
  {
    id: "pancakeswap",
    name: "PancakeSwap",
    type: "dex",
    networks: ["binance"],
    url: "https://pancakeswap.finance"
  },
  {
    id: "raydium",
    name: "Raydium",
    type: "dex",
    networks: ["solana"],
    url: "https://raydium.io"
  },
  {
    id: "aave",
    name: "Aave",
    type: "lending",
    networks: ["ethereum", "polygon", "arbitrum"],
    url: "https://app.aave.com"
  },
  {
    id: "compound",
    name: "Compound",
    type: "lending",
    networks: ["ethereum"],
    url: "https://app.compound.finance"
  }
];

// Risk profiles
const RISK_PROFILES = {
  CONSERVATIVE: {
    id: "conservative",
    name: "Conservative",
    description: "Low risk, stable returns",
    maxDailyLoss: 1, // 1% of portfolio
    maxPositionSize: 5, // 5% of portfolio per position
    tradingFrequency: "low"
  },
  MODERATE: {
    id: "moderate",
    name: "Moderate",
    description: "Balanced risk and return",
    maxDailyLoss: 3, // 3% of portfolio
    maxPositionSize: 10, // 10% of portfolio per position
    tradingFrequency: "medium"
  },
  AGGRESSIVE: {
    id: "aggressive",
    name: "Aggressive",
    description: "Higher risk, higher potential returns",
    maxDailyLoss: 7, // 7% of portfolio
    maxPositionSize: 20, // 20% of portfolio per position
    tradingFrequency: "high"
  }
};

// Voice command patterns
const COMMAND_PATTERNS = {
  BALANCE: [
    "what is my {token} balance",
    "how much {token} do i have",
    "check my {token} balance",
    "show me my balance",
    "what's my wallet worth"
  ],
  SEND: [
    "send {amount} {token} to {recipient}",
    "transfer {amount} {token} to {recipient}",
    "pay {recipient} {amount} {token}"
  ],
  SWAP: [
    "swap {amount} {fromToken} to {toToken}",
    "exchange {amount} {fromToken} for {toToken}",
    "convert {amount} {fromToken} to {toToken}"
  ],
  HISTORY: [
    "show my transactions",
    "show my {token} transactions",
    "what did I buy {period}",
    "show transaction history"
  ],
  AGENT_SETUP: [
    "create my trading agent",
    "set up autonomous trading",
    "configure my agent"
  ],
  AGENT_CONFIG: [
    "set risk level to {riskLevel}",
    "target {percent}% monthly returns",
    "set daily limit to {amount}"
  ],
  AGENT_CONTROL: [
    "pause my agent",
    "resume trading",
    "stop all operations",
    "start trading again"
  ],
  AGENT_STATUS: [
    "how is my agent performing",
    "show trading results",
    "what's my agent's status"
  ]
};

// Storage keys
const STORAGE_KEYS = {
  WALLET_STATE: "walletState",
  AGENT_STATE: "agentState",
  USER_PREFERENCES: "userPreferences",
  VOICE_PROFILE: "voiceProfile"
};

// Export constants
if (typeof module !== 'undefined' && module.exports) {
  module.exports = {
    WAKE_WORD,
    API_ENDPOINTS,
    SUPPORTED_NETWORKS,
    SUPPORTED_PROTOCOLS,
    RISK_PROFILES,
    COMMAND_PATTERNS,
    STORAGE_KEYS
  };
} else {
  // For browser environment
  window.CONSTANTS = {
    WAKE_WORD,
    API_ENDPOINTS,
    SUPPORTED_NETWORKS,
    SUPPORTED_PROTOCOLS,
    RISK_PROFILES,
    COMMAND_PATTERNS,
    STORAGE_KEYS
  };
}
