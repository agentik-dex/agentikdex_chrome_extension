# CryptoVoice - Voice-Activated Crypto Wallet Chrome Extension

CryptoVoice is a Chrome extension that enables users to perform cryptocurrency operations through voice commands using an agentic framework. Similar to Phantom Wallet but with advanced speech-to-action capabilities and autonomous trading features.

## Features

### Voice-Activated Wallet Operations
- **Balance Checking**: "Hey, what is my wallet balance?"
- **Fund Transfers**: "Send 0.5 ETH to [address/contact name]"
- **Token Swaps**: "Swap 100 USDC to Bitcoin"
- **Transaction History**: "Show my recent transactions"
- **Portfolio Overview**: "What's my portfolio worth?"

### Autonomous Trading Agent
- **24/7 Investment Agent**: Dedicated AI agent for continuous market monitoring
- **Risk Profiling**: User-defined risk tolerance (Conservative, Moderate, Aggressive)
- **Profit Preferences**: Target returns, stop-loss settings, take-profit levels
- **Asset Class Diversification**: Automated investment across different crypto categories
- **Market Analysis**: Real-time market sentiment and technical analysis

### Security & Authentication
- **Biometric Authentication**: Voice recognition for security
- **Multi-layer Security**: Hardware wallet integration, secure enclave storage
- **Permission Management**: Granular control over agent actions
- **Transaction Limits**: Daily/weekly spending limits for autonomous operations

## Installation

1. Clone this repository:
```
git clone https://github.com/yourusername/cryptovoice.git
```

2. Open Chrome and navigate to `chrome://extensions/`

3. Enable "Developer mode" in the top-right corner

4. Click "Load unpacked" and select the CryptoVoice directory

5. The extension should now be installed and visible in your Chrome toolbar

## Usage

1. Click the CryptoVoice icon in your Chrome toolbar to open the wallet interface

2. For voice commands, click the microphone button and speak after the prompt

3. Configure your trading agent by clicking the "Configure" button in the Agent section

4. Use voice commands to check balances, send funds, swap tokens, and manage your portfolio

## Development

### Project Structure
```
src/
├── popup/                  # Extension popup UI
│   ├── components/
│   ├── hooks/
│   └── popup.tsx
├── content/               # Content scripts for web3 integration
├── background/            # Service worker for background operations
└── shared/               # Shared utilities and types
```

### Setup for Development

1. Install dependencies:
```
npm install
```

2. Build the extension:
```
npm run build
```

3. Load the extension in Chrome as described in the Installation section

## Security Considerations

- Private keys are never stored in plain text
- All sensitive operations require explicit user confirmation
- The autonomous agent has configurable spending limits and restrictions
- Voice authentication adds an additional layer of security

## License

MIT License

## Disclaimer

This is a demonstration project and should not be used for managing real cryptocurrency assets without thorough security auditing. The autonomous trading features are simulated and not intended for actual trading without proper risk assessment.
