// CryptoVoice - Background Service Worker
// Handles voice processing, wallet management, and the autonomous trading agent

// Constants
const WAKE_WORD = "hey cryptovoice";
const API_ENDPOINTS = {
  PRICE_DATA: "https://api.coingecko.com/api/v3",
  ETHEREUM: "https://api.etherscan.io/api",
  SOLANA: "https://api.solscan.io/api",
  POLYGON: "https://api.polygonscan.com/api",
  BINANCE: "https://api.bscscan.com/api",
  ARBITRUM: "https://api.arbiscan.io/api"
};

// State management
let walletState = {
  connected: false,
  address: null,
  network: null,
  balances: {},
  transactions: []
};

let agentState = {
  active: false,
  riskProfile: 'moderate',
  dailyLimit: 100,
  targetReturn: 5,
  allowedAssets: ['ETH', 'BTC', 'USDC', 'SOL'],
  lastDecision: null,
  performance: {
    dailyProfit: 0,
    weeklyProfit: 0,
    monthlyProfit: 0,
    activePositions: 0
  }
};

// Initialize the extension
chrome.runtime.onInstalled.addListener(() => {
  console.log("CryptoVoice extension installed");
  
  // Initialize storage with default values
  chrome.storage.local.set({
    walletState: walletState,
    agentState: agentState,
    userPreferences: {
      voiceAuthentication: false,
      biometricEnabled: false,
      transactionLimits: {
        daily: 1000,
        weekly: 5000
      },
      notifications: true
    }
  });
});

// Message handling from popup and content scripts
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  console.log("Message received in background:", message);
  
  switch (message.action) {
    case "processVoiceCommand":
      processVoiceCommand(message.command)
        .then(result => sendResponse({ success: true, result }))
        .catch(error => sendResponse({ success: false, error: error.message }));
      return true; // Indicates async response
      
    case "getWalletState":
      sendResponse({ walletState });
      break;
      
    case "getAgentState":
      sendResponse({ agentState });
      break;
      
    case "updateWalletState":
      walletState = { ...walletState, ...message.data };
      chrome.storage.local.set({ walletState });
      sendResponse({ success: true });
      break;
      
    case "updateAgentState":
      agentState = { ...agentState, ...message.data };
      chrome.storage.local.set({ agentState });
      sendResponse({ success: true });
      break;
      
    case "executeTransaction":
      executeTransaction(message.transaction)
        .then(result => sendResponse({ success: true, result }))
        .catch(error => sendResponse({ success: false, error: error.message }));
      return true; // Indicates async response
      
    case "toggleAgent":
      toggleTradingAgent(message.active, message.config)
        .then(result => sendResponse({ success: true, result }))
        .catch(error => sendResponse({ success: false, error: error.message }));
      return true; // Indicates async response
  }
});

// Voice command processing
async function processVoiceCommand(command) {
  console.log("Processing voice command:", command);
  
  // Convert command to lowercase for easier matching
  const lowerCommand = command.toLowerCase();
  
  // Check for wake word
  if (!lowerCommand.includes(WAKE_WORD) && !lowerCommand.startsWith("hey") && !lowerCommand.startsWith("what")) {
    return { type: "error", message: "Wake word not detected" };
  }
  
  // Process balance inquiries
  if (lowerCommand.includes("balance") || lowerCommand.includes("how much") || 
      (lowerCommand.includes("what") && lowerCommand.includes("worth"))) {
    return await getBalanceInfo(lowerCommand);
  }
  
  // Process send/transfer commands
  if (lowerCommand.includes("send") || lowerCommand.includes("transfer")) {
    return parseSendCommand(lowerCommand);
  }
  
  // Process swap/exchange commands
  if (lowerCommand.includes("swap") || lowerCommand.includes("exchange")) {
    return parseSwapCommand(lowerCommand);
  }
  
  // Process transaction history requests
  if (lowerCommand.includes("history") || lowerCommand.includes("transactions") || 
      lowerCommand.includes("recent") || lowerCommand.includes("activity")) {
    return await getTransactionHistory();
  }
  
  // Process agent-related commands
  if (lowerCommand.includes("agent") || lowerCommand.includes("trading")) {
    return processAgentCommand(lowerCommand);
  }
  
  // Default response for unrecognized commands
  return { 
    type: "unknown", 
    message: "I didn't understand that command. Try asking about your balance, sending funds, or checking transaction history." 
  };
}

// Balance information
async function getBalanceInfo(command) {
  // In a real implementation, this would connect to actual blockchain APIs
  // For demo purposes, we'll return mock data
  
  // Check if a specific token was requested
  const tokens = ['ethereum', 'eth', 'bitcoin', 'btc', 'usdc', 'solana', 'sol'];
  const requestedToken = tokens.find(token => command.includes(token));
  
  if (requestedToken) {
    // Return info for specific token
    const tokenInfo = getMockTokenInfo(requestedToken);
    return {
      type: "balance",
      token: tokenInfo.symbol,
      amount: tokenInfo.amount,
      value: tokenInfo.value,
      message: `You have ${tokenInfo.amount} ${tokenInfo.symbol} worth $${tokenInfo.value.toFixed(2)}`
    };
  } else {
    // Return total portfolio value
    const mockTokens = [
      getMockTokenInfo('eth'),
      getMockTokenInfo('btc'),
      getMockTokenInfo('usdc'),
      getMockTokenInfo('sol')
    ];
    
    const totalValue = mockTokens.reduce((sum, token) => sum + token.value, 0);
    
    return {
      type: "portfolio",
      tokens: mockTokens,
      totalValue: totalValue,
      message: `Your portfolio is worth $${totalValue.toFixed(2)}`
    };
  }
}

// Helper function for mock token data
function getMockTokenInfo(tokenName) {
  const lowerToken = tokenName.toLowerCase();
  
  if (lowerToken === 'ethereum' || lowerToken === 'eth') {
    return { symbol: 'ETH', name: 'Ethereum', amount: 1.25, value: 2500.00 };
  } else if (lowerToken === 'bitcoin' || lowerToken === 'btc') {
    return { symbol: 'BTC', name: 'Bitcoin', amount: 0.05, value: 3000.00 };
  } else if (lowerToken === 'usdc') {
    return { symbol: 'USDC', name: 'USD Coin', amount: 1000, value: 1000.00 };
  } else if (lowerToken === 'solana' || lowerToken === 'sol') {
    return { symbol: 'SOL', name: 'Solana', amount: 20, value: 500.00 };
  }
  
  // Default fallback
  return { symbol: 'ETH', name: 'Ethereum', amount: 1.25, value: 2500.00 };
}

// Parse send command
function parseSendCommand(command) {
  // Example: "Send 0.5 ETH to 0x1234..."
  const amountMatch = command.match(/(\d+(\.\d+)?)\s*([a-zA-Z]+)/);
  const addressMatch = command.match(/to\s+(0x[a-fA-F0-9]{40}|[a-zA-Z0-9]+)/);
  
  if (!amountMatch) {
    return { 
      type: "error", 
      message: "Could not determine the amount to send. Please specify an amount like '0.5 ETH'." 
    };
  }
  
  if (!addressMatch) {
    return { 
      type: "error", 
      message: "Could not determine the recipient address. Please specify an address or contact name." 
    };
  }
  
  const amount = parseFloat(amountMatch[1]);
  const token = amountMatch[3].toUpperCase();
  const recipient = addressMatch[1];
  
  return {
    type: "send",
    amount: amount,
    token: token,
    recipient: recipient,
    message: `Preparing to send ${amount} ${token} to ${recipient}`
  };
}

// Parse swap command
function parseSwapCommand(command) {
  // Example: "Swap 100 USDC to Bitcoin"
  const fromMatch = command.match(/(\d+(\.\d+)?)\s*([a-zA-Z]+)/);
  const toMatch = command.match(/to\s+([a-zA-Z]+)/);
  
  if (!fromMatch) {
    return { 
      type: "error", 
      message: "Could not determine the amount to swap. Please specify an amount like '100 USDC'." 
    };
  }
  
  if (!toMatch) {
    return { 
      type: "error", 
      message: "Could not determine the token to swap to. Please specify a token like 'to Bitcoin'." 
    };
  }
  
  const amount = parseFloat(fromMatch[1]);
  const fromToken = fromMatch[3].toUpperCase();
  const toToken = mapTokenName(toMatch[1]);
  
  return {
    type: "swap",
    amount: amount,
    fromToken: fromToken,
    toToken: toToken,
    message: `Preparing to swap ${amount} ${fromToken} to ${toToken}`
  };
}

// Helper function to map token names
function mapTokenName(name) {
  const lowerName = name.toLowerCase();
  
  if (lowerName.includes('ethereum') || lowerName.includes('ether')) {
    return 'ETH';
  } else if (lowerName.includes('bitcoin')) {
    return 'BTC';
  } else if (lowerName.includes('solana')) {
    return 'SOL';
  } else if (lowerName.includes('usd') && lowerName.includes('coin')) {
    return 'USDC';
  }
  
  // Return the original name capitalized if no match
  return name.toUpperCase();
}

// Get transaction history
async function getTransactionHistory() {
  // In a real implementation, this would fetch from blockchain APIs
  // For demo purposes, we'll return mock data
  
  const mockTransactions = [
    { 
      type: 'Send', 
      token: 'ETH', 
      amount: 0.5, 
      address: '0x1234...5678', 
      date: '2023-06-01', 
      status: 'Completed',
      hash: '0xabcd1234...'
    },
    { 
      type: 'Receive', 
      token: 'BTC', 
      amount: 0.01, 
      address: '0xabcd...efgh', 
      date: '2023-05-28', 
      status: 'Completed',
      hash: '0x1234abcd...'
    },
    { 
      type: 'Swap', 
      token: 'USDC → SOL', 
      amount: 100, 
      address: '-', 
      date: '2023-05-25', 
      status: 'Completed',
      hash: '0xef56789...'
    }
  ];
  
  return {
    type: "history",
    transactions: mockTransactions,
    message: "Here are your recent transactions"
  };
}

// Process agent-related commands
function processAgentCommand(command) {
  if (command.includes("create") || command.includes("setup")) {
    return {
      type: "agent_setup",
      message: "Let's set up your trading agent. Please configure your risk preferences."
    };
  } else if (command.includes("risk")) {
    // Extract risk level
    let riskLevel = 'moderate';
    if (command.includes("conservative")) riskLevel = 'conservative';
    if (command.includes("aggressive")) riskLevel = 'aggressive';
    
    return {
      type: "agent_config",
      setting: "riskLevel",
      value: riskLevel,
      message: `Setting risk level to ${riskLevel}`
    };
  } else if (command.includes("target") && (command.includes("return") || command.includes("profit"))) {
    // Extract target return percentage
    const percentMatch = command.match(/(\d+)%/);
    const percent = percentMatch ? parseInt(percentMatch[1]) : 5;
    
    return {
      type: "agent_config",
      setting: "targetReturn",
      value: percent,
      message: `Setting target return to ${percent}%`
    };
  } else if (command.includes("pause") || command.includes("stop")) {
    return {
      type: "agent_control",
      action: "pause",
      message: "Pausing trading agent operations"
    };
  } else if (command.includes("resume") || command.includes("start")) {
    return {
      type: "agent_control",
      action: "resume",
      message: "Resuming trading agent operations"
    };
  } else if (command.includes("performance") || command.includes("how") || command.includes("results")) {
    return {
      type: "agent_status",
      performance: agentState.performance,
      message: `Your agent has made $${agentState.performance.dailyProfit.toFixed(2)} today and has ${agentState.performance.activePositions} active positions`
    };
  }
  
  return {
    type: "agent_unknown",
    message: "I didn't understand that agent command. Try asking about agent performance or configuring risk levels."
  };
}

// Execute transaction
async function executeTransaction(transaction) {
  console.log("Executing transaction:", transaction);
  
  // In a real implementation, this would connect to blockchain networks
  // For demo purposes, we'll simulate a successful transaction
  
  // Add transaction to history
  const newTransaction = {
    type: transaction.type,
    token: transaction.token,
    amount: transaction.amount,
    address: transaction.recipient || '-',
    date: new Date().toISOString().split('T')[0],
    status: 'Completed',
    hash: '0x' + Math.random().toString(16).substring(2, 10) + '...'
  };
  
  walletState.transactions.unshift(newTransaction);
  
  // Update storage
  chrome.storage.local.set({ walletState });
  
  return {
    success: true,
    transaction: newTransaction,
    message: `${transaction.type} transaction completed successfully`
  };
}

// Toggle trading agent
async function toggleTradingAgent(active, config) {
  console.log("Toggling trading agent:", active, config);
  
  agentState.active = active;
  
  if (config) {
    // Update agent configuration
    agentState = { ...agentState, ...config };
  }
  
  // Update storage
  chrome.storage.local.set({ agentState });
  
  if (active) {
    // Start the agent's monitoring and trading logic
    startTradingAgent();
    
    return {
      success: true,
      message: "Trading agent activated successfully"
    };
  } else {
    // Stop the agent's operations
    stopTradingAgent();
    
    return {
      success: true,
      message: "Trading agent deactivated"
    };
  }
}

// Start trading agent
function startTradingAgent() {
  console.log("Starting trading agent with profile:", agentState.riskProfile);
  
  // In a real implementation, this would start a continuous monitoring process
  // For demo purposes, we'll simulate some activity
  
  // Simulate agent performance updates
  setInterval(() => {
    if (!agentState.active) return;
    
    // Simulate market fluctuations
    const profitChange = (Math.random() * 2 - 1) * 5; // Random value between -5 and 5
    agentState.performance.dailyProfit += profitChange;
    
    // Occasionally make trading decisions
    if (Math.random() > 0.7) {
      makeAgentDecision();
    }
    
    // Update storage
    chrome.storage.local.set({ agentState });
  }, 60000); // Update every minute
}

// Stop trading agent
function stopTradingAgent() {
  console.log("Stopping trading agent");
  
  // In a real implementation, this would stop all agent operations
  // For demo purposes, we'll just update the state
  
  agentState.active = false;
  chrome.storage.local.set({ agentState });
}

// Make agent trading decision
function makeAgentDecision() {
  const actions = ['buy', 'sell', 'hold', 'swap'];
  const assets = agentState.allowedAssets;
  
  // Generate a random decision based on risk profile
  let actionProbabilities;
  
  if (agentState.riskProfile === 'conservative') {
    actionProbabilities = [0.2, 0.2, 0.5, 0.1]; // More likely to hold
  } else if (agentState.riskProfile === 'aggressive') {
    actionProbabilities = [0.4, 0.3, 0.1, 0.2]; // More likely to buy/sell
  } else {
    actionProbabilities = [0.3, 0.2, 0.3, 0.2]; // Balanced
  }
  
  // Select action based on probabilities
  let random = Math.random();
  let actionIndex = 0;
  let sum = 0;
  
  for (let i = 0; i < actionProbabilities.length; i++) {
    sum += actionProbabilities[i];
    if (random <= sum) {
      actionIndex = i;
      break;
    }
  }
  
  const action = actions[actionIndex];
  const asset = assets[Math.floor(Math.random() * assets.length)];
  const amount = Math.random() * 10 * (agentState.riskProfile === 'aggressive' ? 2 : 1);
  
  // Create decision object
  const decision = {
    action: action,
    asset: asset,
    amount: parseFloat(amount.toFixed(4)),
    reasoning: `Market conditions favorable for this ${action} operation`,
    confidence: Math.random() * 0.5 + 0.5, // 0.5 to 1.0
    riskScore: actionIndex === 2 ? 0.1 : Math.random() * 0.7 + 0.3 // Higher for non-hold actions
  };
  
  // Update agent state with the decision
  agentState.lastDecision = decision;
  
  // Update active positions count
  if (action === 'buy') {
    agentState.performance.activePositions++;
  } else if (action === 'sell' && agentState.performance.activePositions > 0) {
    agentState.performance.activePositions--;
  }
  
  console.log("Agent decision:", decision);
  
  // In a real implementation, this would execute the trade
  // For demo purposes, we'll just log it
  
  return decision;
}

// Initialize when the service worker starts
console.log("CryptoVoice background service worker initialized");

// Load state from storage
chrome.storage.local.get(['walletState', 'agentState'], (result) => {
  if (result.walletState) {
    walletState = result.walletState;
  }
  
  if (result.agentState) {
    agentState = result.agentState;
    
    // Restart agent if it was active
    if (agentState.active) {
      startTradingAgent();
    }
  }
});
