// Lock screen functionality
let inactivityTimer;
const INACTIVITY_TIMEOUT = 5 * 60 * 1000; // 5 minutes in milliseconds

function resetInactivityTimer() {
  clearTimeout(inactivityTimer);
  inactivityTimer = setTimeout(showLockScreen, INACTIVITY_TIMEOUT);
}

function showLockScreen() {
  const lockScreen = document.getElementById('lockScreen');
  lockScreen.classList.remove('hidden');
}

function hideLockScreen() {
  const lockScreen = document.getElementById('lockScreen');
  lockScreen.classList.add('hidden');
  resetInactivityTimer();
}

// Track user activity
function trackUserActivity() {
  resetInactivityTimer();
  
  // Add event listeners for user activity
  document.addEventListener('mousedown', resetInactivityTimer);
  document.addEventListener('keypress', resetInactivityTimer);
  document.addEventListener('touchstart', resetInactivityTimer);
}

// Function to handle logo resizing
function resizeLogo() {
  const logo = document.querySelector('.logo img');
  const header = document.querySelector('header');
  if (!logo || !header) return;
  
  // Get the header height
  const headerHeight = header.offsetHeight;
  
  // Calculate appropriate logo size (70% of header height)
  const logoSize = Math.max(Math.min(Math.floor(headerHeight * 0.7), 48), 32);
  
  // Apply the new size
  logo.style.width = `${logoSize}px`;
  logo.style.height = `${logoSize}px`;
  
  // Adjust text size based on logo size
  const logoText = document.querySelector('.logo h1');
  if (logoText) {
    logoText.style.fontSize = `${Math.max(logoSize * 0.45, 16)}px`;
  }
}

// Initial resize and add event listener for window resize
document.addEventListener('DOMContentLoaded', () => {
  // Call the resize function
  resizeLogo();
  
  // Add resize event listener
  window.addEventListener('resize', resizeLogo);
  
  // Initialize inactivity timer
  trackUserActivity();
  // DOM Elements
  const voiceButton = document.getElementById('voiceButton');
  const voiceCommandFeedback = document.getElementById('voiceCommandFeedback');
  const tokenList = document.getElementById('tokenList');
  const totalBalanceAmount = document.querySelector('.balance-amount');
  const sendBtn = document.getElementById('sendBtn');
  const receiveBtn = document.getElementById('receiveBtn');
  const swapBtn = document.getElementById('swapBtn');
  const historyBtn = document.getElementById('historyBtn');
  const marketplaceBtn = document.getElementById('marketplaceBtn');
  const configureAgentBtn = document.getElementById('configureAgentBtn');
  const modalContainer = document.getElementById('modalContainer');
  const statusDot = document.querySelector('.status-dot');
  const statusText = document.querySelector('.status-text');
  const agentPerformance = document.getElementById('agentPerformance');
  
  // Marketplace elements
  const marketplaceModal = document.getElementById('marketplaceModal');
  const closeMarketplaceBtn = document.getElementById('closeMarketplaceBtn');
  const agentsList = document.getElementById('agentsList');
  const selectedMarketplaceTitle = document.getElementById('selectedMarketplaceTitle');
  const agentsContainer = document.getElementById('agentsContainer');

  // Mock data for marketplaces and agents
  const marketplaceAgents = {
    avo: [
      { id: 'avo1', name: 'Alpha Predictor', description: 'AI-powered market prediction agent', roi: '+18.5%', users: 1245, fee: '2%' },
      { id: 'avo2', name: 'DeFi Yield Hunter', description: 'Optimizes yield farming strategies', roi: '+12.3%', users: 876, fee: '1.5%' },
      { id: 'avo3', name: 'Trend Surfer', description: 'Rides market trends with precision', roi: '+22.1%', users: 1532, fee: '2.5%' }
    ],
    aixbt: [
      { id: 'aixbt1', name: 'Momentum Master', description: 'Captures momentum in volatile markets', roi: '+15.7%', users: 932, fee: '1.8%' },
      { id: 'aixbt2', name: 'Crypto Oracle', description: 'Predicts crypto market movements', roi: '+19.2%', users: 1103, fee: '2.2%' },
      { id: 'aixbt3', name: 'Arbitrage Hunter', description: 'Exploits price differences across exchanges', roi: '+8.9%', users: 654, fee: '1.2%' }
    ],
    belive: [
      { id: 'belive1', name: 'Pattern Trader', description: 'Identifies and trades on chart patterns', roi: '+14.3%', users: 821, fee: '1.7%' },
      { id: 'belive2', name: 'News Reactor', description: 'Trades based on market news and events', roi: '+11.8%', users: 743, fee: '1.5%' },
      { id: 'belive3', name: 'Volatility Surfer', description: 'Profits from market volatility', roi: '+20.5%', users: 1289, fee: '2.3%' }
    ],
    virtuals: [
      { id: 'virtuals1', name: 'NFT Alpha', description: 'Identifies undervalued NFT collections', roi: '+25.3%', users: 1876, fee: '2.8%' },
      { id: 'virtuals2', name: 'Metaverse Investor', description: 'Invests in promising metaverse projects', roi: '+19.8%', users: 1432, fee: '2.1%' },
      { id: 'virtuals3', name: 'Digital Asset Fund', description: 'Diversified digital asset portfolio manager', roi: '+17.2%', users: 1654, fee: '1.9%' }
    ],
    elizaos: [
      { id: 'elizaos1', name: 'AI Token Trader', description: 'Specializes in AI-related token trading', roi: '+23.7%', users: 2145, fee: '2.5%' },
      { id: 'elizaos2', name: 'Tech Innovator', description: 'Invests in cutting-edge tech projects', roi: '+20.9%', users: 1897, fee: '2.2%' },
      { id: 'elizaos3', name: 'Quantum Portfolio', description: 'Uses quantum computing models for trading', roi: '+28.4%', users: 2356, fee: '3.0%' }
    ],
    agentik: [
      { id: 'agentik1', name: 'Smart Portfolio', description: 'Balanced portfolio management agent', roi: '+16.2%', users: 1567, fee: '1.9%' },
      { id: 'agentik2', name: 'Whale Tracker', description: 'Follows institutional investor movements', roi: '+21.7%', users: 1832, fee: '2.4%' },
      { id: 'agentik3', name: 'Risk Optimizer', description: 'Maximizes returns while minimizing risk', roi: '+13.5%', users: 912, fee: '1.6%' }
    ]
  };
  
  // Mock data for demonstration
  const mockTokens = [
    { symbol: 'SOL', name: 'Solana', amount: 20, value: 3160.00, price: 158.00, icon: '../assets/tokens/sol.svg' },
    { symbol: 'ETH', name: 'Ethereum', amount: 1.25, value: 3121.25, price: 2497.00, icon: '../assets/tokens/eth.svg' },
    { symbol: 'BTC', name: 'Bitcoin', amount: 0.05, value: 5245.54, price: 104910.70, icon: '../assets/tokens/btc.svg' },
    { symbol: 'USDC', name: 'USD Coin', amount: 1000, value: 1000.00, price: 1.00, icon: '../assets/tokens/usdc.svg' }
  ];
  
  // Transaction history
  const transactionHistory = [
    { type: 'Send', token: 'SOL', amount: 5, address: 'AKiTR4rfGxHLVbS1iAZCxNZrKJdCjF4mZfwMJSg8WNj2', date: '2025-05-30', status: 'Completed' },
    { type: 'Receive', token: 'SOL', amount: 10, address: 'BXvRT4rGxJLVbS1iAZCxNZrKJdCjF4mZfwMJSg8WNj7', date: '2025-05-28', status: 'Completed' },
    { type: 'Swap', token: 'USDC → SOL', amount: 100, address: '-', date: '2025-05-25', status: 'Completed' }
  ];

  // Initialize wallet
  function initWallet() {
    // Calculate total balance
    const totalValue = mockTokens.reduce((total, token) => total + token.value, 0);
    totalBalanceAmount.textContent = `$${totalValue.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;
    
    // Populate token list
    tokenList.innerHTML = '';
    mockTokens.forEach(token => {
      const tokenItem = document.createElement('div');
      tokenItem.className = 'token-item';
      tokenItem.innerHTML = `
        <div class="token-name">
          <img src="${token.icon}" alt="${token.symbol}" class="token-icon">
          <span class="token-symbol">${token.symbol}</span>
        </div>
        <div class="token-balance">
          <span class="token-amount">${token.amount}</span>
          <span class="token-value">$${token.value.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</span>
        </div>
      `;
      tokenList.appendChild(tokenItem);
    });
  }

  // Voice recognition functionality
  let recognition;
  let isListening = false;
  const voiceModal = document.getElementById('voiceModal');
  const voiceTranscript = document.getElementById('voiceTranscript');
  const permissionModal = document.getElementById('permissionModal');
  const requestPermissionBtn = document.getElementById('requestPermissionBtn');
  const closePermissionModal = document.getElementById('closePermissionModal');
  
  // Track microphone permission state
  let microphonePermissionGranted = false;

  function setupSpeechRecognition() {
    if ('webkitSpeechRecognition' in window) {
      recognition = new webkitSpeechRecognition();
      recognition.continuous = false;
      recognition.interimResults = true; // Enable interim results to show live transcription
      recognition.lang = 'en-US';

      recognition.onstart = () => {
        isListening = true;
        voiceButton.style.backgroundColor = 'var(--accent-color)';
        // Show the voice modal
        voiceModal.classList.remove('hidden');
        voiceTranscript.textContent = '';
      };

      recognition.onresult = (event) => {
        // Display interim results
        const transcript = Array.from(event.results)
          .map(result => result[0].transcript)
          .join('');
        
        voiceTranscript.textContent = transcript;
        
        // If this is a final result, process the command
        if (event.results[0].isFinal) {
          setTimeout(() => {
            processVoiceCommand(transcript.toLowerCase());
          }, 500); // Small delay to show the final transcript before closing
        }
      };

      recognition.onend = () => {
        isListening = false;
        voiceButton.style.backgroundColor = 'var(--primary-color)';
        // Hide the voice modal
        voiceModal.classList.add('hidden');
      };

      recognition.onerror = (event) => {
        console.error('Speech recognition error', event.error);
        isListening = false;
        voiceButton.style.backgroundColor = 'var(--primary-color)';
        // Hide the voice modal
        voiceModal.classList.add('hidden');
        
        // Show error notification
        if (event.error !== 'aborted') {
          showNotification('Voice recognition error: ' + event.error);
        }
      };
    } else {
      alert('Speech recognition is not supported in your browser.');
      voiceButton.disabled = true;
    }
  }

  // Check if microphone permission is already granted
  function checkMicrophonePermission() {
    return navigator.permissions.query({ name: 'microphone' })
      .then(permissionStatus => {
        console.log('Microphone permission status:', permissionStatus.state);
        if (permissionStatus.state === 'granted') {
          microphonePermissionGranted = true;
          return true;
        } else if (permissionStatus.state === 'denied') {
          microphonePermissionGranted = false;
          return false;
        } else {
          // Permission is 'prompt' - we'll need to ask
          microphonePermissionGranted = false;
          return false;
        }
      })
      .catch(error => {
        console.error('Error checking microphone permission:', error);
        // If we can't check permission status, we'll try to request it anyway
        return false;
      });
  }

  // Request microphone permission for Chrome extension
  function requestMicrophonePermission() {
    // For Chrome extensions, we need to direct users to extension settings
    // We'll try to access the microphone first to trigger the permission prompt
    return navigator.mediaDevices.getUserMedia({ audio: true })
      .then(stream => {
        // Permission granted, stop the stream as we don't need it yet
        stream.getTracks().forEach(track => track.stop());
        microphonePermissionGranted = true;
        return true;
      })
      .catch(error => {
        console.error('Microphone permission denied:', error);
        microphonePermissionGranted = false;
        
        // Open the extensions page to help user set permissions
        chrome.tabs.create({ url: 'chrome://extensions/?id=' + chrome.runtime.id });
        
        return false;
      });
  }

  function toggleSpeechRecognition() {
    if (isListening) {
      recognition.stop();
    } else {
      // First check if we already have permission
      checkMicrophonePermission().then(hasPermission => {
        if (hasPermission) {
          // We have permission, start recognition
          startRecognition();
        } else {
          // Show the permission request modal
          permissionModal.classList.remove('hidden');
        }
      });
    }
  }
  
  function startRecognition() {
    try {
      recognition.start();
    } catch (e) {
      console.error('Error starting recognition:', e);
      // Sometimes the recognition engine needs to be reset
      setupSpeechRecognition();
      setTimeout(() => recognition.start(), 100);
    }
  }

  function processVoiceCommand(command) {
    console.log('Voice command received:', command);
    
    // Check for marketplace browsing command with or without 'Hey Lucy' trigger
    const marketplaceRegex = /(?:(?:hey\s+lucy|hey|hi\s+lucy|hi)\s+)?(?:browse|show|open|view)\s+(?:the\s+)?(?:marketplace|market\s+place|agent\s+marketplace)/i;
    if (marketplaceRegex.test(command)) {
      showNotification('Opening marketplace...');
      showMarketplaceModal();
      return;
    }
    
    // Check for setup agent command with or without 'Hey Lucy' trigger
    const setupAgentRegex = /(?:(?:hey\s+lucy|hey|hi\s+lucy|hi)\s+)?(?:setup|configure|set\s+up)\s+(?:the\s+)?(?:agent|trading\s+agent)/i;
    if (setupAgentRegex.test(command)) {
      showNotification('Opening agent setup...');
      showAgentConfigModal();
      return;
    }
    
    // Check for send command with 'Hey Lucy' trigger - prioritize this over other send commands
    const heyLucySendRegex = /(?:hey\s+lucy|hey|hi\s+lucy|hi)\s+send\b/i;
    if (heyLucySendRegex.test(command)) {
      console.log('Hey Lucy send command detected');
      
      try {
        // Show notification first
        showNotification('Opening send menu...');
        
        // Direct call to send button click handler
        console.log('Simulating send button click');
        if (sendBtn) {
          sendBtn.click();
        } else {
          console.error('Send button not found, falling back to manual modal creation');
          showSendModal('', '', '');
        }
      } catch (error) {
        console.error('Error showing send modal:', error);
        // Fallback approach
        try {
          showModal('Send Tokens', `
            <form id="sendForm">
              <div class="form-group">
                <label for="recipient">Recipient Address</label>
                <input type="text" id="recipient" placeholder="0x..." value="" required>
              </div>
              <div class="form-group">
                <label for="amount">Amount</label>
                <input type="number" id="amount" min="0" step="0.0001" value="" required>
                <div class="usd-conversion" id="usdConversion"></div>
              </div>
              <div class="form-group">
                <label for="token">Token</label>
                <select id="token">
                  ${mockTokens.map(token => `<option value="${token.symbol}">${token.symbol}</option>`).join('')}
                </select>
              </div>
            </form>
          `, `
            <button class="btn btn-secondary" id="cancelSend">Cancel</button>
            <button class="btn btn-primary" id="confirmSend">Send</button>
          `);
        } catch (fallbackError) {
          console.error('Fallback also failed:', fallbackError);
        }
      }
      return;
    }
    
    // Check for command to send 5 SOL to the last transaction address
    const lastTxRegex = /(?:copy|send|transfer)\s+(?:the\s+)?(?:address|5\s+sol)\s+(?:from|to)\s+(?:the\s+)?last\s+transaction/i;
    if (lastTxRegex.test(command)) {
      // Find the address from the last transaction (any type)
      const lastAddress = findLastTransactionAddress();
      if (!lastAddress) {
        showNotification('No transaction history found');
        return;
      }
      
      // Show notification that we're processing the command
      showNotification(`Processing transfer of 5 SOL to last transaction address...`);
      
      // Open send modal with pre-filled information (5 SOL)
      autoCompleteSendTransaction(lastAddress, 5, 'SOL');
      return;
    }
    
    // Check for specific transfer command pattern
    const transferRegex = /(?:transfer|send)\s+(\d+(?:\.\d+)?)\s+(\w+)\s+to\s+(?:my\s+)?(?:previous|last|recent)\s+(?:transaction|recipient|address)/i;
    const transferMatch = command.match(transferRegex);
    
    if (transferMatch) {
      // Extract amount and token from the command
      const amount = parseFloat(transferMatch[1]);
      const tokenSymbol = transferMatch[2].toUpperCase();
      
      // Find the token in our list
      const token = mockTokens.find(t => t.symbol.toUpperCase() === tokenSymbol);
      if (!token) {
        showNotification(`Token ${tokenSymbol} not found in your wallet`);
        return;
      }
      
      // Find the most recent send transaction address
      const lastRecipient = findLastRecipientAddress();
      if (!lastRecipient) {
        showNotification('No previous transaction recipient found');
        return;
      }
      
      // Show notification that we're processing the command
      showNotification(`Processing transfer of ${amount} ${tokenSymbol} to last recipient...`);
      
      // Open send modal with pre-filled information and auto-complete the transaction
      autoCompleteSendTransaction(lastRecipient, amount, token.symbol);
    }
    // Balance command processing with token-specific handling
    else if (command.includes('balance') || command.includes('wallet')) {
      // Check for general balance queries like "what is my current balance"
      const generalBalanceRegex = /(?:what(?:'s|s|\s+is)|show|check|get)\s+(?:my|the)(?:\s+current)?\s+balance/i;
      if (generalBalanceRegex.test(command)) {
        // Show all token balances for general balance queries
        showTokenBalancesModal();
        return;
      }
      
      // Check if the user is asking about a specific token
      // This improved regex handles various phrasings like "What's my Solana balance", "Show me my ETH", etc.
      const tokenRegex = /(?:(?:what(?:'s|s|\s+is)|show|check|get)\s+(?:my|the)\s+(\w+))|(?:(\w+)\s+(?:balance|wallet))/i;
      const match = command.match(tokenRegex);
      const tokenMatch = match ? [match[0], match[1] || match[2]] : null;
      
      if (tokenMatch) {
        // Get the token name or symbol from the command
        const tokenInput = tokenMatch[1].toLowerCase();
        
        // Create a mapping of common token names and variations to their symbols
        const tokenNameMap = {
          'solana': 'SOL',
          'sol': 'SOL',
          'ethereum': 'ETH',
          'eth': 'ETH',
          'ether': 'ETH',
          'bitcoin': 'BTC',
          'btc': 'BTC',
          'usd': 'USDC',
          'usdc': 'USDC',
          'usd coin': 'USDC'
        };
        
        // Get the standardized token symbol
        const tokenSymbol = tokenNameMap[tokenInput] || tokenInput.toUpperCase();
        
        // Find the token in our list
        const token = mockTokens.find(t => 
          t.symbol.toUpperCase() === tokenSymbol || 
          t.name.toLowerCase() === tokenInput
        );
        
        if (token) {
          showNotification(`Your ${token.name} (${token.symbol}) balance is ${token.amount} ${token.symbol} ($${token.value.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })})`);  
        } else {
          showNotification(`Token ${tokenInput} not found in your wallet`);
        }
      } else {
        // Show all token balances
        showTokenBalancesModal();
      }
    } else if (command.includes('send') || command.includes('transfer')) {
      showSendModal();
    } else if (command.includes('swap') || command.includes('exchange')) {
      showSwapModal();
    } else if (command.includes('history') || command.includes('transactions')) {
      showHistoryModal();
    } else if (command.includes('agent') || command.includes('trading')) {
      toggleAgentStatus();
    } else {
      showNotification('Command not recognized. Please try again.');
    }
  }
  
  function findLastRecipientAddress() {
    // Find the most recent send transaction
    const sendTransactions = transactionHistory.filter(tx => tx.type === 'Send');
    if (sendTransactions.length > 0) {
      // Sort by date descending and get the first one
      sendTransactions.sort((a, b) => new Date(b.date) - new Date(a.date));
      return sendTransactions[0].address;
    }
    return null;
  }

  function findLastTransactionAddress() {
    // Find the most recent transaction of any type
    if (transactionHistory.length > 0) {
      // Sort by date descending and get the first one
      const sortedTransactions = [...transactionHistory].sort((a, b) => new Date(b.date) - new Date(a.date));
      return sortedTransactions[0].address;
    }
    return null;
  }

  // UI Interaction Functions
  function showNotification(message, type = 'default') {
    const notification = document.createElement('div');
    notification.className = type === 'success' ? 'success-notification' : 'notification';
    notification.textContent = message;
    document.body.appendChild(notification);
    
    setTimeout(() => {
      notification.remove();
    }, 3000);
  }

  function showModal(title, content, actions) {
    modalContainer.innerHTML = '';
    const modal = document.createElement('div');
    modal.className = 'modal';
    
    modal.innerHTML = `
      <div class="modal-header">
        <h3 class="modal-title">${title}</h3>
        <button class="close-button">&times;</button>
      </div>
      <div class="modal-content">
        ${content}
      </div>
      <div class="modal-footer">
        ${actions}
      </div>
    `;
    
    modalContainer.appendChild(modal);
    modalContainer.classList.remove('hidden');
    
    // Ensure the modal is visible in the viewport by scrolling up
    setTimeout(() => {
      window.scrollTo({
        top: 0,
        behavior: 'smooth'
      });
    }, 100);
    
    const closeButton = modal.querySelector('.close-button');
    closeButton.addEventListener('click', () => {
      modalContainer.classList.add('hidden');
    });
  }

  function autoCompleteSendTransaction(recipientAddress, amount, tokenSymbol) {
    // First show the send modal with pre-filled information
    showSendModal(recipientAddress, amount, tokenSymbol);
    
    // Wait a short time for the modal to render
    setTimeout(() => {
      // Click the confirm send button to show the confirmation modal
      const confirmSendBtn = document.getElementById('confirmSend');
      if (confirmSendBtn) {
        confirmSendBtn.click();
        
        // Wait for the confirmation modal to appear
        setTimeout(() => {
          // Add a voice confirmation prompt to the confirmation modal
          const confirmationModal = document.querySelector('.modal-content');
          if (confirmationModal) {
            // Add a voice confirmation message at the top of the confirmation modal
            const confirmationPrompt = document.createElement('div');
            confirmationPrompt.className = 'voice-confirmation-prompt';
            confirmationPrompt.innerHTML = `
              <div class="confirmation-prompt-message">
                <strong>Voice confirmation required:</strong> Please say "confirm" to complete this transaction or "cancel" to abort.
              </div>
            `;
            confirmationModal.prepend(confirmationPrompt);
            
            // Start listening for confirmation
            listenForTransactionConfirmation(amount, tokenSymbol);
          }
        }, 500);
      }
    }, 500);
  }
  
  function listenForTransactionConfirmation(amount, tokenSymbol) {
    // Create a new recognition instance for this specific confirmation
    const confirmationRecognition = new webkitSpeechRecognition();
    confirmationRecognition.continuous = false;
    confirmationRecognition.interimResults = false;
    
    // Start listening
    confirmationRecognition.start();
    
    // Show a notification that we're waiting for confirmation
    showNotification('Waiting for voice confirmation...', 'default');
    
    // Handle the result
    confirmationRecognition.onresult = function(event) {
      const transcript = event.results[0][0].transcript.toLowerCase().trim();
      console.log('Confirmation response:', transcript);
      
      if (transcript.includes('confirm') || transcript.includes('yes') || transcript.includes('approve')) {
        // User confirmed, execute the transaction
        const executeTransactionBtn = document.getElementById('executeTransaction');
        if (executeTransactionBtn) {
          executeTransactionBtn.click();
          showNotification(`Successfully sent ${amount} ${tokenSymbol} to last recipient`, 'success');
        }
      } else if (transcript.includes('cancel') || transcript.includes('no') || transcript.includes('abort')) {
        // User canceled, close the modal
        const cancelTransactionBtn = document.getElementById('cancelTransaction');
        if (cancelTransactionBtn) {
          cancelTransactionBtn.click();
          showNotification('Transaction canceled', 'default');
        }
      } else {
        // Unrecognized response, ask again
        showNotification('Please say "confirm" or "cancel"', 'default');
        setTimeout(() => listenForTransactionConfirmation(amount, tokenSymbol), 1000);
      }
    };
    
    // Handle errors
    confirmationRecognition.onerror = function(event) {
      console.error('Speech recognition error', event.error);
      showNotification('Voice confirmation failed. Please try again or use the buttons.', 'default');
    };
    
    // Set a timeout for the confirmation
    setTimeout(() => {
      confirmationRecognition.stop();
    }, 5000);
  }
  
  function showSendModal(recipientAddress = '', initialAmount = '', initialToken = '') {
    const content = `
      <form id="sendForm">
        <div class="form-group">
          <label for="recipient">Recipient Address</label>
          <input type="text" id="recipient" placeholder="0x..." value="${recipientAddress}" required>
        </div>
        <div class="form-group">
          <label for="amount">Amount</label>
          <input type="number" id="amount" min="0" step="0.0001" value="${initialAmount}" required>
          <div class="usd-conversion" id="usdConversion"></div>
        </div>
        <div class="form-group">
          <label for="token">Token</label>
          <select id="token">
            ${mockTokens.map(token => `<option value="${token.symbol}" ${token.symbol === initialToken ? 'selected' : ''}>${token.symbol}</option>`).join('')}
          </select>
        </div>
      </form>
    `;
    
    const actions = `
      <button class="btn btn-secondary" id="cancelSend">Cancel</button>
      <button class="btn btn-primary" id="confirmSend">Send</button>
    `;
    
    showModal('Send Tokens', content, actions);
    
    // Set up USD conversion display
    const amountInput = document.getElementById('amount');
    const tokenSelect = document.getElementById('token');
    const usdConversion = document.getElementById('usdConversion');
    
    function updateUsdValue() {
      const amount = parseFloat(amountInput.value) || 0;
      const tokenSymbol = tokenSelect.value;
      const token = mockTokens.find(t => t.symbol === tokenSymbol);
      
      if (token) {
        const usdValue = (amount * token.price).toFixed(2);
        usdConversion.textContent = `≈ $${usdValue} USD`;
      }
    }
    
    // Update USD value when amount or token changes
    amountInput.addEventListener('input', updateUsdValue);
    tokenSelect.addEventListener('change', updateUsdValue);
    
    // Initialize USD value
    updateUsdValue();
    
    document.getElementById('confirmSend').addEventListener('click', () => {
      const recipient = document.getElementById('recipient').value;
      const amount = document.getElementById('amount').value;
      const token = document.getElementById('token').value;
      
      if (recipient && amount && token) {
        showTransactionConfirmation(recipient, amount, token);
      }
    });
    
    document.getElementById('cancelSend').addEventListener('click', () => {
      modalContainer.classList.add('hidden');
    });
  }
  
  function showTransactionConfirmation(recipient, amount, token) {
    const selectedToken = mockTokens.find(t => t.symbol === token);
    const usdValue = (parseFloat(amount) * selectedToken.price).toFixed(2);
    
    const content = `
      <div class="confirmation-details">
        <div class="confirmation-item">
          <span class="label">Recipient:</span>
          <span class="value">${recipient.substring(0, 10)}...${recipient.substring(recipient.length - 5)}</span>
        </div>
        <div class="confirmation-item">
          <span class="label">Amount:</span>
          <span class="value">${amount} ${token}</span>
        </div>
        <div class="confirmation-item">
          <span class="label">Value:</span>
          <span class="value">$${usdValue} USD</span>
        </div>
        <div class="confirmation-item">
          <span class="label">Network Fee:</span>
          <span class="value">0.000005 SOL</span>
        </div>
      </div>
      <div class="confirmation-warning">
        Please verify all details before confirming this transaction.
      </div>
    `;
    
    const actions = `
      <button class="btn btn-secondary" id="cancelTransaction">Cancel</button>
      <button class="btn btn-primary" id="executeTransaction">Confirm</button>
    `;
    
    showModal('Confirm Transaction', content, actions);
    
    document.getElementById('executeTransaction').addEventListener('click', () => {
      // Add the transaction to history
      const newTransaction = {
        type: 'Send',
        token: token,
        amount: parseFloat(amount),
        address: recipient,
        date: new Date().toISOString().split('T')[0],
        status: 'Completed'
      };
      
      transactionHistory.unshift(newTransaction);
      
      // Update token balance
      const tokenToUpdate = mockTokens.find(t => t.symbol === token);
      if (tokenToUpdate) {
        // Ensure we're working with numbers
        const amountToSend = parseFloat(amount);
        tokenToUpdate.amount = parseFloat(tokenToUpdate.amount) - amountToSend;
        tokenToUpdate.value = tokenToUpdate.amount * tokenToUpdate.price;
        
        console.log(`Updated ${token} balance: ${tokenToUpdate.amount} (value: $${tokenToUpdate.value})`);
        
        // Force UI refresh
        initWallet();
        
        // Update the displayed balance in the header
        const totalValue = mockTokens.reduce((total, token) => total + token.value, 0);
        document.getElementById('totalBalanceAmount').textContent = 
          `$${totalValue.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;
      }
      
      showNotification(`Sent ${amount} ${token} to ${recipient.substring(0, 6)}...`);
      modalContainer.classList.add('hidden');
    });
    
    document.getElementById('cancelTransaction').addEventListener('click', () => {
      modalContainer.classList.add('hidden');
    });
  }

  function showSwapModal() {
    const content = `
      <form id="swapForm">
        <div class="form-group">
          <label for="fromToken">From</label>
          <select id="fromToken">
            ${mockTokens.map(token => `<option value="${token.symbol}">${token.symbol}</option>`).join('')}
          </select>
        </div>
        <div class="form-group">
          <label for="fromAmount">Amount</label>
          <input type="number" id="fromAmount" min="0" step="0.0001" required>
        </div>
        <div class="form-group">
          <label for="toToken">To</label>
          <select id="toToken">
            ${mockTokens.map(token => `<option value="${token.symbol}">${token.symbol}</option>`).join('')}
          </select>
        </div>
        <div class="form-group">
          <label>Estimated Receive</label>
          <div id="estimatedAmount">0.00</div>
        </div>
      </form>
    `;
    
    const actions = `
      <button class="btn btn-secondary" id="cancelSwap">Cancel</button>
      <button class="btn btn-primary" id="confirmSwap">Swap</button>
    `;
    
    showModal('Swap Tokens', content, actions);
    
    document.getElementById('confirmSwap').addEventListener('click', () => {
      const fromToken = document.getElementById('fromToken').value;
      const fromAmount = document.getElementById('fromAmount').value;
      const toToken = document.getElementById('toToken').value;
      
      if (fromToken && fromAmount && toToken) {
        showNotification(`Swapped ${fromAmount} ${fromToken} to ${toToken}`);
        modalContainer.classList.add('hidden');
      }
    });
    
    document.getElementById('cancelSwap').addEventListener('click', () => {
      modalContainer.classList.add('hidden');
    });
  }

  function showTokenBalancesModal() {
    const content = `
      <div class="token-balances-container">
        <div class="total-balance-header">
          <h3>Total Balance</h3>
          <div class="total-balance-value">$${mockTokens.reduce((total, token) => total + token.value, 0).toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</div>
        </div>
        <div class="token-balances-list">
          ${mockTokens.map(token => `
            <div class="token-balance-item">
              <div class="token-balance-info">
                <img src="${token.icon}" alt="${token.symbol}" class="token-balance-icon">
                <div class="token-balance-details">
                  <div class="token-balance-name">${token.name} (${token.symbol})</div>
                  <div class="token-balance-amount">${token.amount} ${token.symbol}</div>
                </div>
              </div>
              <div class="token-balance-value">$${token.value.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</div>
            </div>
          `).join('')}
        </div>
      </div>
    `;
    
    const actions = `
      <button class="btn btn-secondary" id="closeBalances">Close</button>
    `;
    
    showModal('Your Token Balances', content, actions);
    
    document.getElementById('closeBalances').addEventListener('click', () => {
      modalContainer.classList.add('hidden');
    });
  }

  function showHistoryModal() {
    const content = `
      <div class="transaction-list">
        ${transactionHistory.map(tx => `
          <div class="transaction-item" data-address="${tx.address}" data-token="${tx.token}">
            <div class="tx-info">
              <div class="tx-type ${tx.type.toLowerCase()}">${tx.type}</div>
              <div class="tx-token">${tx.token}</div>
            </div>
            <div class="tx-details">
              <div class="tx-amount">${tx.amount}</div>
              <div class="tx-date">${tx.date}</div>
            </div>
            ${tx.type === 'Send' || tx.type === 'Receive' ? 
              `<div class="tx-address" title="${tx.address}">${tx.address.substring(0, 8)}...${tx.address.substring(tx.address.length - 4)}</div>` : 
              ''
            }
          </div>
        `).join('')}
      </div>
    `;
    
    const actions = `
      <button class="btn btn-secondary" id="closeHistory">Close</button>
    `;
    
    showModal('Transaction History', content, actions);
    
    // Add click event for transaction items to easily send to previous recipients
    document.querySelectorAll('.transaction-item').forEach(item => {
      item.addEventListener('click', () => {
        const address = item.getAttribute('data-address');
        const token = item.getAttribute('data-token');
        
        if (address && address !== '-') {
          modalContainer.classList.add('hidden');
          setTimeout(() => {
            showSendModal(address, '', token.split(' ')[0]); // Use first token if it's a swap
          }, 300);
        }
      });
    });
    
    document.getElementById('closeHistory').addEventListener('click', () => {
      modalContainer.classList.add('hidden');
    });
  }

  function toggleAgentStatus() {
    const isActive = statusDot.classList.contains('active');
    
    if (isActive) {
      statusDot.classList.remove('active');
      statusDot.classList.add('inactive');
      statusText.textContent = 'Inactive';
      agentPerformance.classList.add('hidden');
      showNotification('Trading agent deactivated');
    } else {
      showAgentConfigModal();
    }
  }

  function showAgentConfigModal() {
    const content = `
      <form id="agentConfigForm">
        <div class="form-group">
          <label for="riskLevel">Risk Level</label>
          <select id="riskLevel">
            <option value="conservative">Conservative</option>
            <option value="moderate">Moderate</option>
            <option value="aggressive">Aggressive</option>
          </select>
        </div>
        <div class="form-group">
          <label for="dailyLimit">Daily Trading Limit ($)</label>
          <input type="number" id="dailyLimit" min="10" value="100">
        </div>
        <div class="form-group">
          <label for="targetReturn">Target Monthly Return (%)</label>
          <input type="number" id="targetReturn" min="1" max="100" value="5">
        </div>
        <div class="form-group">
          <label>Allowed Assets</label>
          <div class="checkbox-group">
            ${mockTokens.map(token => `
              <div class="checkbox-item">
                <input type="checkbox" id="${token.symbol}" value="${token.symbol}" checked>
                <label for="${token.symbol}">${token.symbol}</label>
              </div>
            `).join('')}
          </div>
        </div>
      </form>
    `;
    
    const actions = `
      <button class="btn btn-secondary" id="cancelConfig">Cancel</button>
      <button class="btn btn-primary" id="confirmConfig">Activate Agent</button>
    `;
    
    showModal('Configure Trading Agent', content, actions);
    
    document.getElementById('confirmConfig').addEventListener('click', () => {
      statusDot.classList.remove('inactive');
      statusDot.classList.add('active');
      statusText.textContent = 'Active';
      
      // Show agent performance section with mock data
      agentPerformance.innerHTML = `
        <div class="performance-item">
          <span class="performance-label">Today's Profit:</span>
          <span class="performance-value positive">+$12.45 (2.3%)</span>
        </div>
        <div class="performance-item">
          <span class="performance-label">Active Positions:</span>
          <span class="performance-value">3</span>
        </div>
        <div class="performance-item">
          <span class="performance-label">Risk Level:</span>
          <span class="performance-value">${document.getElementById('riskLevel').value}</span>
        </div>
      `;
      agentPerformance.classList.remove('hidden');
      
      modalContainer.classList.add('hidden');
      showNotification('Trading agent activated');
    });
    
    document.getElementById('cancelConfig').addEventListener('click', () => {
      modalContainer.classList.add('hidden');
    });
  }

  // Marketplace functions
  function showMarketplaceModal() {
    marketplaceModal.classList.remove('hidden');
    agentsList.classList.add('hidden');
    
    // Add click event listeners to marketplace options
    const marketplaceOptions = document.querySelectorAll('.marketplace-option');
    marketplaceOptions.forEach(option => {
      option.addEventListener('click', () => {
        // Remove selected class from all options
        marketplaceOptions.forEach(opt => opt.classList.remove('selected'));
        
        // Add selected class to clicked option
        option.classList.add('selected');
        
        // Get marketplace ID and show agents
        const marketplaceId = option.getAttribute('data-marketplace');
        showAgentsForMarketplace(marketplaceId);
      });
    });
    
    // Add click event listener to View All button
    const viewAllAgentsBtn = document.getElementById('viewAllAgentsBtn');
    if (viewAllAgentsBtn) {
      viewAllAgentsBtn.addEventListener('click', showAllAgents);
    }
  }
  
  function showAgentsForMarketplace(marketplaceId) {
    // Update title
    const marketplaceName = document.querySelector(`.marketplace-option[data-marketplace="${marketplaceId}"] span`).textContent;
    selectedMarketplaceTitle.textContent = `${marketplaceName} Agents`;
    
    // Show agents list
    agentsList.classList.remove('hidden');
    
    // Get agents for selected marketplace
    const agents = marketplaceAgents[marketplaceId];
    
    // Populate agents container
    agentsContainer.innerHTML = '';
    agents.forEach(agent => {
      const agentCard = document.createElement('div');
      agentCard.className = 'agent-card';
      agentCard.innerHTML = `
        <div class="agent-icon">${agent.name.charAt(0)}</div>
        <div class="agent-info">
          <div class="agent-name">${agent.name}</div>
          <div class="agent-description">${agent.description}</div>
          <div class="agent-metrics">
            <div class="agent-metric positive">ROI: ${agent.roi}</div>
            <div class="agent-metric">Users: ${agent.users.toLocaleString()}</div>
            <div class="agent-metric">Fee: ${agent.fee}</div>
          </div>
        </div>
        <div class="agent-actions">
          <button class="invest-btn" data-agent-id="${agent.id}">Invest</button>
        </div>
      `;
      
      agentsContainer.appendChild(agentCard);
    });
    
    // Add event listeners to invest buttons
    const investButtons = document.querySelectorAll('.invest-btn');
    investButtons.forEach(button => {
      button.addEventListener('click', (e) => {
        e.stopPropagation();
        const agentId = button.getAttribute('data-agent-id');
        showInvestModal(agentId);
      });
    });
  }
  
  function showAllAgents() {
    // Update title
    selectedMarketplaceTitle.textContent = 'All Available Agents';
    
    // Show agents list
    agentsList.classList.remove('hidden');
    
    // Populate agents container with agents from all marketplaces
    agentsContainer.innerHTML = '';
    
    // Get all marketplace options and remove selected class
    const marketplaceOptions = document.querySelectorAll('.marketplace-option');
    marketplaceOptions.forEach(opt => opt.classList.remove('selected'));
    
    // Loop through all marketplaces and add their agents
    for (const marketplaceId in marketplaceAgents) {
      const agents = marketplaceAgents[marketplaceId];
      const marketplaceName = document.querySelector(`.marketplace-option[data-marketplace="${marketplaceId}"] span`).textContent;
      
      // Add marketplace header
      const marketplaceHeader = document.createElement('div');
      marketplaceHeader.className = 'marketplace-header-divider';
      marketplaceHeader.innerHTML = `<h4>${marketplaceName}</h4>`;
      agentsContainer.appendChild(marketplaceHeader);
      
      // Add agents from this marketplace
      agents.forEach(agent => {
        const agentCard = document.createElement('div');
        agentCard.className = 'agent-card';
        agentCard.innerHTML = `
          <div class="agent-icon">${agent.name.charAt(0)}</div>
          <div class="agent-info">
            <div class="agent-name">${agent.name}</div>
            <div class="agent-description">${agent.description}</div>
            <div class="agent-metrics">
              <div class="agent-metric positive">ROI: ${agent.roi}</div>
              <div class="agent-metric">Users: ${agent.users.toLocaleString()}</div>
              <div class="agent-metric">Fee: ${agent.fee}</div>
            </div>
          </div>
          <div class="agent-actions">
            <button class="invest-btn" data-agent-id="${agent.id}">Invest</button>
          </div>
        `;
        
        agentsContainer.appendChild(agentCard);
      });
    }
    
    // Add event listeners to invest buttons
    const investButtons = document.querySelectorAll('.invest-btn');
    investButtons.forEach(button => {
      button.addEventListener('click', (e) => {
        e.stopPropagation();
        const agentId = button.getAttribute('data-agent-id');
        showInvestModal(agentId);
      });
    });
  }
  
  function showInvestModal(agentId) {
    // Find the agent
    let agent;
    for (const marketplace in marketplaceAgents) {
      const found = marketplaceAgents[marketplace].find(a => a.id === agentId);
      if (found) {
        agent = found;
        break;
      }
    }
    
    if (!agent) return;
    
    const content = `
      <div class="invest-form">
        <div class="agent-details">
          <div class="agent-icon large">${agent.name.charAt(0)}</div>
          <div>
            <h3>${agent.name}</h3>
            <p>${agent.description}</p>
            <div class="agent-metrics">
              <div class="agent-metric positive">ROI: ${agent.roi}</div>
              <div class="agent-metric">Fee: ${agent.fee}</div>
            </div>
          </div>
        </div>
        
        <div class="form-group">
          <label for="investAmount">Investment Amount</label>
          <div class="input-with-select">
            <input type="number" id="investAmount" value="100" min="10" class="form-input">
            <select id="investToken" class="form-select">
              <option value="USDC">USDC</option>
              <option value="SOL">SOL</option>
              <option value="ETH">ETH</option>
            </select>
          </div>
        </div>
        
        <div class="form-group">
          <label for="investDuration">Investment Duration</label>
          <select id="investDuration" class="form-select">
            <option value="1">1 Month</option>
            <option value="3" selected>3 Months</option>
            <option value="6">6 Months</option>
            <option value="12">12 Months</option>
          </select>
        </div>
        
        <div class="investment-summary">
          <div class="summary-item">
            <span>Estimated Return:</span>
            <span class="positive">${agent.roi} (annualized)</span>
          </div>
          <div class="summary-item">
            <span>Platform Fee:</span>
            <span>${agent.fee}</span>
          </div>
        </div>
      </div>
    `;
    
    const actions = `
      <button class="btn btn-primary" id="confirmInvestBtn">Confirm Investment</button>
      <button class="btn btn-secondary" id="cancelInvestBtn">Cancel</button>
    `;
    
    showModal(`Invest in ${agent.name}`, content, actions);
    
    document.getElementById('confirmInvestBtn').addEventListener('click', () => {
      const amount = document.getElementById('investAmount').value;
      const token = document.getElementById('investToken').value;
      const duration = document.getElementById('investDuration').value;
      
      showNotification(`Successfully invested ${amount} ${token} in ${agent.name} for ${duration} month${duration > 1 ? 's' : ''}!`, 'success');
      modalContainer.classList.add('hidden');
      marketplaceModal.classList.add('hidden');
    });
    
    document.getElementById('cancelInvestBtn').addEventListener('click', () => {
      modalContainer.classList.add('hidden');
    });
  }
  
  // Event Listeners
  voiceButton.addEventListener('click', toggleSpeechRecognition);
  sendBtn.addEventListener('click', showSendModal);
  
  // Permission modal event listeners
  requestPermissionBtn.addEventListener('click', () => {
    // Request microphone permission
    requestMicrophonePermission().then(granted => {
      if (granted) {
        // Permission granted, hide modal and start recognition
        permissionModal.classList.add('hidden');
        startRecognition();
      } else {
        // Permission denied, show notification with instructions
        showNotification('Microphone access denied. Please check browser settings.');
      }
    });
  });
  
  closePermissionModal.addEventListener('click', () => {
    permissionModal.classList.add('hidden');
  });
  receiveBtn.addEventListener('click', () => {
    // Show receive modal with wallet address
    const content = `
      <div class="wallet-address-container">
        <p>Your wallet address:</p>
        <div class="wallet-address">0x7F5EB5bB5cF88cfcEe9613368636f458800e62CB</div>
        <button class="btn btn-secondary copy-btn" id="copyAddress">Copy</button>
      </div>
      <div class="qr-code-container">
        <div class="qr-placeholder">QR Code Placeholder</div>
      </div>
    `;
    
    const actions = `
      <button class="btn btn-primary" id="closeReceive">Close</button>
    `;
    
    showModal('Receive Tokens', content, actions);
    
    document.getElementById('copyAddress').addEventListener('click', () => {
      navigator.clipboard.writeText('0x7F5EB5bB5cF88cfcEe9613368636f458800e62CB');
      showNotification('Address copied to clipboard');
    });
    
    document.getElementById('closeReceive').addEventListener('click', () => {
      modalContainer.classList.add('hidden');
    });
  });
  
  swapBtn.addEventListener('click', showSwapModal);
  historyBtn.addEventListener('click', showHistoryModal);
  configureAgentBtn.addEventListener('click', showAgentConfigModal);
  marketplaceBtn.addEventListener('click', showMarketplaceModal);

  // Close marketplace modal button
  if (closeMarketplaceBtn) {
    closeMarketplaceBtn.addEventListener('click', () => {
      marketplaceModal.classList.add('hidden');
    });
  }

  // Initialize wallet
  initWallet();
  
  // Lock screen event listeners
  const unlockButton = document.getElementById('unlockButton');
  const lockPassword = document.getElementById('lockPassword');
  const forgotPassword = document.getElementById('forgotPassword');
  const supportLink = document.getElementById('supportLink');
  
  unlockButton.addEventListener('click', () => {
    // In a real app, you would validate the password here
    // For demo purposes, we'll just unlock regardless of password
    hideLockScreen();
  });
  
  lockPassword.addEventListener('keypress', (e) => {
    if (e.key === 'Enter') {
      hideLockScreen();
    }
  });
  
  forgotPassword.addEventListener('click', (e) => {
    e.preventDefault();
    showNotification('Password reset functionality would be implemented in a real app');
  });
  
  supportLink.addEventListener('click', (e) => {
    e.preventDefault();
    showNotification('Support contact would be implemented in a real app');
  });
  setupSpeechRecognition();

  // Add custom CSS for notifications
  const style = document.createElement('style');
  style.textContent = `
    .notification {
      position: fixed;
      bottom: -60px;
      left: 50%;
      transform: translateX(-50%);
      background-color: var(--primary-color);
      color: white;
      padding: 12px 20px;
      border-radius: 6px;
      box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
      transition: bottom 0.3s ease;
      z-index: 1000;
    }
    
    .notification.show {
      bottom: 20px;
    }
    
    .form-group {
      margin-bottom: 16px;
    }
    
    .form-group label {
      display: block;
      margin-bottom: 6px;
      font-weight: 500;
    }
    
    .form-group input, .form-group select {
      width: 100%;
      padding: 8px 12px;
      border: 1px solid var(--border-color);
      border-radius: 4px;
      font-size: 14px;
    }
    
    .checkbox-group {
      display: grid;
      grid-template-columns: 1fr 1fr;
      gap: 8px;
    }
    
    .checkbox-item {
      display: flex;
      align-items: center;
    }
    
    .checkbox-item input {
      margin-right: 6px;
    }
    
    .wallet-address-container {
      margin-bottom: 16px;
    }
    
    .wallet-address {
      background-color: var(--background-color);
      padding: 10px;
      border-radius: 4px;
      font-family: monospace;
      margin: 8px 0;
      word-break: break-all;
    }
    
    .copy-btn {
      margin-top: 8px;
    }
    
    .qr-placeholder {
      width: 150px;
      height: 150px;
      margin: 0 auto;
      background-color: var(--background-color);
      display: flex;
      justify-content: center;
      align-items: center;
      border: 1px solid var(--border-color);
    }
    
    .transaction-list {
      max-height: 300px;
      overflow-y: auto;
    }
    
    .transaction-item {
      display: flex;
      justify-content: space-between;
      padding: 10px 0;
      border-bottom: 1px solid var(--border-color);
    }
    
    .transaction-item:last-child {
      border-bottom: none;
    }
    
    .tx-type {
      font-weight: 600;
      margin-bottom: 4px;
    }
    
    .tx-type.send {
      color: var(--danger-color);
    }
    
    .tx-type.receive {
      color: var(--success-color);
    }
    
    .tx-type.swap {
      color: var(--primary-color);
    }
    
    .tx-date {
      font-size: 12px;
      color: var(--text-secondary);
    }
    
    .performance-item {
      display: flex;
      justify-content: space-between;
      margin-bottom: 8px;
    }
    
    .performance-value.positive {
      color: var(--success-color);
    }
    
    .performance-value.negative {
      color: var(--danger-color);
    }
  `;
  document.head.appendChild(style);
});
