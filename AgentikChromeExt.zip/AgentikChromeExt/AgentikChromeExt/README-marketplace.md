# Agentik Marketplace Feature

The Agentik Marketplace is a new feature in the Agentik Wallet Chrome extension that allows users to browse and invest in various AI trading agents across multiple marketplaces.

## Features

- Browse agents from multiple marketplaces: Avo.so, AIXBT, Belive.app, and Agentik
- View detailed agent information including ROI, user count, and fees
- Invest in agents with customizable investment amount and duration
- Receive success notifications upon investment

## How to Use

1. Click on the "Marketplace" button in the Quick Actions section of the wallet
2. Select a marketplace from the available options (Avo.so, AIXBT, Belive.app, or Agentik)
3. Browse the available agents in the selected marketplace
4. Click "Invest" on an agent to open the investment modal
5. Specify investment amount, token, and duration
6. Click "Confirm Investment" to complete the investment

## Implementation Details

The Marketplace feature consists of:

- A marketplace button in the Quick Actions section
- A marketplace modal with marketplace selection
- Dynamic agent listing based on selected marketplace
- Investment modal for agent investments
- Success notifications for completed investments

## File Structure

- `/popup/popup.html` - Contains the HTML structure for the marketplace UI
- `/popup/popup.js` - Contains the JavaScript functionality for the marketplace
- `/popup/popup.css` - Contains the CSS styling for the marketplace UI
- `/assets/marketplace/` - Contains marketplace logos and placeholder images

## Mock Data

The current implementation uses mock data for marketplaces and agents. In a production environment, this would be replaced with API calls to fetch real marketplace and agent data.

## Future Enhancements

- Add real-time ROI tracking for invested agents
- Implement portfolio view for all agent investments
- Add filtering and sorting options for agents
- Implement real API integration with marketplaces
